﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class CustomerInfo : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string Gradeid;
        public CustomerInfo()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCustName.Text == "" || txtCustName.Text == null)
                {
                    MessageBox.Show("Please Enter Customer Name");
                    txtCustName.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Customer_Masters where k.CompID == "0001" && k.Customer_Id == txtCustId.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_Customer_Master("0001", txtCustId.Text);
                        Customer_Master gm = new Customer_Master();
                        gm.Customer_Name = (txtCustName.Text == "") ? "" : txtCustName.Text;
                        gm.Customer_Id = txtCustId.Text;
                        gm.CompID = "0001";
                        gm.Created_By = "";
                        gm.Created_On = DateTime.Now;
                        gm.Modified_By = "";
                        gm.Modified_On = DateTime.Now;
                        db.Customer_Masters.InsertOnSubmit(gm);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Succesfully");
                        BindGrid();
                        Clear();
                    }
                    else
                    {
                        Customer_Master gm = new Customer_Master();
                        gm.Customer_Name = (txtCustName.Text == "") ? "" : txtCustName.Text;
                        var sa = (db.Sp_autoincrement_Customer_Master("0001")).ToList();
                        gm.Customer_Id = sa.FirstOrDefault().Customer_Id;
                        gm.CompID = "0001";
                        gm.Created_By = "";
                        gm.Created_On = DateTime.Now;
                        gm.Modified_By = "";
                        gm.Modified_On = DateTime.Now;
                        db.Customer_Masters.InsertOnSubmit(gm);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Succesfully");
                        BindGrid();
                        Clear();
                    }

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void Clear()
        {
            try
            {
                txtCustId.Text = "";
                txtCustName.Text = "";
               
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public void BindGrid()
        {
            try
            {
                var sa = ((from k in db.Customer_Masters where k.CompID == "0001" select new { k.Customer_Id, k.Customer_Name })).ToList();
                if (sa.Count > 0)
                {
                    dgCustmaster.DataSource = sa;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        private void dgCustmaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    Gradeid = (dgCustmaster.Rows[e.RowIndex].Cells["Customer_Id"].Value.ToString());
                    var sa = (from k in db.Customer_Masters where k.CompID == "0001" && k.Customer_Id == Gradeid select k).ToList();
                    if (sa.Count > 0)
                    {
                        txtCustId.Text = sa[0].Customer_Id;
                        txtCustName.Text = sa[0].Customer_Name;
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                Clear();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CustomerInfo_Load(object sender, EventArgs e)
        {
            BindGrid();
        }
    }
}
