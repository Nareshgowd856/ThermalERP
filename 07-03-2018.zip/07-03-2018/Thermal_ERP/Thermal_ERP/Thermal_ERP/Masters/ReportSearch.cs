﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Thermal_ERP.Masters
{
    public partial class ReportSearch : Form
    {
        public static string reportno;
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public ReportSearch()
        {
            InitializeComponent();
        }

        private void ReportSearch_Load(object sender, EventArgs e)
        {
            var data2 = db.Activity_Reports.Select(c => c.Report_No).Distinct().ToArray();
            AutoCompleteStringCollection instcol = new AutoCompleteStringCollection();
            instcol.AddRange(data2);
            textBox1.AutoCompleteCustomSource = instcol;
            var sa = (from k in db.Activity_Reports where k.CompID == "0001" select new { k.Report_No, k.Main_Work_Center, k.Activity_Code, k.Work_Center }).ToList();
            if(sa.Count>0)
            {
                dgCustmaster.DataSource = sa;
            }
            else
            {

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            var sa = (from k in db.Activity_Reports where k.CompID == "0001" select new { k.Report_No, k.Main_Work_Center, k.Activity_Code, k.Work_Center }).ToList();
            if (sa.Count > 0)
            {
                dgCustmaster.DataSource = sa;
            }
            else
            {

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Activity_Reports where k.Report_No == textBox1.Text.Trim() && k.CompID == "0001" select new { k.Report_No, k.Main_Work_Center, k.Activity_Code, k.Work_Center }).ToList();
                if(sa.Count>0)
                {
                    dgCustmaster.DataSource = sa;
                }
                else
                {
                    MessageBox.Show("No Recoreds Found");
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dgCustmaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
              if(e.RowIndex>=0)
                {
                  reportno = (dgCustmaster.Rows[e.RowIndex].Cells["Report_No"].Value == "" || dgCustmaster.Rows[e.RowIndex].Cells["Report_No"].Value == null) ? "" : dgCustmaster.Rows[e.RowIndex].Cells["Report_No"].Value.ToString();
                   
                    if (reportno != "")
                    {
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
