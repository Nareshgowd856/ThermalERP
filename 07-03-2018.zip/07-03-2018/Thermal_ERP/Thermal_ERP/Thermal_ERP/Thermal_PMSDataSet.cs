﻿namespace Thermal_ERP
{


    partial class Thermal_PMSDataSet
    {
        partial class Maker_MasterDataTable
        {
        }
    }
}
