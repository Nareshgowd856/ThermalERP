﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Thermal_ERP
{
    public partial class frmActivityMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);
        public frmActivityMaster()
        {
            InitializeComponent();
        }

        private void frmActivityMaster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Activity_Master' table. You can move, or remove it, as needed.
          //  this.activity_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Activity_Master);
            BindGrid();

            using (SqlCommand cmd = new SqlCommand("select Maker_Description from Maker_Master", con))
            {
                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    using (DataTable dt = new DataTable())
                    {
                        da.Fill(dt);
                        for (int i=0; i<dt.Rows.Count;i++)
                        {

                            checkedListBox1.Items.Add(dt.Rows[i][0].ToString());
                        }
                    }

                }
            }
            
        }
        public void BindGrid()
        {
            var sa = (from k in db.Activity_Masters where k.CompID == "0001" select new { k.Activity_Code, k.Activity_Description, k.Activity_Group }).ToList();
            if(sa.Count>0)
            {
                dataGridView1.DataSource = sa;
            }
        }
        public void Clear()
        {
            try
            {
                txtactCode.Text = "";
                //txtActGroup.Text = "";
                cmbActivityGroup.Text = "";
                txtApprxExetime.Text = "";
                txtDescription.Text = "";
                txtPredessoActCode.Text = "";
                cmbActType.Text = "";
                cmblinkDoc.Text = "";
                if (dgActMaster.Rows.Count > 0)
                {
                    for (int i = 0; i < dgActMaster.Rows.Count - 1; i++)
                    {
                        dgActMaster.Rows.RemoveAt(i);
                        i--;
                        while (dgActMaster.Rows.Count == 0)
                            continue;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //activity_MasterTableAdapter.DeleteQuery(textBox1.Text);
            //activity_MasterTableAdapter.InsertActivity(textBox1.Text, textBox2.Text, textBox3.Text, comboBox1.Text, comboBox2.Text, textBox4.Text, textBox5.Text, "0001");
            try
            {
                if (txtactCode.Text == "" || txtactCode.Text == null)
                {
                    MessageBox.Show("Please Enter Activity Code");
                    txtactCode.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Activity_Masters where k.CompID == "0001" && k.Activity_Code == txtactCode.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_Activity_Master("0001", txtactCode.Text);
                        Activity_Master m = new Activity_Master();
                        m.Activity_Code = txtactCode.Text;
                        m.Activity_Description = (txtDescription.Text == "") ? "" : txtDescription.Text;
                        m.Activity_Group = (cmbActivityGroup.Text == "") ? "" : cmbActivityGroup.Text;
                        m.Activity_Document = (cmblinkDoc.Text == "") ? "" : cmblinkDoc.Text;
                        m.Activity_Type = (cmbActType.Text == "") ? "" : cmbActType.Text;
                        m.Activity_Predessor = (txtPredessoActCode.Text == "") ? "" : txtPredessoActCode.Text;
                        m.Activity_Exe_Time = (txtApprxExetime.Text == "") ? "" : txtApprxExetime.Text;
                        m.Activity_Level = (comboBox2.Text == "") ? "" : comboBox2.Text;
                        m.Resp_Dept = (comboBox3.Text == "") ? "" : comboBox3.Text;
                        m.Time_Unit = (comboBox1.Text == "") ? "" : comboBox1.Text;
                        m.Applicable_Equipments = (textBox1.Text == "") ? "" : textBox1.Text;

                        m.CompID = "0001";
                        //m.Created_By = "";
                        //m.Created_On = DateTime.Now;
                        m.Modified_By = "";
                        m.Modified_on = DateTime.Now;
                        db.Activity_Masters.InsertOnSubmit(m);
                        db.SubmitChanges();
                        for (int y = 0; y < dgActMaster.Rows.Count - 1; y++)
                        {
                            Activity_Child c = new Activity_Child();
                            c.Activity_Code = txtactCode.Text;
                            c.Activity_Res_Id = (dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value == "" || dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value.ToString();
                            c.Act_Noof_Res = (dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value == "" || dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value.ToString();
                            c.Act_Res_Cost = (dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value == "" || dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value.ToString();
                            c.Act_Res_Skill_Level = (dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value == "" || dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value.ToString();
                            c.CompID = "0001";
                            c.Modified_On = "";
                            c.Modified_By = DateTime.Now;
                            db.Activity_Childs.InsertOnSubmit(c);
                            db.SubmitChanges();

                        }
                        MessageBox.Show("Recored UpDated Successfully");
                        BindGrid();
                        Clear();
                        return;
                    }
                    else
                    {
                        Activity_Master m = new Activity_Master();
                        m.Activity_Code = txtactCode.Text;
                        m.Activity_Description = (txtDescription.Text == "") ? "" : txtDescription.Text;
                        m.Activity_Group = (cmbActivityGroup.Text == "") ? "" : cmbActivityGroup.Text;
                        m.Activity_Document = (cmblinkDoc.Text == "") ? "" : cmblinkDoc.Text;
                        m.Activity_Type = (cmbActType.Text == "") ? "" : cmbActType.Text;
                        m.Activity_Predessor = (txtPredessoActCode.Text == "") ? "" : txtPredessoActCode.Text;
                        m.Activity_Exe_Time = (txtApprxExetime.Text == "") ? "" : txtApprxExetime.Text;
                        m.Activity_Level = (comboBox2.Text == "") ? "" : comboBox2.Text;
                        m.Resp_Dept = (comboBox3.Text == "") ? "" : comboBox3.Text;
                        m.Time_Unit = (comboBox1.Text == "") ? "" : comboBox1.Text;
                        m.Applicable_Equipments = (textBox1.Text == "") ? "" : textBox1.Text;
                        m.CompID = "0001";
                        m.Created_By = "";
                        m.Created_On = DateTime.Now;
                        //m.Modified_By = "";
                        //m.Modified_on = DateTime.Now;
                        db.Activity_Masters.InsertOnSubmit(m);
                        db.SubmitChanges();
                        for (int y = 0; y < dgActMaster.Rows.Count - 1; y++)
                        {
                            Activity_Child c = new Activity_Child();
                            c.Activity_Code = txtactCode.Text;
                            c.Activity_Res_Id = (dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value == "" || dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Activity_Res_Id"].Value.ToString();
                            c.Act_Noof_Res = (dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value == "" || dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Noof_Res"].Value.ToString();
                            c.Act_Res_Cost = (dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value == "" || dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Res_Cost"].Value.ToString();
                            c.Act_Res_Skill_Level = (dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value == "" || dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value == null) ? "" : dgActMaster.Rows[y].Cells["Act_Res_Skill_Level"].Value.ToString();
                            c.CompID = "0001";
                            c.Created_By = "";
                            c.Created_On = DateTime.Now;
                            db.Activity_Childs.InsertOnSubmit(c);
                            db.SubmitChanges();

                        }
                        MessageBox.Show("Recored Saved Successfully");
                        BindGrid();
                        Clear();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        DataTable dt;
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {

                    string actno = dataGridView1.Rows[e.RowIndex].Cells["Activity_Code"].Value.ToString();
                    var sa = (from k in db.Activity_Masters where k.CompID == "0001" && k.Activity_Code == actno select k).ToList();
                    if (sa.Count > 0)
                    {
                        txtactCode.Text = sa[0].Activity_Code;
                        txtDescription.Text = sa[0].Activity_Description;
                        cmbActivityGroup.Text = sa[0].Activity_Group;
                        cmblinkDoc.Text = sa[0].Activity_Document;
                        cmbActType.Text = sa[0].Activity_Type;
                        txtPredessoActCode.Text = sa[0].Activity_Predessor;
                        txtApprxExetime.Text = sa[0].Activity_Exe_Time;
                        comboBox2.Text = sa[0].Activity_Level;
                        comboBox3.Text = sa[0].Resp_Dept;
                        comboBox1.Text = sa[0].Time_Unit;
                        string maker;
                        if (sa[0].Applicable_Equipments != null)
                        {
                            maker = sa[0].Applicable_Equipments.ToString();
                            textBox1.Text = sa[0].Applicable_Equipments.ToString();
                        }
                        else
                        {
                            maker = null; 
                        }
                        if (maker != null)
                        {
                            string[] p = new string[] { };
                            p = maker.ToString().Split(',');
                            int len = p.Length;
                            for(int i =0; i<len;i++)
                            {
                                string m2 = p[i];
                                for (int j = 0; j < checkedListBox1.Items.Count-1; j++)
                                {

                                    if(checkedListBox1.Items[j].ToString()==m2)
                                    {
                                        checkedListBox1.SetItemChecked(j, true);
                                    }
                                }
                            }
                        }
                    }
                    var g = (from j in db.Activity_Childs where j.CompID == "0001" && j.Activity_Code == actno select new { j.Activity_Res_Id, j.Act_Noof_Res, j.Act_Res_Cost, j.Act_Res_Skill_Level });
                    SqlCommand cmd2 = (SqlCommand)db.GetCommand(g);
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                    dt = new DataTable();
                    da2.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        
                        dgActMaster.DataSource = dt;
                    }
                    else
                    {
                        dgActMaster.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are You Sure Want to Delete this Record ", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    db.Sp_Delete_Activity_Master("0001", txtactCode.Text);
                    BindGrid();
                    Clear();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void comboBox2_Leave(object sender, EventArgs e)
        {

            //var sa = (from k in db.Activity_Masters where k.CompID == "0001" select new { k.Activity_Code, k.Activity_Description, k.Activity_Group }).ToList();
            //if (sa.Count > 0)
            //{
            //    dataGridView1.DataSource = sa;
            //}

            if(comboBox2.Text == "L1")
            {
                cmbActivityGroup.Text = txtDescription.Text;
            }
            else
            {
                string Level = comboBox2.Items[comboBox2.SelectedIndex-1].ToString();

                var sa1 = (from g in db.Activity_Masters where g.CompID == "0001" && g.Activity_Level == Level select new { g.Activity_Code,g.Activity_Description }).Distinct().ToList();
                if (sa1.Count > 0)
                {
                    cmbActivityGroup.DataSource = sa1;
                    cmbActivityGroup.DisplayMember = "Activity_Description";
                    cmbActivityGroup.ValueMember = "Activity_Code";
                }
            }
        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            string ItemSelected = "";
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if(checkedListBox1.GetItemChecked(i))
                {
                    if(ItemSelected=="")
                    {
                        ItemSelected = checkedListBox1.Items[i].ToString();
                    }
                    else
                    {
                        ItemSelected = ItemSelected + ',' + checkedListBox1.Items[i].ToString();
                    }
                    
                }
            }
            textBox1.Text = ItemSelected.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
