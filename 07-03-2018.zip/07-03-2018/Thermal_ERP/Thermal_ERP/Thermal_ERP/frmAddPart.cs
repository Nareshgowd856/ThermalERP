﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing.Printing;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmAddPart : Form
    {

        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);


        public frmAddPart()
        {
            InitializeComponent();
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmAddSubassembly frm = new frmAddSubassembly();
            //frm.MdiParent = this.ParentForm;
            frm.Show();
        }

        private void comboBox6_Leave(object sender, EventArgs e)
        {
            if(cmbPartGroup.Text== "Main Assembly")
            {
                var sa = (from k in db.Part_List_Items where k.CompId == "0001" && k.Part_Group == cmbPartGroup.Text.Trim() select new { k.Part_Name }).Distinct().ToList();
                if(sa.Count>0)
                {
                    comboBox1.DataSource = sa;
                    comboBox1.DisplayMember = "Part_Name";
                    comboBox1.ValueMember = "Part_Name";
                    
                    if(comboBox1.Items.Count>0)
                    {
                        comboBox1.SelectedIndex = -1;
                    }
                    else
                    {
                        comboBox1.SelectedIndex = -1;
                    }
                    cmbPartname.Text = "";
                }               
            }
            else if (cmbPartGroup.Text == "Sub Assembly")
            {
                var sa = (from k in db.SubAssembly_Masters where k.CompID == "0001"  select new { k.Sub_Assembly_Name }).Distinct().ToList();
                if (sa.Count > 0)
                {
                    cmbPartname.DataSource = sa;
                    cmbPartname.DisplayMember = "Sub_Assembly_Name";
                    cmbPartname.ValueMember = "Sub_Assembly_Name";
                    comboBox1.Text = "";
                    if (cmbPartname.Items.Count > 0)
                    {
                        cmbPartname.SelectedIndex = -1;
                       
                    }
                    else
                    {
                        cmbPartname.SelectedIndex = -1;
                    }
                }
            }
            else
            {

            }
            //string strPartType = cmbPartGroup.Text;
            //switch(strPartType)
            //{
            //    case "Main Assembly":

            //        break;
            //    case "Sub Assembly" :
            //         SqlCommand cmd = new SqlCommand("select Sub_Assembly_Name from SubAssembly_Master where CompID='0001'", con);
            //    SqlDataAdapter da = new SqlDataAdapter(cmd);
            //    DataSet ds = new DataSet();
            //    da.Fill(ds, "p");
            //    //DataRow drow = ds.Tables["p"].NewRow();
            //    //drow["AccName"] = "SELF";
            //    //ds.Tables["p"].Rows.InsertAt(drow, 0);
            //    cmbPartname.DataSource = ds.Tables["p"];
            //        cmbPartname.DisplayMember = "Sub_Assembly_Name";
            //        cmbPartname.ValueMember = "Sub_Assembly_Name";
            //        cmbPartname.SelectedIndex = -1;
            //        //comboBox6.DataSource = Thermal_PMSDataSetTableAdapters.APG_MasterTableAdapter;
            //        break;
            //    case "Brought Out Component" :
            //        break;
            //}   
        }

        private void comboBox7_Leave(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select Variant_Name from Variant_Master where Sub_Assembly_Name ='" + cmbPartname.Text + "' and  CompID='0001'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "p");
            //DataRow drow = ds.Tables["p"].NewRow();
            //drow["AccName"] = "SELF";
            //ds.Tables["p"].Rows.InsertAt(drow, 0);
            cmbvariant.DataSource = ds.Tables["p"];
            cmbvariant.DisplayMember = "Variant_Name";
            cmbvariant.ValueMember = "Variant_Name";
            cmbvariant.SelectedIndex = -1;
        }
        public void BindMethods()
        {
            var sa = (from k in db.Material_Grades where k.CompID == "0001" select new { k.Material_Grad,k.Spec_Code }).ToList();
            if (sa.Count > 0)
            {
                cmbSpecification.DataSource = sa;
                cmbSpecification.DisplayMember = "Material_Grad";
                cmbSpecification.ValueMember = "Spec_Code";
                if (cmbSpecification.Items.Count > 0)
                {
                    cmbSpecification.SelectedIndex = -1;
                }
                else
                {
                    cmbSpecification.SelectedIndex = -1;
                }
            }
            var s = (from d in db.UOM_Masters where d.CompId == "0001" select new { d.UOM_Name }).ToList();
            if(s.Count>0)
            {
                cmbUom.DataSource = s;
                cmbUom.DisplayMember = "UOM_Name";
                cmbUom.ValueMember = "UOM_Name";
                if(cmbUom.Items.Count>0)
                {
                    cmbUom.SelectedIndex = -1;
                }
                else
                {
                    cmbUom.SelectedIndex = -1;
                }
            }
            //var sqq = (from d in db.Material_Grades where d.CompID == "0001" select new { d.Material_Grad,d.Spec_Code }).ToList();
            //if (sqq.Count > 0)
            //{
            //    cmbSpecification.DataSource = sqq;
            //    cmbSpecification.DisplayMember = "Material_Grad";
            //    cmbSpecification.ValueMember = "Spec_Code";
            //    if (cmbSpecification.Items.Count > 0)
            //    {
            //        cmbSpecification.SelectedIndex = -1;
            //    }
            //    else
            //    {
            //        cmbSpecification.SelectedIndex = -1;
            //    }
            //}
        }
        private void frmAddPart_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Material_Grades' table. You can move, or remove it, as needed.
            //    this.material_GradesTableAdapter.Fill(this.thermal_PMSDataSet.Material_Grades);
            BindMethods();
           if ("frmpartlist" == frmPartList.part)
            {
                txtmarkerno.Text= frmPartList.MakerNo;
                 txtprojectcode.Text=frmPartList.projectCode;
                txtapgno.Text =frmPartList.apgno;
               txtApgname.Text=  frmPartList.Eqpname;
                txtplno.Text= frmPartList.Partno;
                txtverno.Text = frmPartList.Revno;
                txtmaindrawingno.Text = frmPartList.DRAWINGNO;
                txtRevStatus.Text = frmPartList.revStatus;
            }
           else if("TreeviewItemName"==frmPartList.part)
            {
                txtmarkerno.Text = frmPartList.MakerNo;
                txtprojectcode.Text = frmPartList.projectCode;
                txtapgno.Text = frmPartList.apgno;
                txtApgname.Text = frmPartList.Eqpname;
                txtplno.Text = frmPartList.Partno;
                txtpartno.Text = frmPartList.plno;
                txtRevStatus.Text = frmPartList.revStatus;
                //  txtverno.Text = frmPartList.Revno;

                var sa = (from k in db.Part_List_Items where k.CompId == "0001" && k.Partlist_No == txtplno.Text&&k.Part_Sl_No==txtpartno.Text// && k.Status== "Revised" 
                          select k).ToList();
                if(sa.Count>0)
                {
                    txtprojectcode.Text = sa[0].Project_Code;
                    txtmarkerno.Text = sa[0].Maker_No;
                    txtplno.Text = sa[0].Partlist_No;
                    txtapgno.Text = sa[0].Apg_No;
                    txtApgname.Text = sa[0].Apg_Name;
                    cmbPartGroup.Text = sa[0].Part_Group;
                    txtpartno.Text = sa[0].Part_Sl_No;
                    cmbPartname.Text = sa[0].Part_Name;
                    txtmaindrawingno.Text = sa[0].Main_Drwaing_No;
                    txtdescription.Text = sa[0].Part_Desription;
                    cmbvariant.Text = sa[0].Part_variant;
                    cmbUom.Text = sa[0].Part_UOM;
                    cmbSpecification.Text = sa[0].Part_Spec_Id;
                    cmbRmtype.Text = sa[0].Part_Rm_Type;
                    txtdrawingno.Text = sa[0].Drawing_NO;
                    cmbptsno.Text = sa[0].PTS_NO;
                    cmbThickNo.Text = Convert.ToString(sa[0].Part_Rm_WThick);
                    txtDensity.Text = Convert.ToString(sa[0].Part_Rm_Density);
                    if("Yes"== sa[0].Part_EN_Cert)
                    {
                        chkEn.Checked = true;
                    }
                   else
                    {
                        chkEn.Checked = false;
                    }
                    if ("Yes" == sa[0].Part_IBR_Cert)
                    {
                        chkIbr.Checked = true;
                    }
                    else
                    {
                        chkIbr.Checked = false;
                    }
                    if ("Yes" == sa[0].Part_Mtc_Cert)
                    {
                        chkMtc.Checked = true;
                    }
                    else
                    {
                        chkMtc.Checked = false;
                    }
                    txtMMitem.Text = sa[0].Part_RM_Code;
                    txtDia.Text = Convert.ToString(sa[0].Part_Dia);
                    txtThickness.Text = Convert.ToString(sa[0].Part_Rm_WThick);
                    txtlength.Text = Convert.ToString(sa[0].Part_Length);
                    txtfgwt.Text = Convert.ToString(sa[0].Part_Fg_wt);
                    txtrmwt.Text = Convert.ToString(sa[0].Part_Rm_Wt);
                    txtDwt.Text = Convert.ToString(sa[0].Part_D_Wt);
                   // txtod.Text = Convert.ToString(sa[0].OD);
                    txtW2.Text = Convert.ToString(sa[0].Part_W2);
                    txtQty.Text = Convert.ToString(sa[0].Qty);
                    txtverno.Text = sa[0].Version_No;
                    dpdate.Value = Convert.ToDateTime(sa[0].Version_Date);
                    txtEqpName.Text = sa[0].Part_Equipment_Name;
                    textBox2.Text = sa[0].Part_Spl_Notes;
                }
                else
                {
                    MessageBox.Show("Please Select Valid Name");
                    return;
                }

                //var obj = (from w1 in db.Project_ActivityCharts join k in db.Part_List_Items on w1.CompID equals k.CompId && while. where w.CompID == "0001" &&
                //        w.Project_Code == txtprojectcode.Text && w.Apg_No == txtapgno.Text && w.Apg_Name == txtEqpName.Text && w.Maker_No == txtmarkerno.Text && w.Partlist_No == txtplno.Text
                //        select new { w.Activity_Code,w.Activity_Description,w.Work_Center,w.Person_Rep,w.Planned_StartDate,w.Planned_CompletionDate,w.Actual_StartDate,w.Actual_Completiondate,w.Status});
                //SqlCommand cmd2 = (SqlCommand)db.GetCommand(obj);
                //SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                //DataTable  dt2 = new DataTable();
                //da2.Fill(dt2);
                //if (dt2.Rows.Count >0)
                //{
                //    dgActivity.DataSource = da2;
                //}
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Sp_Bind_PartlistIndiualData";
                cmd.Parameters.AddWithValue("@Compid", "0001");
                cmd.Parameters.AddWithValue("@ProjetCode", txtprojectcode.Text);
                cmd.Parameters.AddWithValue("@Maker", txtmarkerno.Text);
                cmd.Parameters.AddWithValue("@ApgNo", txtapgno.Text);
                cmd.Parameters.AddWithValue("@Partlistno ", txtplno.Text);//Revised
                cmd.Parameters.AddWithValue("@Status ", "Revised");
                cmd.Parameters.AddWithValue("@PartNo ", txtpartno.Text);
                cmd.Connection = con;
                // con.Open();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                con.Close();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    //dgActivity.DataSource = dt;
                   
                }
                  

                else
                {

                }
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.CommandText = "Sp_Bind_Version_Data";
                cmd1.Parameters.AddWithValue("@Compid", "0001");
                cmd1.Parameters.AddWithValue("@ProjetCode", txtprojectcode.Text);
                cmd1.Parameters.AddWithValue("@Maker", txtmarkerno.Text);
                cmd1.Parameters.AddWithValue("@ApgNo", txtapgno.Text);
                cmd1.Parameters.AddWithValue("@Partlistno ", txtplno.Text);//Revised@PartNo
                cmd1.Parameters.AddWithValue("@PartNo", txtpartno.Text);
                cmd1.Connection = con;
                // con.Open();

                SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                con.Close();
                da1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                    dataGridView1.DataSource = dt1;
                else
                {

                }
                //var s = (from k in db.Sp_Bind_PartlistIndiualData("0001", txtprojectcode.Text, txtmarkerno.Text, txtapgno.Text, txtplno.Text) select k).ToList();
                //if(s.Count>0)
                //{
                //    dgActivity.DataSource = s;
                //}
                //else
                //{

                //}
            }
           else
            {

            }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public string specno;
        private void comboBox2_Leave(object sender, EventArgs e)
        {
            try
            {
                var ka = (from m in db.Material_Grades where m.CompID == "0001" && m.Material_Grad == cmbSpecification.Text.Trim() select new { m.Spec_Code }).ToList();
                if (ka.Count > 0)
                {
                    specno = ka[0].Spec_Code;
                }
                var sa = (from k in db.Item_RM_Masters join w in db.Group_Masters on new { q=k.CompID,b=k.Item_Group} equals new {q=w.CompID,b=w.Group_Id } where k.CompID == "0001" && k.Item_Spec == specno select new { w.Group_Name }).Distinct().ToList();
                if(sa.Count>0)
                {
                    cmbRmtype.Text = sa[0].Group_Name;
                    //cmbRmtype.DisplayMember = "Item_Group";
                    //cmbRmtype.ValueMember = "Item_Group";
                    //if (cmbRmtype.Items.Count>0)
                    //{
                    //    cmbRmtype.SelectedIndex = -1;
                    //}
                    //else
                    //{
                    //    cmbRmtype.SelectedIndex = -1;
                    //}
                }
                var sa1 = (from g in db.Item_RM_Codes where g.CompID == "0001" && g.Item_Spec == specno select new { g.Item_WT }).Distinct().ToList();
                if(sa1.Count>0)
                {
                    cmbThickNo.DataSource = sa1;
                    cmbThickNo.DisplayMember = "Item_WT";
                    cmbThickNo.ValueMember = "Item_WT";
                }
                var sa2 = (from f in db.Material_Grades where f.CompID == "0001" && f.Material_Grad == cmbSpecification.Text select new { f.Material_Density }).Distinct().ToList();
                if(sa2.Count>0)
                {
                    txtDensity.Text = sa2[0].Material_Density.ToString();
                }
                // var sa = (from s in db.Sp_Bid_Specifications(cmbSpecification.Text.Trim(), "0001") select new { s.Item_Group }//, s.Item_WT, s.Material_Density }
                // ).Distinct().ToList();
                // if (sa.Count > 0)
                // {
                //     cmbRmtype.DataSource = sa;
                //     cmbRmtype.DisplayMember = "Item_Group";
                //     cmbRmtype.ValueMember = "Item_Group";
                //     //  comboBox5.DataSource = sa[0].Item_WT;
                //     //  textBox14.Text = sa[0].Material_Density.ToString();
                // }
                // var sa1 = (from s in db.Sp_Bid_Specifications(cmbSpecification.Text.Trim(), "0001") select new { s.Item_WT }//, s.Item_WT, s.Material_Density }
                //).Distinct().ToList();
                // if (sa.Count > 0)
                // {
                //     cmbThickNo.DataSource = sa1;
                //     cmbThickNo.DisplayMember = "Item_WT";
                //     cmbThickNo.ValueMember = "Item_WT";
                //     //  comboBox5.DataSource = sa[0].Item_WT;
                //     //  textBox14.Text = sa[0].Material_Density.ToString();
                // }
                // var sa2 = (from s in db.Sp_Bid_Specifications(cmbSpecification.Text.Trim(), "0001") select new { s.Material_Density }//, s.Item_WT, s.Material_Density }
                //).Distinct().ToList();
                // if (sa.Count > 0)
                // {
                //     txtDensity.Text = sa2[0].Material_Density.ToString();
                //     //comboBox4.DisplayMember = "Item_Group";
                //     //comboBox4.ValueMember = "Item_Group";
                //     //  comboBox5.DataSource = sa[0].Item_WT;
                //     //  textBox14.Text = sa[0].Material_Density.ToString();
                // }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void comboBox5_Leave(object sender, EventArgs e)
        {
            try
            {
                if(cmbSpecification.Text!="")
                {
                    string THINK = (cmbThickNo.Text == "") ? "" : cmbThickNo.Text;
                    if(THINK=="")
                    {

                    }
                    else
                    {
                        var sa = (from km in db.Item_RM_Codes where km.CompID == "0001" && km.Item_WT == Convert.ToDecimal(THINK) && km.Item_Spec == specno select new { km.Item_Code }).ToList();
                        if (sa.Count > 0)
                        {
                            txtMMitem.Text = sa[0].Item_Code;
                            txtThickness.Text = cmbThickNo.Text;
                        }
                        else
                        {
                            txtMMitem.Text = "";
                            txtThickness.Text = cmbThickNo.Text;
                        }
                        var ka = (from k in db.Item_RM_Codes where k.CompID == "0001" && k.Item_WT == Convert.ToDecimal(THINK) && k.Item_Spec == specno select new { k.Part_List_No }).ToList();
                        if (ka.Count > 0)
                        {
                            string ptnos = ka[0].Part_List_No;

                            string[] ptnosArr = null;
                            int count = 0;
                            if (ptnos == "" || ptnos == null)
                            {

                            }
                            else
                            {
                                char[] splitchar = { ',' };
                                ptnosArr = ptnos.Split(splitchar);
                                cmbptsno.Items.Clear();
                                for (count = 0; count <= ptnosArr.Length - 1; count++)
                                {
                                    string nn = ptnosArr[count];
                                    cmbptsno.Items.Add(nn);
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                    
                }
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void SaveRecord()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                Part_List_Item pl = new Part_List_Item();
                pl.Project_Code = (txtprojectcode.Text == "") ? "" : txtprojectcode.Text;
                pl.Maker_No = (txtmarkerno.Text == "") ? "" : txtmarkerno.Text;
                pl.Partlist_No = (txtplno.Text == "") ? "" : txtplno.Text;
                pl.Apg_No = (txtapgno.Text == "") ? "" : txtapgno.Text;
                pl.Main_Drwaing_No = (txtmaindrawingno.Text == "") ? "" : txtmaindrawingno.Text;
                pl.Apg_Name = (txtApgname.Text == "") ? "" : txtApgname.Text;
                pl.Part_Group = (cmbPartGroup.Text == "") ? "" : cmbPartGroup.Text;
                pl.Part_Name = (cmbPartname.Text == "") ? "" : cmbPartname.Text;
                pl.Part_Sl_No = (txtpartno.Text == "") ? "" : txtpartno.Text;
                pl.Part_Desription = (txtdescription.Text == "") ? "" : txtdescription.Text;
                pl.Part_variant = (cmbvariant.Text == "") ? "" : cmbvariant.Text;
                pl.Part_UOM = (cmbUom.Text == "") ? "" : cmbUom.Text;
                pl.Qty = (txtQty.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtQty.Text);
                pl.Part_Equipment_Name = (txtApgname.Text == "") ? "" : txtApgname.Text;
                pl.Part_Spec_Id = (cmbSpecification.Text == "") ? "" : cmbSpecification.Text;
                pl.Part_Rm_Type = (cmbRmtype.Text == "") ? "" : cmbRmtype.Text;
                pl.Drawing_NO = (txtdrawingno.Text == "") ? "" : txtdrawingno.Text;
                pl.PTS_NO = (cmbptsno.Text == "") ? "" : cmbptsno.Text;
                pl.Part_Rm_WThick = (cmbThickNo.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(cmbThickNo.Text);
                pl.Part_Rm_Density = (txtDensity.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDensity.Text);
                pl.Part_RM_Code = (txtMMitem.Text == "") ? "" : txtMMitem.Text;
                if (chkMtc.Checked == true)
                {
                    pl.Part_Mtc_Cert = "Yes";
                }
                else
                {
                    pl.Part_Mtc_Cert = "No";
                }
                if (chkIbr.Checked == true)
                {
                    pl.Part_IBR_Cert = "Yes";
                }
                else
                {
                    pl.Part_IBR_Cert = "No";
                }
                if (chkEn.Checked == true)
                {
                    pl.Part_EN_Cert = "Yes";
                }
                else
                {
                    pl.Part_EN_Cert = "No";
                }
                pl.Part_Dia = (txtDia.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDia.Text);
                pl.Part_W2 = (txtW2.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtW2.Text);
                pl.Part_Length = (txtlength.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtlength.Text);
                pl.Part_Fg_wt = (txtfgwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtfgwt.Text);
                pl.Part_Rm_Wt = (txtrmwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtrmwt.Text);
                pl.Part_D_Wt = (txtDwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDwt.Text);
                pl.Version_No = (txtverno.Text == "") ? "" : txtverno.Text;
                pl.Part_Engg_Code = txtprojectcode.Text + txtmarkerno.Text + txtapgno.Text + txtplno.Text + txtpartno.Text;
                pl.Activity_Part_No = txtprojectcode.Text + "." + txtmarkerno.Text + "." + txtapgno.Text + "." + txtplno.Text;
                pl.Part_Spl_Notes = (textBox2.Text == "") ? "" : textBox2.Text;
                pl.Version_Date = dpdate.Value;
                pl.Version_Change = (textBox1.Text == "") ? "" : textBox1.Text;
                pl.Status = "Created";
                pl.CompId = "0001";
                pl.Created = "";
                pl.Creted_By = DateTime.Now;
                pl.Modified = "";
                pl.Modified_By = DateTime.Now;
                db.Part_List_Items.InsertOnSubmit(pl);
                db.SubmitChanges();
              
                MessageBox.Show("Record Saved Succesfully");
                //Clear();
                     
                Cursor.Current = Cursors.Default;

            }
            catch (Exception ex)
            {


            }
        }
        public void UpdateRecord()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                Part_List_Item pl = new Part_List_Item();
                pl.Project_Code = (txtprojectcode.Text == "") ? "" : txtprojectcode.Text;
                pl.Maker_No = (txtmarkerno.Text == "") ? "" : txtmarkerno.Text;
                pl.Partlist_No = (txtplno.Text == "") ? "" : txtplno.Text;
                pl.Apg_No = (txtapgno.Text == "") ? "" : txtapgno.Text;
                pl.Main_Drwaing_No = (txtmaindrawingno.Text == "") ? "" : txtmaindrawingno.Text;
                pl.Apg_Name = (txtApgname.Text == "") ? "" : txtApgname.Text;
                pl.Part_Group = (cmbPartGroup.Text == "") ? "" : cmbPartGroup.Text;
                pl.Part_Name = (cmbPartname.Text == "") ? "" : cmbPartname.Text;
                pl.Part_Sl_No = (txtpartno.Text == "") ? "" : txtpartno.Text;
                pl.Part_Desription = (txtdescription.Text == "") ? "" : txtdescription.Text;
                pl.Part_variant = (cmbvariant.Text == "") ? "" : cmbvariant.Text;
                pl.Part_UOM = (cmbUom.Text == "") ? "" : cmbUom.Text;
                pl.Qty = (txtQty.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtQty.Text);
                pl.Part_Equipment_Name = (txtApgname.Text == "") ? "" : txtApgname.Text;
                pl.Part_Spec_Id = (cmbSpecification.Text == "") ? "" : cmbSpecification.Text;
                pl.Part_Rm_Type = (cmbRmtype.Text == "") ? "" : cmbRmtype.Text;
                pl.Drawing_NO = (txtdrawingno.Text == "") ? "" : txtdrawingno.Text;
                pl.PTS_NO = (cmbptsno.Text == "") ? "" : cmbptsno.Text;
                pl.Part_Rm_WThick = (cmbThickNo.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(cmbThickNo.Text);
                pl.Part_Rm_Density = (txtDensity.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDensity.Text);
                pl.Part_RM_Code = (txtMMitem.Text == "") ? "" : txtMMitem.Text;
                if (chkMtc.Checked == true)
                {
                    pl.Part_Mtc_Cert = "Yes";
                }
                else
                {
                    pl.Part_Mtc_Cert = "No";
                }
                if (chkIbr.Checked == true)
                {
                    pl.Part_IBR_Cert = "Yes";
                }
                else
                {
                    pl.Part_IBR_Cert = "No";
                }
                if (chkEn.Checked == true)
                {
                    pl.Part_EN_Cert = "Yes";
                }
                else
                {
                    pl.Part_EN_Cert = "No";
                }
                pl.Part_Dia = (txtDia.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDia.Text);
                pl.Part_W2 = (txtW2.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtW2.Text);
                pl.Part_Length = (txtlength.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtlength.Text);
                pl.Part_Fg_wt = (txtfgwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtfgwt.Text);
                pl.Part_Rm_Wt = (txtrmwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtrmwt.Text);
                pl.Part_D_Wt = (txtDwt.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDwt.Text);
                pl.Part_Spl_Notes = (textBox2.Text == "") ? "" : textBox2.Text;
                if (txtRevStatus.Text != "Create")
                {
                    var result = MessageBox.Show("Do You  Want to Update the Version No ", "Part List", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (result == DialogResult.Yes)
                    {
                        int verno = Convert.ToInt32(txtverno.Text);
                        int VersionNo = verno + 1;
                        string vrs = "0" + VersionNo;
                        pl.Version_No = vrs;
                        pl.Version_Change = (textBox1.Text == "") ? "" : textBox1.Text;
                        pl.Status = "Revised";
                    }
                }
                else
                {
                    int verno = Convert.ToInt32(txtverno.Text);
                    int VersionNo = verno;
                    string vrs = "0" + VersionNo;
                    pl.Version_No = vrs;
                    pl.Version_Date = dpdate.Value;
                    pl.Version_Change = (textBox1.Text == "") ? "" : textBox1.Text;
                    pl.Status = "Created";
                }





                //pl.Version_No = (txtverno.Text == "") ? "" : txtverno.Text;
                pl.Part_Engg_Code = txtprojectcode.Text + txtmarkerno.Text + txtapgno.Text + txtplno.Text + txtpartno.Text;
                pl.Activity_Part_No = txtprojectcode.Text + "." + txtmarkerno.Text + "." + txtapgno.Text + "." + txtplno.Text;
                
                
                //pl.Status = "Created";
                pl.CompId = "0001";
                pl.Created = "";
                pl.Creted_By = DateTime.Now;
                pl.Modified = "";
                pl.Modified_By = DateTime.Now;
                db.Part_List_Items.InsertOnSubmit(pl);
                db.SubmitChanges();

                MessageBox.Show("Record Saved Succesfully");
                //Clear();

                Cursor.Current = Cursors.Default;

            }
            catch (Exception ex)
            {


            }
        }
        public string abc;
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtprojectcode.Text == "" || txtprojectcode.Text == null)
                {
                    MessageBox.Show("Please Enter Project Code");
                    txtprojectcode.Focus();
                    return;
                }
                else
                {



                    if ((from j in db.Part_List_Items where j.CompId == "0001" && j.Project_Code == txtprojectcode.Text && j.Maker_No == txtmarkerno.Text && j.Part_Sl_No == txtpartno.Text.Trim() && j.Apg_No == txtapgno.Text && j.Apg_Name == txtApgname.Text && j.Partlist_No == txtplno.Text select j).Count() > 0)
                    {

                        UpdateRecord();
                        Clear();
                    }
                    else
                    {

                        SaveRecord();
                        Clear();
                    }
                }
            }
               
                    
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Clear()
        {
            try
            {
                //foreach(Control d in tableLayoutPanel1.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();
                //    if (d is ComboBox)
                //        (d as ComboBox).SelectedIndex = -1;
                //    if (d is CheckBox)
                //        (d as CheckBox).Checked = false;
                //}
                //foreach (Control d in tableLayoutPanel2.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();

                //}
                //foreach (Control d in groupBox1.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();

                //}
                //   txtprojectcode.Clear();txtmarkerno.Clear();txtplno.Clear();txtapgno.Clear();txtApgname.Clear();txtEqpName.Clear();
                txtdrawingno.Text=""; cmbptsno.Text=""; txtmaindrawingno.Clear(); cmbPartGroup.SelectedIndex = -1;txtpartno.Clear();cmbPartname.SelectedIndex = -1;txtdescription.Clear();cmbvariant.SelectedIndex = -1;cmbUom.SelectedIndex = -1;cmbSpecification.SelectedIndex = -1;cmbRmtype.Text = "";cmbThickNo.SelectedIndex = -1;txtDensity.Clear();chkEn.Checked = false;chkIbr.Checked = false;chkMtc.Checked = false; txtMMitem.Clear(); txtDia.Clear();txtW2.Clear();txtThickness.Clear();txtlength.Clear();txtverno.Clear();txtfgwt.Clear();txtrmwt.Clear();txtDwt.Clear();txtod.Clear();dpdate.Value = DateTime.Now;txtQty.Clear();
                //if(dgActivity.Rows.Count>0)
                //{
                //    for(int i=0;i<dgActivity.Rows.Count-1;i++)
                //    {
                //        dgActivity.Rows.RemoveAt(i);
                //        i--;
                //        while (dgActivity.Rows.Count == 0)
                //            continue;
                //    }
                //}
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Clear();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        public decimal lenght=0;
        private void txtlength_Leave(object sender, EventArgs e)
        {
            try
            {
                string len = (txtlength.Text == "") ? "0" : txtlength.Text;
                if(Convert.ToDecimal(len)>1000)
                {
                    lenght = Convert.ToDecimal(txtlength.Text) / 1000;
                    
                }
                else
                {
                    
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void txtfgwt_Leave(object sender, EventArgs e)
        {
            try
            {
                if(cmbRmtype.Text =="PLATE")
                {
                    string fwt = (txtDia.Text == "") ? "0" : txtDia.Text;
                    string thck = (cmbThickNo.Text == "") ? "0" : cmbThickNo.Text;
                    string den = (txtDensity.Text == "") ? "0" : txtDensity.Text;
                    string len = (txtlength.Text == "") ? "0" : txtlength.Text;
                    decimal fgwt = Convert.ToDecimal(fwt);
                    decimal thick = Convert.ToDecimal(thck);
                    decimal density = Convert.ToDecimal(den);
                    decimal length = Convert.ToDecimal(len);
                    //if (lenght != 0)
                    //{
                    decimal wt = (length * fgwt * thick * density)/1000000;
                    txtrmwt.Text = wt.ToString(".00");
                    //}
                    //else
                    //{
                    //    decimal le = Convert.ToDecimal(len);
                    //    decimal wt = (le * fgwt * thick * density);
                    //    txtrmwt.Text = wt.ToString(".00");
                    //}
                }

            
                else
                {

                }

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void txtod_Leave(object sender, EventArgs e)
        {
            try
            {
                if (cmbRmtype.Text == "Tubes")
                {
                    decimal od = (txtod.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtod.Text);
                    decimal thick = (cmbThickNo.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(cmbThickNo.Text);
                    decimal density = (txtDensity.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDensity.Text);
                    string len = (txtlength.Text == "") ? "0" : txtlength.Text;
                    if (lenght!=0)
                    {
                        decimal wt = (od - thick) * (thick * density)*lenght;
                        txtrmwt.Text = wt.ToString(".00");

                    }
                    else
                    {
                        decimal le = Convert.ToDecimal(len);
                        decimal wt = (od - thick) * (thick * density)*le;
                        txtrmwt.Text = wt.ToString(".00");

                    }

                }
                else if (cmbRmtype.Text == "Pipes")
                {
                    decimal od = (txtod.Text=="")?Convert.ToDecimal(0):Convert.ToDecimal(txtod.Text);
                    decimal thick = (cmbThickNo.Text=="")?Convert.ToDecimal(0):Convert.ToDecimal(cmbThickNo.Text);
                    decimal density =(txtDensity.Text=="")?Convert.ToDecimal(0): Convert.ToDecimal(txtDensity.Text);
                    string len = (txtlength.Text == "") ? "0" : txtlength.Text;
                    if (lenght !=0)
                    {
                        decimal wt = (od - thick) * (thick * density) * lenght;
                        txtrmwt.Text = wt.ToString(".00");

                    }
                    else
                    {
                        decimal le = Convert.ToDecimal(len);
                        decimal wt = (od - thick) * (thick * density) * le;
                        txtrmwt.Text = wt.ToString(".00");

                    }
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void BindUomMasterdata()
        {
            try
            {
                var sa = ((from k in db.UOM_Masters where k.CompId == "0001" select new { k.UOM_Name,k.UOM_Id })).ToList();
                if (sa.Count > 0)
                {
                    cmbUom.DataSource = sa;
                    cmbUom.DisplayMember = "UOM_Name";
                    cmbUom.ValueMember = "UOM_Id";
                    if (cmbUom.Items.Count > 0)
                    {
                        cmbUom.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbUom.SelectedIndex = -1;
                    }
                   
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        public void BindAssemblyMasterdata()
        {
            try
            {
                var sa = ((from k in db.SubAssembly_Masters where k.CompID == "0001" select new { k.Sub_Assembly_ID, k.Sub_Assembly_Name })).ToList();
                if (sa.Count > 0)
                {
                    cmbPartname.DataSource = sa;
                    cmbPartname.DisplayMember = "Sub_Assembly_Name";
                    cmbPartname.ValueMember = "Sub_Assembly_Name";
                    if (cmbPartname.Items.Count > 0)
                    {
                        cmbPartname.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbPartname.SelectedIndex = -1;
                    }

                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        /// UOM BUTTON CLICK EVENT
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Masters.UomMaster obj = new Masters.UomMaster();
                if (obj.ShowDialog() == DialogResult.Cancel)
                {
                    BindUomMasterdata();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void cmbPartGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void addItems(AutoCompleteStringCollection coll)
        {
            try
            {
                //int columnIndex = dgActivity.CurrentCell.ColumnIndex;
                //string columnName = dgActivity.Columns[columnIndex].HeaderText;
                //DataGridViewRow R1 = dgActivity.Rows[dgActivity.CurrentRow.Index];
                //if (columnName == "Activity Code")
                //{
                //    var d = (from c in db.Activity_Masters where c.CompID == "0001" select new { c.Activity_Code }).ToList();
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("d");
                //    foreach (var item in d)
                //    {
                //        dt.Rows.Add(item.Activity_Code);
                //    }
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //        coll.Add(dt.Rows[i][0].ToString());
                //    }
                //}
                //if (columnName == "Activity Name")
                //{
                //    var d = (from c in db.Activity_Masters where c.CompID == "0001" select new { c.Activity_Description }).ToList();
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("d");
                //    foreach (var item in d)
                //    {
                //        dt.Rows.Add(item.Activity_Description);
                //    }
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //        coll.Add(dt.Rows[i][0].ToString());
                //    }
                //}
                //if (columnName == "Work Center")
                //{
                //    var d = (from c in db.WorkCenters where c.CompID == "0001" select new { c.Work_Center_id }).ToList();
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("d");
                //    foreach (var item in d)
                //    {
                //        dt.Rows.Add(item.Work_Center_id);
                //    }
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //        coll.Add(dt.Rows[i][0].ToString());
                //    }
                //}
                ////
                //if (columnName == "Person Resp")
                //{
                //    var d = (from c in db.Resource_Masters where c.CompID == "0001" select new { c.Resource_Id }).ToList();
                //    DataTable dt = new DataTable();
                //    dt.Columns.Add("d");
                //    foreach (var item in d)
                //    {
                //        dt.Rows.Add(item.Resource_Id);
                //    }
                //    for (int i = 0; i < dt.Rows.Count; i++)
                //    {
                //        coll.Add(dt.Rows[i][0].ToString());
                //    }
                //}
            }
            catch (Exception ex)
            {
            }
        }

        private void dgActivity_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {    
                //int columnIndex = dgActivity.CurrentCell.ColumnIndex;
                //string columnName = dgActivity.Columns[columnIndex].HeaderText;
                //TextBox tb = e.Control as TextBox; ///Product Group
                //if ((tb != null && (columnName == "Activity Code"||columnName == "Activity Name"|| columnName == "Work Center"||columnName== "Person Resp")))
                //{
                //    tb.AutoCompleteMode = AutoCompleteMode.Suggest;
                //    tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                //    AutoCompleteStringCollection DataColl = new AutoCompleteStringCollection();
                //    addItems(DataColl);
                //    tb.AutoCompleteCustomSource = DataColl;
                //}
                //else
                //{
                //    tb.AutoCompleteMode = AutoCompleteMode.None;
                //}
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public string mainhh, mainmm;
       public int hours,TotalMM;
        public DateTime dt, dt1;
        public string Tthrs;
        private void dgActivity_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //DataGridViewRow R = dgActivity.Rows[dgActivity.CurrentRow.Index];
                //int columnIndex = dgActivity.CurrentCell.ColumnIndex;
                //string columnName = dgActivity.Columns[columnIndex].HeaderText;
                //if ("Activity Code" == columnName)
                //{
                //    var sa = (from k in db.Activity_Masters where k.CompID == "0001" && k.Activity_Code == R.Cells["Activity_Code"].Value.ToString() select k).ToList();
                //    if (sa.Count > 0)
                //    {
                //        string actdesc = sa[0].Activity_Description;
                //        string status = "Open";
                //        R.Cells["Activity_Description"].Value = actdesc;
                //        R.Cells["Status"].Value = status;
                //    }
                //    else
                //    {
                //        MessageBox.Show("Please Select Valid  Activity Code");
                //        R.Cells["Activity_Code"].Value = "";
                //        return;
                //    }
                //}
                //if ("Activity Name" == columnName)
                //{
                //    var sa = (from k in db.Activity_Masters where k.CompID == "0001" && k.Activity_Description == R.Cells["Activity_Description"].Value.ToString() select k).ToList();
                //    if (sa.Count > 0)
                //    {
                //        string actdesc = sa[0].Activity_Code;
                //        string status = "Open";
                //        R.Cells["Activity_Code"].Value = actdesc;
                //        R.Cells["Status"].Value = status;
                //    }
                //    else
                //    {
                //        MessageBox.Show("Please Select Valid  Activity Name");
                //        R.Cells["Activity_Description"].Value = "";
                //        return;
                //    }
                //}
              
                //if ("Planned Start Date" == columnName)
                //{

                //    if (R.Cells["Planned_StartDate"].Value == "" || R.Cells["Planned_StartDate"].Value == null)
                //    {
                //        MessageBox.Show("Please  Enter Planned Start Date..");

                //        return;

                //    }
                //    else
                //    {
                //        string Plstartdate = R.Cells["Planned_StartDate"].Value.ToString();
                //        var sa = (db.Sp_Bind_Dates("0001", R.Cells["Planned_StartDate"].Value.ToString(), R.Cells["Work_Center"].Value.ToString()));
                //        if (sa.Count() > 0)
                //        {
                //            MessageBox.Show("This Planning Date Already Assign...");
                //            R.Cells["Planned_StartDate"].Value = "";
                //            //dgActivity.CurrentCell = dgActivity.Rows[dgActivity.CurrentRow.Index].Cells["Planned_StartDate"];
                //            //dgActivity.CurrentCell.Selected = true;
                //            //dgActivity.BeginEdit(true);
                //            return;
                //            //dgActivity.Rows[dgActivity.CurrentRow.Index].Cells["Planned_StartDate"].Selected = true;
                //            //return;
                //        }
                //        else
                //        {
                //            ///.Columns[4].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss";
                //            dt = Convert.ToDateTime(R.Cells["Planned_StartDate"].Value);
                //            String formated = dt.ToString("yyyy/MM/dd HH:mm");
                //            R.Cells["Planned_StartDate"].Value = formated;
                //            String fromdate = formated.Substring(0, 4);
                //            String hh = formated.Substring(11, 2);
                //            String mm = formated.Substring(14, 2);
                //            string hhmm = hh + mm;
                //            hours = 2400 - Convert.ToInt32(hhmm);
                //            string hrs = hours.ToString();
                //            mainhh = hrs.Substring(0, 2);
                //            mainmm = hrs.Substring(2, 2);
                //            //  String makname = value.Substring(8, maknamelen);
                //            // String[] am = formated;
                //            //DateTime planstartdate = Convert.ToDateTime(R.Cells["Planned_StartDate"].Value);
                //            //string f1 = planstartdate.ToString("yyyyMMddHHmmss");
                //            //string sss = f1;
                //        }

                //    }

                //}
                //if ("Planned Completion Date" == columnName)
                //{

                //    if (R.Cells["Planned_CompletionDate"].Value == "" || R.Cells["Planned_CompletionDate"].Value == null)
                //    {
                //        MessageBox.Show("Please  Enter Planned Completion Date..");

                //        return;

                //    }
                //    else
                //    {
                //        string Plcomptdate = R.Cells["Planned_CompletionDate"].Value.ToString();
                //        var sa = (db.Sp_Bind_Dates("0001", R.Cells["Planned_CompletionDate"].Value.ToString(), R.Cells["Work_Center"].Value.ToString()));
                //        if (sa.Count() > 0)
                //        {
                //            MessageBox.Show("This Planning Date Already Assign...");
                //            R.Cells["Planned_CompletionDate"].Value = "";
                        

                //            return;
                //        }
                //        else
                //        {
                //            dt1 = Convert.ToDateTime(R.Cells["Planned_CompletionDate"].Value);
                //            string planningstart = dt.ToString();
                //            string planningenddate = dt1.ToString();
                //            if (dt1 >= dt)
                //            {
                //                string TotalHours = dt1.Subtract(dt).TotalHours.ToString();
                //                String planninstratMM = planningstart.Substring(14, 2);
                //                String plannineng = planningenddate.Substring(14, 2);
                //                char[] splitchar = { '.' };
                //                string[] strArr = TotalHours.Split(splitchar);
                //                if (1 == strArr.Length)
                //                {
                //                    Tthrs = TotalHours;

                //                }
                //                else
                //                {
                //                    for (int count = 0; count <= strArr.Length - 2; count++)
                //                    {
                //                        Tthrs = strArr[count];
                //                    }
                //                }
                //                if ((Convert.ToInt32(plannineng) >= Convert.ToInt32(planninstratMM)))
                //                {
                //                    TotalMM = Convert.ToInt32(plannineng) - Convert.ToInt32(planninstratMM);
                //                }
                //                else
                //                {
                //                    TotalMM = 60 - Convert.ToInt32(planninstratMM) + Convert.ToInt32(plannineng);

                //                }
                //                string Mints = Convert.ToString(TotalMM);
                //                string mins = dt1.Subtract(dt).TotalMinutes.ToString();
                //                string days = dt1.Subtract(dt).TotalDays.ToString();

                //                string TotalMins = dt1.Subtract(dt).TotalMinutes.ToString();
                //                if ("0." == TotalHours)
                //                {
                //                    R.Cells["Planned_Duration"].Value = 0 + ":" + TotalMM;
                //                }
                //                else
                //                {
                //                    R.Cells["Planned_Duration"].Value = Tthrs + ":" + TotalMM;
                //                }
                //            }
                //        }
                       
                //    }
                //    // ///.Columns[4].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss";
                //    //  dt1 = Convert.ToDateTime(R.Cells["Planned_CompletionDate"].Value);
                //    // String formated1 = dt1.ToString("yyyy/MM/dd HH:mm");
                //    // R.Cells["Planned_CompletionDate"].Value = formated1;
                //    // String fromdate1 = formated1.Substring(0, 4);
                //    // String hh1 = formated1.Substring(11, 2);
                //    // String mm1 = formated1.Substring(14, 2);
                //    // string hhmm1 = hh1 + mm1;
                //    // int hours1 = Convert.ToInt32(hhmm1);
                //    // int h = hours + hours1;
                //    // string h1 = h.ToString();
                //    // String planhh = h1.Substring(0, 2);
                //    // String Planmm = h1.Substring(2, 2);
                //    //  R.Cells["Planned_Duration"].Value=planhh+":"+Planmm;
                //    // if(dt1>=dt)
                //    // {
                //    //     string kk=  dt1.Subtract(dt).TotalHours.ToString();
                //    //     string ll = dt1.Subtract(dt).TotalMinutes.ToString();
                //    //     R.Cells["Planned_Duration"].Value=kk+":"+ll;
                //    // }
                //    // else
                //    // {
                //    //     if(dt.Hour>dt1.Hour)
                //    //     {
                //    //         string kk = dt1.Subtract(dt).TotalHours.ToString();
                //    //         string ll = dt1.Subtract(dt).TotalMinutes.ToString();
                //    //     }
                //    //     else
                //    //     {
                //    //         string ll = dt1.Subtract(dt).TotalMinutes.ToString();
                //    //     }

                //    // }
                //    //// DateTime dt11 = DateTime.ParseExact(time1, "HH:mm:ss", new DateTimeFormatInfo());
                //    // //DateTime dt2 = DateTime.ParseExact(time2, "HH:mm:ss", new DateTimeFormatInfo());
                //    // //TimeSpan ts = dt1.Subtract(dt);
                //    // //R.Cells["Planned_Duration"].Value = ts;
                //    // //DateTime planstartdate = Convert.ToDateTime(R.Cells["Planned_StartDate"].Value);
                //    // //string f1 = planstartdate.ToString("yyyyMMddHHmmss");
                //    // //string sss = f1;
                
            
                //}
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dgActivity_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
                {
            //DataGridViewRow R = dgActivity.Rows[dgActivity.CurrentRow.Index];
            //int columnIndex = dgActivity.CurrentCell.ColumnIndex;
            //string columnName = dgActivity.Columns[columnIndex].HeaderText;
            //if ("Planned Start Date" == columnName)
            //{               
            //    if (dgActivity.Columns[e.ColumnIndex].Name == "Planned_StartDate")
            //    {
            //        if (R.Cells["Activity_Code"].Value == "" || R.Cells["Activity_Code"].Value == null || R.Cells["Activity_Description"].Value == "" || R.Cells["Activity_Description"].Value == null)
            //        {
                       
            //        }
            //        else
            //        {

            //            if (e.FormattedValue == null || e.FormattedValue == "")
            //            {
            //                MessageBox.Show("Please Enter Planned Start Date..");
            //                e.Cancel = true;
            //            }
            //            else
            //            {
            //                e.Cancel = false;
            //            }
            //        }
            //    }                 

            //}
            //if ("Planned Completion Date" == columnName)
            //{
            //    if (R.Cells["Activity_Code"].Value == "" || R.Cells["Activity_Code"].Value == null || R.Cells["Activity_Description"].Value == "" || R.Cells["Activity_Description"].Value == null)
            //    {                    
                  
            //    }
            //    else
            //    {
            //        if (e.FormattedValue == null || e.FormattedValue == "")
            //        {
            //            MessageBox.Show("Please Enter Planned Completion Date..");
            //            e.Cancel = true;
            //        }
            //        else
            //        {
            //            e.Cancel = false;
            //        }
            //    }
            //}
           
        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            try
            {
                if((""==textBox1.Text.Trim())||(null==textBox1.Text.Trim()))
                {
                    MessageBox.Show("Please Enter Remarks...");
                    textBox1.Focus();
                    return;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                Masters.SubAssembly obj = new Masters.SubAssembly();
                if (obj.ShowDialog() == DialogResult.Cancel)
                {
                    BindAssemblyMasterdata();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgActivity_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgActivity_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            //for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
            //{
            //    string status = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
            //    if ("Open" == status)
            //    {

            //    }
            //    else if ("Closed" == status)
            //    {
            //        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
            //    }
            //    else if ("InProcess" == status)
            //    {
            //        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
            //    }
            //}
        }

        private void txtDia_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void txtmarkerno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtplno_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
