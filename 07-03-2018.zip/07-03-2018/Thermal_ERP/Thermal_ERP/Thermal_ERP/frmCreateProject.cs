﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmCreateProject : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        DataTable dt1, dt2,dt;
        public frmCreateProject()
        {
            InitializeComponent();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void Clear()
        {
            try
            {
                txtDescrption.Text = "";
                txtFinalClient.Text = "";
                txtLDfodelayd.Text = "";
                txtLDforDelDrawing.Text = "";
                txtProjectCode.Text = "";
                txtsplMatreq.Text = "";
                txtWarrantyPeriod.Text = "";
                cmbClient.Text = "";
                cmbCodeOfConstruction.Text = "";
                cmbCurrency.Text = "";
                cmbProjectClass.Text = "";
                cmbProjectSector.Text = "";
                dpdate.Value = DateTime.Now;
                chkASME.Checked = false;
                chkCEMarketing.Checked = false;
                chkCompDoscGost.Checked = false;
                chkComplocalreg.Checked = false;
                chkConcessReq.Checked = false;
                chkInspandAccpbyClient.Checked = false;
                chkInspbyAuth.Checked = false;
                chkinspbyCIB.Checked = false;
                chkInspByTPIA.Checked = false;
                chkNationalBoardreg.Checked = false;
                chkQAP.Checked = false;
                chkSplmatreq.Checked = false;
                if(dgEqup.Rows.Count>0)
                {
                    for (int i = 0; i < dgEqup.Rows.Count - 1; i++)
                    {
                        dgEqup.Rows.RemoveAt(i);
                        i--;
                        while (dgEqup.Rows.Count == 0)
                            continue;
                    }
                }
                if (dgPymentterms.Rows.Count > 0)
                {
                    for (int i = 0; i < dgPymentterms.Rows.Count - 1; i++)
                    {
                        dgPymentterms.Rows.RemoveAt(i);
                        i--;
                        while (dgPymentterms.Rows.Count == 0)
                            continue;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        // // Submit Click // //
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtProjectCode.Text == "" || txtProjectCode.Text == null)
                {
                    MessageBox.Show("Please Enter Product Code");
                    txtProjectCode.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Project_Masters where k.CompID == "0001" && k.Project_Code == txtProjectCode.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_ProjectMaster("0001", txtProjectCode.Text);
                        Project_Master p = new Project_Master();
                        p.Project_Code = (txtProjectCode.Text == "") ? "" : txtProjectCode.Text;
                        p.Project_Description = (txtDescrption.Text == "") ? "" : txtDescrption.Text;
                        p.Project_Client = (cmbClient.Text == "") ? "" : cmbClient.Text;
                        p.Project_Name = (txtFinalClient.Text == "") ? "" : txtFinalClient.Text;
                        p.Project_DeliveryDate = Convert.ToDateTime(dpdate.Value);                      
                        p.CompID = "0001";
                        db.Project_Masters.InsertOnSubmit(p);
                        db.SubmitChanges();
                        for (int i = 0; i < dgEqup.Rows.Count - 1; i++)
                        {
                            Project_Master_Child po = new Project_Master_Child();
                            po.Project_Code = txtProjectCode.Text;
                            po.Project_Equp_Name = (dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == "" || dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == null) ? "" : dgEqup.Rows[i].Cells["Project_Equp_Name"].Value.ToString();
                            po.Maker_No = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            string mkno= (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            po.Full_Project_Code = txtProjectCode.Text + "." + mkno;
                            po.CompID = "0001";
                            po.Modified_By = "";
                            po.Modified_On = DateTime.Now;
                            db.Project_Master_Childs.InsertOnSubmit(po);
                          
                        }
                        db.SubmitChanges();
                        for(int i=0;i<dgEqup.Rows.Count-1;i++)
                        {
                            Project_Structure_Main po = new Project_Structure_Main();
                            po.Project_Code = txtProjectCode.Text;
                            po.Maker_Name = (dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == "" || dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == null) ? "" : dgEqup.Rows[i].Cells["Project_Equp_Name"].Value.ToString();
                            po.Maker_No = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            string mkno = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            po.Full_Project_Code = txtProjectCode.Text + "." + mkno;
                            po.CompID = "0001";
                            po.Modified_By = "";
                            po.Modified_On = DateTime.Now;
                            db.Project_Structure_Mains.InsertOnSubmit(po);
                        }
                        db.SubmitChanges();
                        Project_Technical_Data pt = new Project_Technical_Data();
                        pt.Project_Code = txtProjectCode.Text;
                        pt.ProjectCodeConstruction = (cmbCodeOfConstruction.Text == "") ? "" : cmbCodeOfConstruction.Text;
                        pt.Special_Mtrl_Requ = (txtsplMatreq.Text == "") ? "" : txtsplMatreq.Text;
                        pt.Warranty_Period = (txtWarrantyPeriod.Text == "") ? "" : txtWarrantyPeriod.Text;
                        pt.Special_Mtrl_Requ_Chk = (chkSplmatreq.Checked == true) ? "Yes" : "No";
                        pt.CE_Marking = (chkCEMarketing.Checked == true) ? "Yes" : "No";
                        pt.Insp_TPIA = (chkInspByTPIA.Checked == true) ? "Yes" : "No";
                        pt.ASME_Code = (chkASME.Checked == true) ? "Yes" : "No";
                        pt.National_Board_Reg = (chkNationalBoardreg.Checked == true) ? "Yes" : "No";
                        pt.InspectonBy_CIB = (chkinspbyCIB.Checked == true) ? "Yes" : "No";
                        pt.Comp_With_Loc_Reg = (chkComplocalreg.Checked == true) ? "Yes" : "No";
                        pt.Comp_With_Doc_To_Gost = (chkCompDoscGost.Checked == true) ? "Yes" : "No";
                        pt.QAP_Approve = (chkQAP.Checked == true) ? "Yes" : "No";
                        pt.Insp_by_Auth_Insp = (chkInspbyAuth.Checked == true) ? "Yes" : "No";
                        pt.Insp_by_Accep_Client = (chkInspandAccpbyClient.Checked == true) ? "Yes" : "No";
                        pt.Concession_Requeist_Client = (chkConcessReq.Checked == true) ? "Yes" : "No";
                        pt.CompID = "0001";
                        db.Project_Technical_Datas.InsertOnSubmit(pt);
                        db.SubmitChanges();

                        Project_Commercial_Data pc = new Project_Commercial_Data();
                        pc.Project_Code = txtProjectCode.Text;
                        pc.Project_Clasificaton = (cmbProjectClass.Text == "") ? "" : cmbProjectClass.Text;
                        pc.Project_Sector = (cmbProjectSector.Text == "") ? "" : cmbProjectSector.Text;
                        pc.Project_Currency = (cmbCurrency.Text == "") ? "" : cmbCurrency.Text;
                        pc.LDfor_Delyed_Deliveryfor_Equp = (txtLDfodelayd.Text == "") ? "" : txtLDfodelayd.Text;
                        pc.LDfor_Delyed_Deliveryfor_Draw = (txtLDforDelDrawing.Text == "") ? "" : txtLDforDelDrawing.Text;
                        
                        pc.CompID = "0001";
                        db.Project_Commercial_Datas.InsertOnSubmit(pc);
                        db.SubmitChanges();
                        for (int i = 0; i < dgPymentterms.Rows.Count - 1; i++)
                        {
                            Project_Technical_Data_Child pi = new Project_Technical_Data_Child();
                            pi.Project_Code = txtProjectCode.Text;
                            pi.Mile_Stone = (dgPymentterms.Rows[i].Cells["Mile_Stone"].Value == "" || dgPymentterms.Rows[i].Cells["Mile_Stone"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["Mile_Stone"].Value.ToString();
                            pi.Per_Payments = (dgPymentterms.Rows[i].Cells["Per_Payments"].Value == "" || dgPymentterms.Rows[i].Cells["Per_Payments"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["Per_Payments"].Value.ToString();
                            pi.TriggeringPoint = (dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value == "" || dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value.ToString();
                            pi.CompID = "0001";
                            pi.Modigied_By = "";
                            pi.Modified_On = DateTime.Now;
                            db.Project_Technical_Data_Childs.InsertOnSubmit(pi);
                            
                        }
                        db.SubmitChanges();

                        MessageBox.Show("Recored Updated Successfully");
                        Clear();
                        return;
                    }
                    else
                    {
                        Project_Master p = new Project_Master();
                        p.Project_Code = (txtProjectCode.Text == "") ? "" : txtProjectCode.Text;
                        p.Project_Description = (txtDescrption.Text == "") ? "" : txtDescrption.Text;
                        p.Project_Client = (cmbClient.Text == "") ? "" : cmbClient.Text;
                        p.Project_Name = (txtFinalClient.Text == "") ? "" : txtFinalClient.Text;
                        p.Project_DeliveryDate = Convert.ToDateTime(dpdate.Value);
                        
                        p.CompID = "0001";
                        db.Project_Masters.InsertOnSubmit(p);
                        db.SubmitChanges();
                        for (int i = 0; i < dgEqup.Rows.Count - 1; i++)
                        {
                            Project_Master_Child po = new Project_Master_Child();
                            po.Project_Code = txtProjectCode.Text;
                            po.Project_Equp_Name = (dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == "" || dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == null) ? "" : dgEqup.Rows[i].Cells["Project_Equp_Name"].Value.ToString();
                            po.Maker_No = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            string mkno = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            po.Full_Project_Code = txtProjectCode.Text + "." + mkno;
                            po.CompID = "0001";
                            po.Created_By = "";
                            po.Created_On = DateTime.Now;
                            db.Project_Master_Childs.InsertOnSubmit(po);
                          
                        }
                        db.SubmitChanges();
                        for (int i = 0; i < dgEqup.Rows.Count - 1; i++)
                        {
                            Project_Structure_Main po = new Project_Structure_Main();
                            po.Project_Code = txtProjectCode.Text;
                            po.Maker_Name = (dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == "" || dgEqup.Rows[i].Cells["Project_Equp_Name"].Value == null) ? "" : dgEqup.Rows[i].Cells["Project_Equp_Name"].Value.ToString();
                            po.Maker_No = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            string mkno = (dgEqup.Rows[i].Cells["Maker_No"].Value == "" || dgEqup.Rows[i].Cells["Maker_No"].Value == null) ? "" : dgEqup.Rows[i].Cells["Maker_No"].Value.ToString();
                            po.Full_Project_Code = txtProjectCode.Text + "." + mkno;
                            po.CompID = "0001";
                            po.Modified_By = "";
                            po.Modified_On = DateTime.Now;
                            db.Project_Structure_Mains.InsertOnSubmit(po);
                        }
                        db.SubmitChanges();
                        Project_Technical_Data pt = new Project_Technical_Data();
                        pt.Project_Code = txtProjectCode.Text;
                        pt.ProjectCodeConstruction = (cmbCodeOfConstruction.Text == "") ? "" : cmbCodeOfConstruction.Text;
                        pt.Special_Mtrl_Requ = (txtsplMatreq.Text == "") ? "" : txtsplMatreq.Text;
                        pt.Special_Mtrl_Requ_Chk = (chkSplmatreq.Checked == true) ? "Yes" : "No";
                        pt.Warranty_Period = (txtWarrantyPeriod.Text == "") ? "" : txtWarrantyPeriod.Text;
                        pt.CE_Marking = (chkCEMarketing.Checked == true) ? "Yes" : "No";
                        pt.Insp_TPIA = (chkInspByTPIA.Checked == true) ? "Yes" : "No";
                        pt.ASME_Code = (chkASME.Checked == true) ? "Yes" : "No";
                        pt.National_Board_Reg = (chkNationalBoardreg.Checked == true) ? "Yes" : "No";
                        pt.InspectonBy_CIB = (chkinspbyCIB.Checked == true) ? "Yes" : "No";
                        pt.Comp_With_Loc_Reg = (chkComplocalreg.Checked == true) ? "Yes" : "No";
                        pt.Comp_With_Doc_To_Gost = (chkCompDoscGost.Checked == true) ? "Yes" : "No";
                        pt.QAP_Approve = (chkQAP.Checked == true) ? "Yes" : "No";
                        pt.Insp_by_Auth_Insp = (chkInspbyAuth.Checked == true) ? "Yes" : "No";
                        pt.Insp_by_Accep_Client = (chkInspandAccpbyClient.Checked == true) ? "Yes" : "No";
                        pt.Concession_Requeist_Client = (chkConcessReq.Checked == true) ? "Yes" : "No";
                        pt.CompID = "0001";
                        db.Project_Technical_Datas.InsertOnSubmit(pt);
                        db.SubmitChanges();

                        Project_Commercial_Data pc = new Project_Commercial_Data();
                        pc.Project_Code = txtProjectCode.Text;
                        pc.Project_Clasificaton = (cmbProjectClass.Text == "") ? "" : cmbProjectClass.Text;
                        pc.Project_Sector = (cmbProjectSector.Text == "") ? "" : cmbProjectSector.Text;
                        pc.Project_Currency = (cmbCurrency.Text == "") ? "" : cmbCurrency.Text;
                        pc.LDfor_Delyed_Deliveryfor_Equp = (txtLDfodelayd.Text == "") ? "" : txtLDfodelayd.Text;
                        pc.LDfor_Delyed_Deliveryfor_Draw = (txtLDforDelDrawing.Text == "") ? "" : txtLDforDelDrawing.Text;
                        
                        pc.CompID = "0001";
                        db.Project_Commercial_Datas.InsertOnSubmit(pc);
                        db.SubmitChanges();
                        for (int i = 0; i < dgPymentterms.Rows.Count - 1; i++)
                        {
                            Project_Technical_Data_Child pi = new Project_Technical_Data_Child();
                            pi.Project_Code = txtProjectCode.Text;
                            pi.Mile_Stone = (dgPymentterms.Rows[i].Cells["Mile_Stone"].Value == "" || dgPymentterms.Rows[i].Cells["Mile_Stone"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["Mile_Stone"].Value.ToString();
                            pi.Per_Payments = (dgPymentterms.Rows[i].Cells["Per_Payments"].Value == "" || dgPymentterms.Rows[i].Cells["Per_Payments"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["Per_Payments"].Value.ToString();
                            pi.TriggeringPoint = (dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value == "" || dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value == null) ? "" : dgPymentterms.Rows[i].Cells["TriggeringPoint"].Value.ToString();
                            pi.CompID = "0001";
                            pi.Created_By = "";
                            pi.Created_On = DateTime.Now;
                            db.Project_Technical_Data_Childs.InsertOnSubmit(pi);
                           
                        }
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Successfully");
                        Clear();
                        return;
                    }
                    //project_MasterTableAdapter.DeleteProject(textBox1.Text);
                    //project_MasterTableAdapter.InsertProject(textBox1.Text, textBox2.Text, comboBox1.Text, dateTimePicker1.Value, "0001");
                }
            }
            catch (Exception ex)
            {

                throw;
            }
          
        }

        private void project_MasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.project_MasterBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.thermal_PMSDataSet);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are You Sure Want to Delete this Record ", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    db.Sp_Delete_ProjectMaster("0001", txtProjectCode.Text);
                    Clear();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void txtProjectCode_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Project_Masters where k.CompID == "0001" && k.Project_Code == txtProjectCode.Text.Trim() select k).ToList();
                if(sa.Count>0)
                {
                    MessageBox.Show("This Project Code is Already Existing..  Please Enter Another Code");
                    txtProjectCode.Clear();
                    txtProjectCode.Focus();
                    return;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void frmCreateProject_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmProjectList.Name = "";
        }
        public void addItems(AutoCompleteStringCollection coll)
        {
            try
            {
                int columnIndex = dgEqup.CurrentCell.ColumnIndex;
                string columnName = dgEqup.Columns[columnIndex].HeaderText;
                DataGridViewRow R1 = dgEqup.Rows[dgEqup.CurrentRow.Index];
                if (columnName == "Description of Item")
                {
                    var d = (from c in db.Maker_Masters where c.CompID == "0001" select new { c.Maker_Description }).ToList();
                    DataTable dt = new DataTable();
                    dt.Columns.Add("d");
                    foreach (var item in d)
                    {
                        dt.Rows.Add(item.Maker_Description);
                    }
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        coll.Add(dt.Rows[i][0].ToString());
                    }
                }              

            }
            catch (Exception ex)
            {
            }
        }
        private void dgEqup_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                int columnIndex = dgEqup.CurrentCell.ColumnIndex;
                string columnName = dgEqup.Columns[columnIndex].HeaderText;
                TextBox tb = e.Control as TextBox; ///Product Group
                if ((tb != null && (columnName == "Description of Item")))
                {
                    tb.AutoCompleteMode = AutoCompleteMode.Suggest;
                    tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    AutoCompleteStringCollection DataColl = new AutoCompleteStringCollection();
                    addItems(DataColl);
                    tb.AutoCompleteCustomSource = DataColl;
                }
                else
                {
                    tb.AutoCompleteMode = AutoCompleteMode.None;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void dgEqup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dgEqup.Rows.Count > 1)
                {
                    if (dgEqup.Rows[dgEqup.CurrentRow.Index].Cells[dgEqup.CurrentCell.ColumnIndex].Value == "Remove")
                    {
                        if (dgEqup.Rows.Count > 0)
                        {
                            foreach (DataGridViewCell oneCell in dgEqup.SelectedCells)
                            {
                                if (oneCell.Selected)
                                    dgEqup.Rows.RemoveAt(oneCell.RowIndex);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dgEqup_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //DataGridViewRow R = dgEqup.Rows[dgEqup.CurrentRow.Index];
                //int columnIndex = dgEqup.CurrentCell.ColumnIndex;
                //string columnName = dgEqup.Columns[columnIndex].HeaderText;
                //if ("Description of Item" == columnName)
                //{
                //    var sa = (from k in db.Maker_Masters where k.CompID == "0001" && k.Maker_Description == R.Cells["Project_Equp_Name"].Value select new { k.Maker_No }).ToList();
                //    if (sa.Count > 0)
                //    {
                //        string makno = sa[0].Maker_No;
                //        R.Cells["Maker_No"].Value = makno;
                //    }
                

                //}
                 
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void frmCreateProject_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Project_Master' table. You can move, or remove it, as needed.
            // this.project_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Project_Master);
            var saa = (from h in db.Customer_Masters where h.CompID == "0001" select new { h.Customer_Id, h.Customer_Name }).ToList();
            if(saa.Count>0)
            {
                cmbClient.DataSource = saa;
                cmbClient.DisplayMember = "Customer_Name";
                cmbClient.ValueMember = "Customer_Id";
                if(cmbClient.Items.Count>0)
                {
                    cmbClient.SelectedIndex = -1;
                }
                else
                {
                    cmbClient.SelectedIndex = -1;
                }
            }
           if("FrmProjects" == frmProjectList.Name)
            {
                var sa = (from k in db.Project_Masters where k.CompID == "0001" && k.Project_Code==frmProjectList.projectcode select k).ToList();
                if (sa.Count > 0)
                {
                    txtProjectCode.Text = sa[0].Project_Code;
                    txtDescrption.Text = sa[0].Project_Description;
                    cmbClient.Text = sa[0].Project_Client;
                    txtFinalClient.Text = sa[0].Project_Name;
                    dpdate.Value = Convert.ToDateTime(sa[0].Project_DeliveryDate);
                }
                var s = (from k in db.Project_Master_Childs where k.CompID == "0001" && k.Project_Code == frmProjectList.projectcode select new { k.Maker_No, k.Project_Equp_Name });
                SqlCommand cmd2 = (SqlCommand)db.GetCommand(s);
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                dt1 = new DataTable();
                da2.Fill(dt1);
                if( dt1.Rows.Count > 0)
                {
                  //  dt1.Rows.Add();
                    dgEqup.DataSource = dt1;
                }
                else
                {
                    int n =  1;
                    for (int i = dt1.Rows.Count; i < n; i++)
                 //       dt1.Rows.Add();
                    dgEqup.DataSource = dt1;
                }
                var sa1 = (from k in db.Project_Technical_Datas where k.CompID == "0001" && k.Project_Code == frmProjectList.projectcode select k).ToList();
                if (sa1.Count > 0)
                {
                    cmbCodeOfConstruction.Text = sa1[0].ProjectCodeConstruction;
                    if (sa1[0].Special_Mtrl_Requ_Chk == "Yes")
                    {
                        chkSplmatreq.Checked = true;
                    }
                    else
                    {
                        chkSplmatreq.Checked = false;
                    }
                    txtsplMatreq.Text = sa1[0].Special_Mtrl_Requ;
                    txtWarrantyPeriod.Text = sa1[0].Warranty_Period;
                    if (sa1[0].CE_Marking == "Yes")
                    {
                        chkCEMarketing.Checked = true;
                    }
                    else
                    {
                        chkCEMarketing.Checked = false;
                    }
                    if (sa1[0].ASME_Code == "Yes")
                    {
                        chkASME.Checked = true;
                    }
                    else
                    {
                        chkASME.Checked = false;
                    }
                    if (sa1[0].National_Board_Reg == "Yes")
                    {
                        chkNationalBoardreg.Checked = true;
                    }
                    else
                    {
                        chkNationalBoardreg.Checked = false;
                    }
                    if (sa1[0].InspectonBy_CIB == "Yes")
                    {
                        chkinspbyCIB.Checked = true;
                    }
                    else
                    {
                        chkinspbyCIB.Checked = false;
                    }
                    if (sa1[0].Comp_With_Loc_Reg == "Yes")
                    {
                        chkComplocalreg.Checked = true;
                    }
                    else
                    {
                        chkComplocalreg.Checked = false;
                    }
                    if (sa1[0].Comp_With_Doc_To_Gost == "Yes")
                    {
                        chkCompDoscGost.Checked = true;
                    }
                    else
                    {
                        chkCompDoscGost.Checked = false;
                    }
                        if (sa1[0].QAP_Approve == "Yes")
                        {
                            chkQAP.Checked = true;
                        }
                        else
                        {
                            chkQAP.Checked = false;
                        }
                        if (sa1[0].Insp_by_Auth_Insp == "Yes")
                        {
                            chkInspbyAuth.Checked = true;
                        }
                        else
                        {
                            chkInspbyAuth.Checked = false;
                        }
                    if (sa1[0].Insp_by_Accep_Client == "Yes")
                    {
                        chkInspandAccpbyClient.Checked = true;
                    }
                    else
                    {
                        chkInspandAccpbyClient.Checked = false;
                    }
                    if (sa1[0].Concession_Requeist_Client == "Yes")
                    {
                        chkConcessReq.Checked = true;
                    }
                    else
                    {
                        chkConcessReq.Checked = false;
                    }
                }
                
                var sa2= (from k in db.Project_Commercial_Datas where k.CompID == "0001" && k.Project_Code == frmProjectList.projectcode select k).ToList();
                if(sa2.Count>0)
                {
                    cmbProjectClass.Text = sa2[0].Project_Clasificaton;
                    cmbProjectSector.Text = sa2[0].Project_Sector;
                    cmbCurrency.Text = sa2[0].Project_Currency;
                    txtLDfodelayd.Text = sa2[0].LDfor_Delyed_Deliveryfor_Equp;
                    txtLDforDelDrawing.Text = sa2[0].LDfor_Delyed_Deliveryfor_Draw;

                }
                var sa3 = (from k in db.Project_Technical_Data_Childs where k.CompID == "0001" && k.Project_Code == frmProjectList.projectcode select new { k.Mile_Stone,k.Per_Payments,k.TriggeringPoint});
                SqlCommand cmd = (SqlCommand)db.GetCommand(sa3);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                if (sa3.Count() > 0)
                {
                   // dt.Rows.Add();
                    dgPymentterms.DataSource = dt;
                }
                else
                {
                    int n =  1;
                    for (int i = dt.Rows.Count; i < n; i++)
                  //      dt.Rows.Add();
                    dgPymentterms.DataSource = dt;
                }
                txtDescrption.Focus();
            }
           else
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmProjectList.Name = "";
            this.Close();
        }
    }
}
