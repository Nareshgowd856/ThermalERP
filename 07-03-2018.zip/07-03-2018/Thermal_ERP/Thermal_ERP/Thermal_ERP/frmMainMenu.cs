﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Thermal_ERP
{
    public partial class frmMainMenu : Form
    {
        private Button button1;

        public frmMainMenu()
        {
            InitializeComponent();
        }

        private void newProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void newMakerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMakers frm = new frmMakers();
            frm.Show();

        }

        private void newAPGGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAPGMaster frm = new frmAPGMaster();
            frm.Show();
        }

        private void activityMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmActivityMaster frm = new frmActivityMaster();
            frm.Show();
        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Image = global::Thermal_ERP.Properties.Resources.eNGG_iMAGE1;
            this.button1.Location = new System.Drawing.Point(146, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 108);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmMainMenu
            // 
            this.ClientSize = new System.Drawing.Size(881, 449);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thermal_ERP_GateWay frm = new Thermal_ERP_GateWay();
            //frm.MdiParent = this;
            //this.Close();
            frm.Show();
        }
    }
}
