﻿namespace Thermal_ERP
{
    partial class frmMaterialGrades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbmaterialgroup = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbcolorcode = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDensity = new System.Windows.Forms.TextBox();
            this.txtmaterialgrade = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtmeterialid = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.material_GradesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.material_GradesTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter();
            this.tableAdapterManager = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.TableAdapterManager();
            this.material_GradesDataGridView = new System.Windows.Forms.DataGridView();
            this.Spec_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Material_Group = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Material_Grad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Material_Color = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Material_Density = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.material_GradesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.material_GradesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(821, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "MATERIAL GRADES";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbmaterialgroup, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbcolorcode, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDensity, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtmaterialgrade, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtmeterialid, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(424, 46);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(575, 107);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Material Group";
            // 
            // cmbmaterialgroup
            // 
            this.cmbmaterialgroup.FormattingEnabled = true;
            this.cmbmaterialgroup.Items.AddRange(new object[] {
            "Steel",
            "Aluminum",
            "Ferrous ",
            "Non Ferrous",
            "Spl Steel"});
            this.cmbmaterialgroup.Location = new System.Drawing.Point(108, 3);
            this.cmbmaterialgroup.Name = "cmbmaterialgroup";
            this.cmbmaterialgroup.Size = new System.Drawing.Size(137, 25);
            this.cmbmaterialgroup.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(251, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Material Grade";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Color Code";
            // 
            // cmbcolorcode
            // 
            this.cmbcolorcode.FormattingEnabled = true;
            this.cmbcolorcode.Items.AddRange(new object[] {
            "Red",
            "White",
            "Blue",
            "Yellow",
            "Orange"});
            this.cmbcolorcode.Location = new System.Drawing.Point(108, 39);
            this.cmbcolorcode.Name = "cmbcolorcode";
            this.cmbcolorcode.Size = new System.Drawing.Size(121, 25);
            this.cmbcolorcode.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(251, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Density";
            // 
            // txtDensity
            // 
            this.txtDensity.Location = new System.Drawing.Point(354, 39);
            this.txtDensity.Name = "txtDensity";
            this.txtDensity.Size = new System.Drawing.Size(100, 25);
            this.txtDensity.TabIndex = 7;
            // 
            // txtmaterialgrade
            // 
            this.txtmaterialgrade.Location = new System.Drawing.Point(354, 3);
            this.txtmaterialgrade.Name = "txtmaterialgrade";
            this.txtmaterialgrade.Size = new System.Drawing.Size(115, 25);
            this.txtmaterialgrade.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(475, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Attach Std.";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // txtmeterialid
            // 
            this.txtmeterialid.Location = new System.Drawing.Point(108, 75);
            this.txtmeterialid.Name = "txtmeterialid";
            this.txtmeterialid.Size = new System.Drawing.Size(100, 25);
            this.txtmeterialid.TabIndex = 10;
            this.txtmeterialid.Leave += new System.EventHandler(this.txtmeterialid_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Material Id";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(481, 159);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(255, 193);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chemical Properties";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 24);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView2);
            this.groupBox2.Location = new System.Drawing.Point(742, 160);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 193);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Mechanical Properties";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 24);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkedListBox1);
            this.groupBox3.Location = new System.Drawing.Point(481, 360);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(255, 169);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Applicable / Equvilent Standards";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(20, 31);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(229, 124);
            this.checkedListBox1.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Red;
            this.button8.Location = new System.Drawing.Point(924, 526);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(74, 28);
            this.button8.TabIndex = 9;
            this.button8.Text = "Close";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Red;
            this.button7.Location = new System.Drawing.Point(844, 526);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(74, 28);
            this.button7.TabIndex = 8;
            this.button7.Text = "Submit";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Red;
            this.button6.Location = new System.Drawing.Point(764, 526);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(74, 28);
            this.button6.TabIndex = 7;
            this.button6.Text = "Reset";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // material_GradesBindingSource
            // 
            this.material_GradesBindingSource.DataMember = "Material_Grades";
            this.material_GradesBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // material_GradesTableAdapter
            // 
            this.material_GradesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.Activity_MasterTableAdapter = null;
            this.tableAdapterManager.APG_MasterTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Item_MasterTableAdapter = null;
            this.tableAdapterManager.Maker_MasterTableAdapter = null;
            this.tableAdapterManager.Material_GradesTableAdapter = this.material_GradesTableAdapter;
            this.tableAdapterManager.Project_MasterTableAdapter = null;
            this.tableAdapterManager.Project_StructureTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Thermal_ERP.Thermal_PMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // material_GradesDataGridView
            // 
            this.material_GradesDataGridView.AutoGenerateColumns = false;
            this.material_GradesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.material_GradesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Spec_Code,
            this.Material_Group,
            this.Material_Grad,
            this.Material_Color,
            this.Material_Density});
            this.material_GradesDataGridView.DataSource = this.material_GradesBindingSource;
            this.material_GradesDataGridView.Location = new System.Drawing.Point(12, 46);
            this.material_GradesDataGridView.Name = "material_GradesDataGridView";
            this.material_GradesDataGridView.Size = new System.Drawing.Size(406, 455);
            this.material_GradesDataGridView.TabIndex = 11;
            this.material_GradesDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.material_GradesDataGridView_CellDoubleClick);
            // 
            // Spec_Code
            // 
            this.Spec_Code.DataPropertyName = "Spec_Code";
            this.Spec_Code.HeaderText = "Material Id";
            this.Spec_Code.Name = "Spec_Code";
            // 
            // Material_Group
            // 
            this.Material_Group.DataPropertyName = "Material_Group";
            this.Material_Group.HeaderText = "Material_Group";
            this.Material_Group.Name = "Material_Group";
            // 
            // Material_Grad
            // 
            this.Material_Grad.DataPropertyName = "Material_Grad";
            this.Material_Grad.HeaderText = "Material Grade";
            this.Material_Grad.Name = "Material_Grad";
            // 
            // Material_Color
            // 
            this.Material_Color.DataPropertyName = "Material_Color";
            this.Material_Color.HeaderText = "Material_Color";
            this.Material_Color.Name = "Material_Color";
            // 
            // Material_Density
            // 
            this.Material_Density.DataPropertyName = "Material_Density";
            this.Material_Density.HeaderText = "Material_Density";
            this.Material_Density.Name = "Material_Density";
            // 
            // frmMaterialGrades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.material_GradesDataGridView);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmMaterialGrades";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMaterialGrades";
            this.Load += new System.EventHandler(this.frmMaterialGrades_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.material_GradesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.material_GradesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbmaterialgroup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbcolorcode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDensity;
        private System.Windows.Forms.TextBox txtmaterialgrade;
        private System.Windows.Forms.Button button1;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource material_GradesBindingSource;
        private Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter material_GradesTableAdapter;
        private Thermal_PMSDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView material_GradesDataGridView;
        private System.Windows.Forms.TextBox txtmeterialid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Spec_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Material_Group;
        private System.Windows.Forms.DataGridViewTextBoxColumn Material_Grad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Material_Color;
        private System.Windows.Forms.DataGridViewTextBoxColumn Material_Density;
        private System.Windows.Forms.Label label6;
    }
}