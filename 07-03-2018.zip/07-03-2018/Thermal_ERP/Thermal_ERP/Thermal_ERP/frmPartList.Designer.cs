﻿namespace Thermal_ERP
{
    partial class frmPartList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbAPGNo = new System.Windows.Forms.ComboBox();
            this.cmbMakerNo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtprojectCode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtdrawno = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtrevno = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtpartlistno = new System.Windows.Forms.TextBox();
            this.txteqpno = new System.Windows.Forms.TextBox();
            this.txtmakerno = new System.Windows.Forms.TextBox();
            this.txtapgno = new System.Windows.Forms.TextBox();
            this.dgpartlist = new System.Windows.Forms.DataGridView();
            this.DUNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Sl_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Shape = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Size = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Spec_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Fg_wt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Rm_Wt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_D_Wt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShopFloor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PtsRefNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MTONo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Desription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Engg_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.btnModify = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.twPartlist = new System.Windows.Forms.TreeView();
            this.btnClose = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSearchProject = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpartlist)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(1242, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "PART LIST";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 11;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 226F));
            this.tableLayoutPanel1.Controls.Add(this.cmbAPGNo, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbMakerNo, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtprojectCode, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtdrawno, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label14, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label16, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtrevno, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtpartlistno, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.txteqpno, 7, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(313, 48);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 44F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1048, 67);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // cmbAPGNo
            // 
            this.cmbAPGNo.FormattingEnabled = true;
            this.cmbAPGNo.Location = new System.Drawing.Point(512, 3);
            this.cmbAPGNo.Name = "cmbAPGNo";
            this.cmbAPGNo.Size = new System.Drawing.Size(121, 25);
            this.cmbAPGNo.TabIndex = 2;
            this.cmbAPGNo.Leave += new System.EventHandler(this.cmbAPGNo_Leave);
            // 
            // cmbMakerNo
            // 
            this.cmbMakerNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbMakerNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMakerNo.FormattingEnabled = true;
            this.cmbMakerNo.Location = new System.Drawing.Point(285, 3);
            this.cmbMakerNo.Name = "cmbMakerNo";
            this.cmbMakerNo.Size = new System.Drawing.Size(121, 25);
            this.cmbMakerNo.TabIndex = 1;
            this.cmbMakerNo.Leave += new System.EventHandler(this.cmbMakerNo_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Project Code";
            // 
            // txtprojectCode
            // 
            this.txtprojectCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtprojectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtprojectCode.Location = new System.Drawing.Point(94, 3);
            this.txtprojectCode.Name = "txtprojectCode";
            this.txtprojectCode.Size = new System.Drawing.Size(100, 25);
            this.txtprojectCode.TabIndex = 0;
            this.txtprojectCode.Leave += new System.EventHandler(this.txtprojectCode_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Drawing No";
            // 
            // txtdrawno
            // 
            this.txtdrawno.Location = new System.Drawing.Point(94, 32);
            this.txtdrawno.Name = "txtdrawno";
            this.txtdrawno.Size = new System.Drawing.Size(100, 25);
            this.txtdrawno.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(412, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Status";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Create",
            "Relesed for Review",
            "Reviewed",
            "Under Revision",
            "Approved"});
            this.comboBox1.Location = new System.Drawing.Point(512, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(96, 25);
            this.comboBox1.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(200, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 17);
            this.label14.TabIndex = 14;
            this.label14.Text = "Maker No";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(412, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 17);
            this.label16.TabIndex = 10;
            this.label16.Text = "APG/EQUIP ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(639, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Rev No";
            // 
            // txtrevno
            // 
            this.txtrevno.Location = new System.Drawing.Point(759, 32);
            this.txtrevno.Name = "txtrevno";
            this.txtrevno.Size = new System.Drawing.Size(100, 25);
            this.txtrevno.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(865, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Rev Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(933, 32);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(132, 25);
            this.dateTimePicker1.TabIndex = 8;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(200, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "Part List No";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(639, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Equipment Name";
            // 
            // txtpartlistno
            // 
            this.txtpartlistno.Location = new System.Drawing.Point(285, 32);
            this.txtpartlistno.Name = "txtpartlistno";
            this.txtpartlistno.Size = new System.Drawing.Size(67, 25);
            this.txtpartlistno.TabIndex = 5;
            // 
            // txteqpno
            // 
            this.txteqpno.Location = new System.Drawing.Point(759, 3);
            this.txteqpno.Name = "txteqpno";
            this.txteqpno.Size = new System.Drawing.Size(100, 25);
            this.txteqpno.TabIndex = 3;
            // 
            // txtmakerno
            // 
            this.txtmakerno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtmakerno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtmakerno.Location = new System.Drawing.Point(616, 12);
            this.txtmakerno.Name = "txtmakerno";
            this.txtmakerno.Size = new System.Drawing.Size(67, 25);
            this.txtmakerno.TabIndex = 2;
            this.txtmakerno.Visible = false;
            this.txtmakerno.Leave += new System.EventHandler(this.txtmakerno_Leave);
            // 
            // txtapgno
            // 
            this.txtapgno.Location = new System.Drawing.Point(832, 15);
            this.txtapgno.Name = "txtapgno";
            this.txtapgno.Size = new System.Drawing.Size(74, 25);
            this.txtapgno.TabIndex = 3;
            this.txtapgno.Visible = false;
            // 
            // dgpartlist
            // 
            this.dgpartlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgpartlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DUNO,
            this.Part_Sl_No,
            this.ItemDesc,
            this.Shape,
            this.Size,
            this.Part_Spec_Id,
            this.Qty,
            this.Part_Fg_wt,
            this.Part_Rm_Wt,
            this.Part_D_Wt,
            this.ShopFloor,
            this.PtsRefNo,
            this.MTONo,
            this.Version_No,
            this.Version_Date,
            this.Part_Desription,
            this.Part_Engg_Code,
            this.Status});
            this.dgpartlist.Location = new System.Drawing.Point(330, 121);
            this.dgpartlist.Name = "dgpartlist";
            this.dgpartlist.Size = new System.Drawing.Size(1048, 447);
            this.dgpartlist.TabIndex = 0;
            this.dgpartlist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dgpartlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridView1_EditingControlShowing);
            this.dgpartlist.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgpartlist_RowPostPaint);
            this.dgpartlist.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView1_KeyDown);
            // 
            // DUNO
            // 
            this.DUNO.DataPropertyName = "DUNO";
            this.DUNO.HeaderText = "DU No";
            this.DUNO.Name = "DUNO";
            this.DUNO.Width = 50;
            // 
            // Part_Sl_No
            // 
            this.Part_Sl_No.DataPropertyName = "Part_Sl_No";
            this.Part_Sl_No.HeaderText = "P No";
            this.Part_Sl_No.Name = "Part_Sl_No";
            this.Part_Sl_No.Width = 50;
            // 
            // ItemDesc
            // 
            this.ItemDesc.DataPropertyName = "ItemDesc";
            this.ItemDesc.HeaderText = "Item Description";
            this.ItemDesc.Name = "ItemDesc";
            this.ItemDesc.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemDesc.Width = 200;
            // 
            // Shape
            // 
            this.Shape.DataPropertyName = "Shape";
            this.Shape.HeaderText = "Shape";
            this.Shape.Name = "Shape";
            // 
            // Size
            // 
            this.Size.DataPropertyName = "Size";
            this.Size.HeaderText = "Size / Spec";
            this.Size.Name = "Size";
            this.Size.Width = 150;
            // 
            // Part_Spec_Id
            // 
            this.Part_Spec_Id.DataPropertyName = "Part_Spec_Id";
            this.Part_Spec_Id.HeaderText = "Material Spec";
            this.Part_Spec_Id.Name = "Part_Spec_Id";
            // 
            // Qty
            // 
            this.Qty.DataPropertyName = "Qty";
            this.Qty.HeaderText = "Qty in Nos";
            this.Qty.Name = "Qty";
            this.Qty.Width = 50;
            // 
            // Part_Fg_wt
            // 
            this.Part_Fg_wt.DataPropertyName = "Part_Fg_wt";
            this.Part_Fg_wt.HeaderText = "Finished Wt";
            this.Part_Fg_wt.Name = "Part_Fg_wt";
            this.Part_Fg_wt.ReadOnly = true;
            this.Part_Fg_wt.Width = 50;
            // 
            // Part_Rm_Wt
            // 
            this.Part_Rm_Wt.DataPropertyName = "Part_Rm_Wt";
            this.Part_Rm_Wt.HeaderText = "RM Wt";
            this.Part_Rm_Wt.Name = "Part_Rm_Wt";
            this.Part_Rm_Wt.ReadOnly = true;
            this.Part_Rm_Wt.Width = 50;
            // 
            // Part_D_Wt
            // 
            this.Part_D_Wt.DataPropertyName = "Part_D_Wt";
            this.Part_D_Wt.HeaderText = "Demand Wt";
            this.Part_D_Wt.Name = "Part_D_Wt";
            this.Part_D_Wt.ReadOnly = true;
            this.Part_D_Wt.Width = 60;
            // 
            // ShopFloor
            // 
            this.ShopFloor.DataPropertyName = "ShopFloor";
            this.ShopFloor.HeaderText = "Shop Floor Dwg. No";
            this.ShopFloor.Name = "ShopFloor";
            this.ShopFloor.ReadOnly = true;
            // 
            // PtsRefNo
            // 
            this.PtsRefNo.DataPropertyName = "PtsRefNo";
            this.PtsRefNo.HeaderText = "PTS Ref No";
            this.PtsRefNo.Name = "PtsRefNo";
            this.PtsRefNo.ReadOnly = true;
            // 
            // MTONo
            // 
            this.MTONo.DataPropertyName = "MTONo";
            this.MTONo.HeaderText = "MTO No";
            this.MTONo.Name = "MTONo";
            this.MTONo.ReadOnly = true;
            // 
            // Version_No
            // 
            this.Version_No.DataPropertyName = "Version_No";
            this.Version_No.HeaderText = "Rev No";
            this.Version_No.Name = "Version_No";
            // 
            // Version_Date
            // 
            this.Version_Date.DataPropertyName = "Version_Date";
            this.Version_Date.HeaderText = "Rev Date";
            this.Version_Date.Name = "Version_Date";
            // 
            // Part_Desription
            // 
            this.Part_Desription.DataPropertyName = "Part_Desription";
            this.Part_Desription.HeaderText = "Special Note / Remarks";
            this.Part_Desription.Name = "Part_Desription";
            this.Part_Desription.ReadOnly = true;
            this.Part_Desription.Width = 200;
            // 
            // Part_Engg_Code
            // 
            this.Part_Engg_Code.DataPropertyName = "Part_Engg_Code";
            this.Part_Engg_Code.HeaderText = "Part_Engg_Code";
            this.Part_Engg_Code.Name = "Part_Engg_Code";
            this.Part_Engg_Code.Visible = false;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(330, 574);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 25);
            this.button1.TabIndex = 1;
            this.button1.Text = "Add Part";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnModify
            // 
            this.btnModify.BackColor = System.Drawing.Color.White;
            this.btnModify.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModify.ForeColor = System.Drawing.Color.Red;
            this.btnModify.Location = new System.Drawing.Point(441, 574);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(111, 25);
            this.btnModify.TabIndex = 2;
            this.btnModify.Text = "Modify Part";
            this.btnModify.UseVisualStyleBackColor = false;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(552, 574);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 25);
            this.button3.TabIndex = 3;
            this.button3.Text = "Delete / Cancel";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(774, 574);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(111, 25);
            this.button4.TabIndex = 5;
            this.button4.Text = "Generate MRP";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(1113, 574);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 89);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color Legend";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.IndianRed;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(131, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 17);
            this.label12.TabIndex = 3;
            this.label12.Text = "Cancel/Hold";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.OrangeRed;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Under Revision";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Turquoise;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(131, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 17);
            this.label10.TabIndex = 1;
            this.label10.Text = "Revised";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.LightGreen;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(15, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "New Addition";
            // 
            // twPartlist
            // 
            this.twPartlist.Location = new System.Drawing.Point(2, 101);
            this.twPartlist.Name = "twPartlist";
            this.twPartlist.Size = new System.Drawing.Size(305, 562);
            this.twPartlist.TabIndex = 7;
            this.twPartlist.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.twPartlist_AfterSelect);
            this.twPartlist.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.twPartlist_NodeMouseClick);
            this.twPartlist.DoubleClick += new System.EventHandler(this.twPartlist_DoubleClick);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(885, 574);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(111, 25);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(99, 9);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 25);
            this.comboBox3.TabIndex = 11;
            this.comboBox3.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(996, 574);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 25);
            this.button2.TabIndex = 12;
            this.button2.Text = "Refresh";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 17);
            this.label8.TabIndex = 13;
            this.label8.Text = "Search Project";
            // 
            // txtSearchProject
            // 
            this.txtSearchProject.Location = new System.Drawing.Point(109, 56);
            this.txtSearchProject.Name = "txtSearchProject";
            this.txtSearchProject.Size = new System.Drawing.Size(111, 25);
            this.txtSearchProject.TabIndex = 14;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(226, 59);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 15;
            this.button5.Text = "Get Data";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Red;
            this.button6.Location = new System.Drawing.Point(663, 574);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(111, 25);
            this.button6.TabIndex = 16;
            this.button6.Text = "Print";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(336, 625);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 17);
            this.label15.TabIndex = 17;
            this.label15.Text = "Prepared By";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(540, 625);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(138, 17);
            this.label17.TabIndex = 18;
            this.label17.Text = "Checked /Reviewed By";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(796, 625);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 17);
            this.label18.TabIndex = 19;
            this.label18.Text = "Approved By";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(421, 625);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 20;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(684, 625);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 25);
            this.textBox2.TabIndex = 21;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(885, 625);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 25);
            this.textBox3.TabIndex = 22;
            // 
            // frmPartList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 677);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.txtSearchProject);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.twPartlist);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.txtmakerno);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtapgno);
            this.Controls.Add(this.dgpartlist);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmPartList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPartList";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPartList_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpartlist)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtprojectCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtrevno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtdrawno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txteqpno;
        private System.Windows.Forms.DataGridView dgpartlist;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtpartlistno;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtmakerno;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtapgno;
        private System.Windows.Forms.TreeView twPartlist;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cmbMakerNo;
        private System.Windows.Forms.ComboBox cmbAPGNo;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DUNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Sl_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shape;
        private System.Windows.Forms.DataGridViewTextBoxColumn Size;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Spec_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Fg_wt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Rm_Wt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_D_Wt;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShopFloor;
        private System.Windows.Forms.DataGridViewTextBoxColumn PtsRefNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn MTONo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Desription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Engg_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSearchProject;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
    }
}