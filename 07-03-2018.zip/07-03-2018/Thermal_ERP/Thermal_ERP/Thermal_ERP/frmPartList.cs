﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Thermal_ERP
{
    using System.IO;
    using Excel = Microsoft.Office.Interop.Excel;
    public partial class frmPartList : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());

        public static string Partno, MakerNo, projectCode, apgno, part,Eqpname, treeviewItemName, Revno, revStatus,plno, DRAWINGNO;
        public frmPartList()
        {
            InitializeComponent();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F3) 
            {
                frmDimensions_Wt frm = new frmDimensions_Wt();
                //frm.MdiParent = this.ParentForm;
                frm.Show();
            }
        }
        private void ColorNodes(TreeNode t)
        {
            foreach (TreeNode tn in t.Nodes)
            {
                tn.ForeColor = Color.Blue;
                ColorNodes(tn);
            }
        }
        public string makno;
        public string apgnoo;
        public void AddChildNodes(TreeNode tr1, string p)
        {
            try
            {
                string Sub_Group_Of = p;
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No)as MakerNo,Project_Code,Maker_No FROM Part_List_Item WHERE Project_Code= '" + p + "'  and CompId='" + "0001" + "'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["MakerNo"].ToString().Trim();
                    makno = dr["Maker_No"].ToString().Trim();
                    AddChild_ChildNodes(child, makno);
                    tr1.Nodes.Add(child);
                }
            }
            catch (Exception ex)
            {
            }

        }
        public void AddChild_ChildNodes(TreeNode tr1, string p)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+Apg_No)as ApgNo,Maker_No,Apg_No  FROM Part_List_Item WHERE Maker_No= '" + p + "'  and CompId='" + "0001" + "' and Project_Code='"+prjcode+"'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["ApgNo"].ToString().Trim();
                    apgnoo = dr["Apg_No"].ToString().Trim();
                    AddSubChild_ChildNodes(child, apgnoo);
                    tr1.Nodes.Add(child);
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }

        }
        public void AddSubChild_ChildNodes(TreeNode tr1, string p)
        {
            try
            {                
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+Apg_No+'.'+Partlist_No)as PartlistNo,Apg_No,Part_Equipment_Name  FROM Part_List_Item WHERE Apg_No= '" + p + "'  and CompId='" + "0001" + "' and Maker_No='"+makno+ "'  and Project_Code='" + prjcode + "'", con);               
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["PartlistNo"].ToString().Trim();
                    string parteqpnam = dr["PartlistNo"].ToString().Trim();
                    AddSubChild_AddChildNodes(child, parteqpnam);
                    tr1.Nodes.Add(child);
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }

        }
        public void AddSubChild_AddChildNodes(TreeNode tr1, string p)
        {
            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+Apg_No+' .'+Partlist_No)as PartlistNo,Part_Equipment_Name,Partlist_No   FROM Part_List_Item WHERE Part_Equipment_Name= '" + p + "'  and CompId='" + "0001" + "'and Maker_No='" + makno + "'  and Project_Code='" + prjcode + "' and APG_No='"+apgnoo+"'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["PartlistNo"].ToString().Trim();

                    AddChild_ChildNodes(child, child.Text);

                    tr1.Nodes.Add(child);
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }

        }
        public void fill_Tree2()
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand("select distinct(Project_Code) from Part_List_Item where  CompId='" + "0001" + "' and project_code ='" + txtSearchProject.Text +"'", con);

                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                twPartlist.Nodes.Clear();
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode tnParent = new TreeNode();
                    tnParent.Text = dr["Project_Code"].ToString();
                    prjcode= dr["Project_Code"].ToString();
                    tnParent.Expand();
                    twPartlist.Nodes.Add(tnParent);
                    AddChildNodes(tnParent, tnParent.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public string prjcode;
        public void BindTreeViewData()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                foreach (TreeNode tn in twPartlist.Nodes)
                {
                    tn.ForeColor = Color.Blue;
                    ColorNodes(tn);
                }
                fill_Tree2();
                Cursor.Current = Cursors.Default;

            }
            catch (Exception ex)
            {


            }
        }
        public void BindProjectCode()
        {
            try
            {
                var data2 = db.Project_Masters.Select(c => c.Project_Code).Distinct().ToArray();
                AutoCompleteStringCollection instcol = new AutoCompleteStringCollection();
                instcol.AddRange(data2);
                txtprojectCode.AutoCompleteCustomSource = instcol;
                //var sa = (from k in db.Project_Masters where k.CompID == "0001" select new { k.Project_Code }).ToList();
                //if (sa.Count > 0)
                //{
                //    txtprojectCode.AutoCompleteCustomSource = sa;
                //}
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        private void frmPartList_Load(object sender, EventArgs e)
        {
            try
            {

                BindTreeViewData();
                BindDataToGrid();
                BindProjectCode();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void twPartlist_DoubleClick(object sender, EventArgs e)
        {
            try
            {
               if("3"==NodeValue)
                {
                    SqlCommand cmd2 = new SqlCommand("Sp_BindData_PartListitem_Searchdata", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@PartListno", twPartlist.SelectedNode.Text);
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da2.Fill(ds2, "x");
                    if (ds2.Tables["X"].Rows.Count > 0)
                    {
                        dgpartlist.DataSource = ds2.Tables[0];
                    }
                    else
                    {
                        MessageBox.Show("No Records Found");
                        return;
                    }
                    var sa = (from k in db.Part_List_Items where k.Activity_Part_No == twPartlist.SelectedNode.Text && k.Status != "Revised" select k).ToList();
                    if (sa.Count() > 0)
                    {
                        txtprojectCode.Text = sa[0].Project_Code;
                        cmbMakerNo.Text = sa[0].Maker_No;
                        cmbAPGNo.Text = sa[0].Apg_No;
                        txteqpno.Text = sa[0].Part_Equipment_Name;
                        txtpartlistno.Text = sa[0].Partlist_No;
                        txtrevno.Text = sa[0].Version_No;
                        comboBox1.Text = sa[0].Status;
                        dateTimePicker1.Value = Convert.ToDateTime(sa[0].Version_Date);
                    }
                }
               else if("1"==NodeValue)
                {
                    MessageBox.Show("Please Select PartList No's");
                    twPartlist.Focus();
                    return;
                }
                //Sp_BindData_PartListitem
                
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void txtmakerno_Leave(object sender, EventArgs e)
        {
            try
            {
                //var sa = (from k in db.Project_Structures where k.CompID == "0001" && k.Parent == txtprojectCode.Text select new { k.Project_Code }).ToList();
                //if(sa.Count>0)
                //{

                //}
            }
            catch (Exception ex)
            {

                throw;
            }
        }
       
        private void txtprojectCode_Leave(object sender, EventArgs e)
        {

            //string ConString = ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString;   
            var sa = (from k in db.Project_Structure_Mains where k.CompID == "0001" && k.Project_Code == txtprojectCode.Text select new { k.Maker_No }).Distinct().ToList();
            if (sa.Count > 0)
            {
                cmbMakerNo.DataSource = sa;
                cmbMakerNo.DisplayMember = "Maker_No";
                cmbMakerNo.ValueMember = "Maker_No";
                if (cmbMakerNo.Items.Count > 0)
                {
                    cmbMakerNo.SelectedIndex = -1;
                }
                else
                {
                    cmbMakerNo.SelectedIndex = -1;
                }
            }
            //////////var sa = (from k in db.Project_Structures where k.CompID == "0001" && k.Parent == txtprojectCode.Text select new { k.Project_Code }).ToList();
            //////////if(sa.Count>0)
            //////////{
            //////////    cmbMakerNo.DataSource = sa;
            //////////    cmbMakerNo.DisplayMember = "Project_Code";
            //////////    cmbMakerNo.ValueMember = "Project_Code";
            //////////    if(cmbMakerNo.Items.Count>0)
            //////////    {
            //////////        cmbMakerNo.SelectedIndex = -1;
            //////////    }
            //////////    else
            //////////    {
            //////////        cmbMakerNo.SelectedIndex = -1;
            //////////    }
            //////////}
            //txtmakerno.AutoCompleteMode = AutoCompleteMode.Suggest;
            //txtmakerno.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
            //getData(DataCollection);
            //txtmakerno.AutoCompleteCustomSource = DataCollection;
        }
        private void getData(AutoCompleteStringCollection dataCollection)
        {
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string nn = txtprojectCode.Text;
          //  connetionString = "Data Source=.;Initial Catalog=pubs;User ID=sa;password=zen412";
            string sql = "SELECT DISTINCT [Project_Code] FROM [Project_Structure] where CompID="+0001+" and Parent ="+txtprojectCode.Text.Trim()+"";                
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);
            try
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                adapter.SelectCommand = command;
                adapter.Fill(ds);
                adapter.Dispose();
                command.Dispose();
                connection.Close();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dataCollection.Add(row[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }
        }
        private void cmbMakerNo_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Project_Structure_Mains where k.CompID == "0001" && k.Maker_No == cmbMakerNo.Text && k.Project_Code == txtprojectCode.Text select new { k.APG_No }).Distinct().ToList();
                if(sa.Count>0)
                {
                    cmbAPGNo.DataSource = sa;
                    cmbAPGNo.DisplayMember = "APG_No";
                    cmbAPGNo.ValueMember = "APG_No";
                    if(cmbAPGNo.Items.Count>0)
                    {
                        cmbAPGNo.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbAPGNo.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void cmbAPGNo_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Project_Structure_Mains where k.CompID == "0001" && k.APG_No == cmbAPGNo.Text && k.Project_Code == txtprojectCode.Text && k.Maker_No==cmbMakerNo.Text select new { k.APG_Name }).ToList();
                if (sa.Count > 0)
                {
                    txteqpno.Text = sa[0].APG_Name;
                }
                else
                {
                    txteqpno.Text = "";
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Do You  Want to Delete This Recored Click On Yes.. (OR)  Do You Want Cancel This Recored Click On Cancel", "Part List", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    DataGridViewRow R = dgpartlist.Rows[dgpartlist.CurrentRow.Index];
                    int columnIndex = dgpartlist.CurrentCell.ColumnIndex;
                    string columnName = dgpartlist.Columns[columnIndex].Name;
                    string Part_Engg_Code = R.Cells["Part_Engg_Code"].Value.ToString();
             //       string rmcode = R.Cells["Part_RM_Code"].Value.ToString();
                    db.Sp_delete_Part_List_Item(1, Part_Engg_Code);
                    MessageBox.Show("Recored Deleted Successfully");
                    return;
                }
                else if(result== DialogResult.No)
                {
                    //MessageBox.Show("Recored Deleted Successfully");
                    //return;
                }
                else if(result == DialogResult.Cancel)
                {
                    DataGridViewRow R = dgpartlist.Rows[dgpartlist.CurrentRow.Index];
                    int columnIndex = dgpartlist.CurrentCell.ColumnIndex;
                    string columnName = dgpartlist.Columns[columnIndex].Name;
                    string Part_Engg_Code = R.Cells["Part_Engg_Code"].Value.ToString();
                //    string rmcode = R.Cells["Part_RM_Code"].Value.ToString();
                    db.Sp_delete_Part_List_Item(2, Part_Engg_Code);                  
                    MessageBox.Show("Recored Cancel Successfully");
                    return;

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dgpartlist_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            for(int i=0;i<dgpartlist.Rows.Count-1;i++)
            {
                string ver = (dgpartlist.Rows[i].Cells["Version_No"].Value == "" || dgpartlist.Rows[i].Cells["Version_No"].Value == null) ? "" : dgpartlist.Rows[i].Cells["Version_No"].Value.ToString();
                if(ver=="")
                {

                }
                else
                {
                    if (Convert.ToInt32(ver) > 00)
                    {
                        dgpartlist.Rows[i].DefaultCellStyle.BackColor = Color.Turquoise;
                    }
                    else
                    {

                    }
                }
               
            }
        }
        public string NodeValue;

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
                //string startupPath = AppDomain.CurrentDomain.BaseDirectory;
                //string targetPath = startupPath + "Templates\\";
                //string path = targetPath + "PartsList format -.xls";
                string path = "C:\\Users\\PROJECT\\Desktop\\PartsList.xls";

                xlWorkBook = xlApp.Workbooks.Open(path);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item("cover sht ");

            //You can loop through all cells and use i and j to get the cells
            xlWorkSheet.Cells[5,13].Value = txteqpno.Text;
            xlWorkSheet.Cells[5,20].Value = txtprojectCode.Text +"."+ cmbMakerNo.Text;
            xlWorkSheet.Cells[14,13].Value = txtdrawno.Text;
            xlWorkSheet.Cells[38,16].Value = txtprojectCode.Text + "." + cmbMakerNo.Text +"." + cmbAPGNo.Text +"." + txtpartlistno.Text;
                xlWorkSheet.Cells[39, 20].Value = txtrevno.Text;
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item("PARTS LIST");

                //You can loop through all cells and use i and j to get the cells
                xlWorkSheet.Cells[2,10].Value = "EQPT: " + txteqpno.Text;
                xlWorkSheet.Cells[2,15].Value = "Makers Nr. /Manufacturer's Sl.Nr." + txtprojectCode.Text + "." + cmbMakerNo.Text;
                xlWorkSheet.Cells[3,10].Value = "'Drg.Nr. " + txtdrawno.Text;
                xlWorkSheet.Cells[2,7].Value = txtprojectCode.Text + "." + cmbMakerNo.Text + "." + cmbAPGNo.Text + "." + txtpartlistno.Text; xlWorkSheet.Cells[39, 20].Value = txtrevno.Text;
                xlWorkSheet.Cells[3, 9].Value = txtrevno.Text;
                int RowNo = 6;
                for(int i=0; i<= dgpartlist.Rows.Count-1;i++)
                {
                    xlWorkSheet.Cells[RowNo, 3].Value = dgpartlist.Rows[i].Cells["Part_Sl_No"].Value;
                    xlWorkSheet.Cells[RowNo, 4].Value = dgpartlist.Rows[i].Cells["ItemDesc"].Value;
                    xlWorkSheet.Cells[RowNo+1, 4].Value = dgpartlist.Rows[i].Cells["Size"].Value;
                    xlWorkSheet.Cells[RowNo, 5].Value = dgpartlist.Rows[i].Cells["Part_Spec_Id"].Value; //Spec                                        
                    xlWorkSheet.Cells[RowNo, 6].Value = dgpartlist.Rows[i].Cells["Qty"].Value; //Qty
                    xlWorkSheet.Cells[RowNo, 7].Value = dgpartlist.Rows[i].Cells["Part_Fg_wt"].Value; //Finish Wt
                    xlWorkSheet.Cells[RowNo, 8].Value = dgpartlist.Rows[i].Cells["ShopFloor"].Value; // Shop Drawing
                    xlWorkSheet.Cells[RowNo, 11].Value = dgpartlist.Rows[i].Cells["PtsRefNo"].Value; //PTS No
                    //xlWorkSheet.Cells[RowNo, 5].Value = dgpartlist.Rows[i].Cells["ItemDesc"].Value; //Mtrl Cert
                    //xlWorkSheet.Cells[RowNo, 5].Value = dgpartlist.Rows[i].Cells["ItemDesc"].Value; //MTO No
                    xlWorkSheet.Cells[RowNo, 14].Value = dgpartlist.Rows[i].Cells["Part_Desription"].Value; //Spl Notes
                    if(RowNo >=28)
                    {
                        xlWorkSheet.Rows[RowNo+2].Insert();
                        //xlWorkSheet.Range[xlWorkSheet.Cells[RowNo+2,8], xlWorkSheet.Cells[RowNo + 3, 10]].Merge();
                        xlWorkSheet.Rows[RowNo + 2].Insert();
                        
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 2], xlWorkSheet.Cells[RowNo + 3, 2]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 3], xlWorkSheet.Cells[RowNo + 3, 3]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 4], xlWorkSheet.Cells[RowNo + 3, 4]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 5], xlWorkSheet.Cells[RowNo + 3, 5]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 6], xlWorkSheet.Cells[RowNo + 3, 6]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 7], xlWorkSheet.Cells[RowNo + 3, 7]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 8], xlWorkSheet.Cells[RowNo + 3, 10]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 11], xlWorkSheet.Cells[RowNo + 3, 11]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 12], xlWorkSheet.Cells[RowNo + 3, 12]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 13], xlWorkSheet.Cells[RowNo + 3, 13]].Merge();
                        xlWorkSheet.Range[xlWorkSheet.Cells[RowNo + 2, 14], xlWorkSheet.Cells[RowNo + 3, 15]].Merge();
                    }
                    RowNo = RowNo + 2;
                }


                xlApp.Visible = true; 
            //xlWorkBook.Close(false, misValue, misValue);
            //xlApp.Quit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void twPartlist_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            BindTreeViewData();
        }

        private void twPartlist_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {

                twPartlist.SelectedNode = e.Node;
                if (e.Node.Level == 4)
                {
                    NodeValue = "4";

                }
                else
                {
                    NodeValue = "1";
                }

            }
            else if (e.Button == MouseButtons.Left)
            {

                twPartlist.SelectedNode = e.Node;
                if (e.Node.Level == 3)
                {
                    NodeValue = "3";

                }
                else
                {
                    NodeValue = "1";
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BindTreeViewData();
            BindDataToGrid();
            BindProjectCode();
            txtprojectCode.Text = "";cmbMakerNo.Text = "";
            cmbAPGNo.Text = "";txteqpno.Text = "";
            txtdrawno.Text = "";txtpartlistno.Text="";
            comboBox1.Text = "";txtrevno.Text = "";dateTimePicker1.Value = DateTime.Now;
            if (dgpartlist.Rows.Count > 0)
            {
                for (int i = 0; i < dgpartlist.Rows.Count - 1; i++)
                {
                    dgpartlist.Rows.RemoveAt(i);
                    i--;
                    while (dgpartlist.Rows.Count == 0)
                        continue;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                frmAddPart obj = new frmAddPart();
                part = "TreeviewItemName";
                Partno = txtpartlistno.Text;
                MakerNo = cmbMakerNo.Text;
                apgno = cmbAPGNo.Text;
                projectCode = txtprojectCode.Text;
                revStatus = comboBox1.Text;
                Eqpname = txteqpno.Text;
                DataGridViewRow R = dgpartlist.Rows[dgpartlist.CurrentRow.Index];
                int columnIndex = dgpartlist.CurrentCell.ColumnIndex;
                string columnName = dgpartlist.Columns[columnIndex].HeaderText;
                if(R.Cells["Part_Sl_No"].Value!=""|| R.Cells["Part_Sl_No"].Value != null)
                {
                plno  = R.Cells["Part_Sl_No"].Value.ToString();
                }

                // Revno = txtrevno.Text;
                //  treeviewItemName =   twPartlist.SelectedNode.Text;
                if (obj.ShowDialog() == DialogResult.OK)
                {
                    // BindDataToGrid();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            TextBox tb = e.Control as TextBox;
            int colindex = dgpartlist.CurrentCell.ColumnIndex;
            string colname = dgpartlist.Columns[colindex].HeaderText;
                if ((tb != null && colname == "Item Description"))
                {
                tb.AutoCompleteMode = AutoCompleteMode.Suggest;
                tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                //AutoCompleteStringCollection DataColl = new AutoCompleteStringCollection;
            }  
                

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        public void BindDataToGrid()
        {
            try
            {
                var sa = (from k in db.Sp_BindData_PartListitem_Searchdata("0001","") select k).ToList();
                if (sa.Count > 0)
                {
                    dgpartlist.DataSource = sa;
                    for(int k=0;k<dgpartlist.Rows.Count;k++)
                    {
                        decimal rev = (dgpartlist.Rows[k].Cells["Version_No"].Value == "" || dgpartlist.Rows[k].Cells["Version_No"].Value == null|| dgpartlist.Rows[k].Cells["Version_No"].Value ==DBNull.Value) ? Convert.ToDecimal(00) : Convert.ToDecimal(dgpartlist.Rows[k].Cells["Version_No"].Value.ToString());
                        string status = (dgpartlist.Rows[k].Cells["Status"].Value == "" || dgpartlist.Rows[k].Cells["Status"].Value == null) ? "" : dgpartlist.Rows[k].Cells["Status"].Value.ToString();
                        if((00==rev)&&""==status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.LightGreen;
                        }
                        else if((00 == rev) && "Cancel" == status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.IndianRed;
                        }
                        else if ((00 != rev) && "Cancel" == status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.IndianRed;
                        }
                        else if ((00 < rev) && "" == status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.Turquoise;
                        }
                        else if ((00 < rev) && "Cancel" == status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.IndianRed;
                        }
                        else if ((00 < rev) && "Cancel" != status)
                        {
                            dgpartlist.Rows[k].DefaultCellStyle.BackColor = Color.Turquoise;
                        }
                    }
                   
                }
            }
            catch (Exception ex)
            {

                throw;
            }
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
           

            frmAddPart frm = new frmAddPart();
            Partno = txtpartlistno.Text;
            MakerNo = cmbMakerNo.Text;
            apgno = cmbAPGNo.Text;
            projectCode = txtprojectCode.Text;
            Eqpname = txteqpno.Text;
            DRAWINGNO = txtdrawno.Text;
            Revno = "00";
             part = "frmpartlist";


            if (frm.ShowDialog() == DialogResult.Cancel)
            {
                BindDataToGrid();
            }
        }
        //        public void addItems(AutoCompleteStringCollection coll)

        //        {

        //            try

        //            {

        //                int columnIndex = dataGridView1.CurrentCell.ColumnIndex;
        //                string columnName = dataGridView1.Columns[columnIndex].HeaderText;                
        //                DataGridViewRow R1 = dataGridView1.Rows[dataGridView1.CurrentRow.Index];
        //                if (columnName == "Item Description")
        //                {
        //                    var d = (from c in db.ProdMasters                            
        //                             select new
        //                             {
        //                                 c.Product_Category
        //                             }).ToList();



        //                    DataTable dt = new DataTable();

        //                    dt.Columns.Add("d");

        //                    foreach (var item in d)

        //                    {

        //                        dt.Rows.Add(item.Product_Category);

        //                    }

        //                    for (int i = 0; i < dt.Rows.Count; i++)

        //                    {

        //                        coll.Add(dt.Rows[i][0].ToString());

        //                    }



        //                }

        //                if (columnName == "Product Name")

        //                {

        //                    if (R1.Cells["Product_Category"].Value != null &&
        //R1.Cells["Product_Category"].Value != DBNull.Value)

        //                    {

        //                        var d = (from c in db.ProdMasters
        //                                 where c.Comp_Name
        //== AppCode.GlobalAccess.companyName && c.Product_Category ==
        //R1.Cells["Product_Category"].Value.ToString().Trim()
        //                                 select new
        //                                 {
        //                                     c.Product_Name
        //                                 }).ToList();



        //                        DataTable dt = new DataTable();

        //                        dt.Columns.Add("d");

        //                        foreach (var item in d)



        //                        {

        //                            dt.Rows.Add(item.Product_Name);

        //                        }

        //                        for (int i = 0; i < dt.Rows.Count; i++)

        //                        {

        //                            coll.Add(dt.Rows[i][0].ToString());

        //                        }





        //                    }

        //                }

        //            }

        //            catch (Exception ex)

        //            {

        //            }

    }
    }
