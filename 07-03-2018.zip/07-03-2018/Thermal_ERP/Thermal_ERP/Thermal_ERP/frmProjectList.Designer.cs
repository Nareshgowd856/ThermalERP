﻿namespace Thermal_ERP
{
    partial class frmProjectList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Project_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Project_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Project_Client = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Project_DeliveryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projectMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.button1 = new System.Windows.Forms.Button();
            this.project_MasterTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Project_MasterTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DimGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Project_Code,
            this.Project_Name,
            this.Project_Client,
            this.Project_DeliveryDate,
            this.CompID});
            this.dataGridView1.DataSource = this.projectMasterBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(959, 491);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // Project_Code
            // 
            this.Project_Code.DataPropertyName = "Project_Code";
            this.Project_Code.HeaderText = "Project_Code";
            this.Project_Code.Name = "Project_Code";
            // 
            // Project_Name
            // 
            this.Project_Name.DataPropertyName = "Project_Name";
            this.Project_Name.HeaderText = "Project_Name";
            this.Project_Name.Name = "Project_Name";
            // 
            // Project_Client
            // 
            this.Project_Client.DataPropertyName = "Project_Client";
            this.Project_Client.HeaderText = "Project_Client";
            this.Project_Client.Name = "Project_Client";
            // 
            // Project_DeliveryDate
            // 
            this.Project_DeliveryDate.DataPropertyName = "Project_DeliveryDate";
            this.Project_DeliveryDate.HeaderText = "Project_DeliveryDate";
            this.Project_DeliveryDate.Name = "Project_DeliveryDate";
            // 
            // CompID
            // 
            this.CompID.DataPropertyName = "CompID";
            this.CompID.HeaderText = "CompID";
            this.CompID.Name = "CompID";
            // 
            // projectMasterBindingSource
            // 
            this.projectMasterBindingSource.DataMember = "Project_Master";
            this.projectMasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(807, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 25);
            this.button1.TabIndex = 1;
            this.button1.Text = "Add New";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // project_MasterTableAdapter
            // 
            this.project_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(904, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(66, 25);
            this.button2.TabIndex = 2;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmProjectList
            // 
            this.AccessibleName = "frmProjectList";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.AccessibleName = "frmProjectList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmProjectList";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmProjectList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource projectMasterBindingSource;
        private Thermal_PMSDataSetTableAdapters.Project_MasterTableAdapter project_MasterTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project_Client;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project_DeliveryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompID;
        private System.Windows.Forms.Button button2;
    }
}