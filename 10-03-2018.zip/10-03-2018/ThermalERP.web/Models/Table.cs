
namespace ThermalERP.web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class Table
    {
        public int UserID { get; set; }
        public string CompId { get; set; }
        [Display(Name = "Created By")]
        public string Created_By { get; set; }
        [Display(Name = "Created Date")]
        public Nullable<System.DateTime> Created_Date { get; set; }
        [Display(Name = "Modified By")]
        public string Modified_By { get; set; }
        [Display(Name = "Modified Date")]
        public Nullable<System.DateTime> Modified_Date { get; set; }
        [Display(Name = "User Name")]
        public string User_Name { get; set; }
        public string Password { get; set; }
    }
}
