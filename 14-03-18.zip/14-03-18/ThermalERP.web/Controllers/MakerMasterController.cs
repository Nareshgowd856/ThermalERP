﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;

namespace ThermalERP.web.Controllers
{
    public class MakerMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        [HttpPost]
        public ActionResult Index()
        {
            return View(db.Maker_Master.ToList());
        }
        [HttpGet]
        public ActionResult Index(int page = 1, string sort = "Maker_No", string sortdir = "asc", string search = "")
        {
            int pagesize = 5;
            int totalRecord = 0;
            if (page < 1) page = 1;
            int skip = (page * pagesize) - pagesize;
            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
            ViewBag.TotalRows = totalRecord;
            return View(data);
        }
        public List<Maker_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var v = (from a in db.Maker_Master
                         where
                         a.Maker_No.Contains(Search) ||
                         a.Maker_Description.Contains(Search)

                         select a
                         );
                TotalRecord = v.Count();
                v = v.OrderBy(sort + " " + sortdir);
                if (pageSize > 0)
                {
                    v = v.Skip(skip).Take(pageSize);
                }
                return v.ToList();
            }
        }

        // GET: MakerMaster/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Maker_Master maker_Master = db.Maker_Master.Find(id);
            if (maker_Master == null)
            {
                return HttpNotFound();
            }
            return View(maker_Master);
        }

        // GET: MakerMaster/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Maker_Master, "Id" , "MakerNo");
            return PartialView("Partial_Create");
        }

        // POST: MakerMaster/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Maker_Master.Add(maker_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", maker_Master.Maker_No);
        //    return View(maker_Master);
        //}

        // GET: MakerMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Maker_Master maker_Master = db.Maker_Master.Find(id);
            if (maker_Master == null)
            {
                return HttpNotFound();
            }
            return View(maker_Master);
        }

        // POST: MakerMaster/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(maker_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(maker_Master);
        }

        // GET: MakerMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Maker_Master maker_Master = db.Maker_Master.Find(id);
            if (maker_Master == null)
            {
                return HttpNotFound();
            }
            return View(maker_Master);
        }

        /// <summary>
        /// Partial_s the create.
        /// </summary>
        /// <returns></returns>
        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
        {
            if (ModelState.IsValid)
            {
                db.Maker_Master.Add(maker_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", maker_Master.Maker_No);
            return PartialView(maker_Master);
        }

        // POST: MakerMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Maker_Master maker_Master = db.Maker_Master.Find(id);
            db.Maker_Master.Remove(maker_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
