﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;

namespace ThermalERP.web.Controllers
{
    public class PartListItemController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        [HttpPost]
        public ActionResult Index()
        {
            return View(db.Part_List_Item.ToList());
        }
        [HttpGet]
        public ActionResult Index(int page = 1, string sort = "Project_Code", string sortdir = "asc", string search = "")
        {
            int pagesize = 10;
            int totalRecord = 0;
            if (page < 1) page = 1;
            int skip = (page * pagesize) - pagesize;
            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
            ViewBag.TotalRows = totalRecord;
            return View(data);
        }
        public List<Part_List_Item> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var v = (from a in db.Part_List_Item
                         where
                         a.Project_Code.Contains(Search) ||
                         a.Maker_No.Contains(Search)

                         select a
                         );
                TotalRecord = v.Count();
                v = v.OrderBy(sort + " " + sortdir);
                if (pageSize > 0)
                {
                    v = v.Skip(skip).Take(pageSize);
                }
                return v.ToList();
            }
        }

        //// GET: PartListItem/Details/5
        //public ActionResult Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
        //    if (part_List_Item == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(part_List_Item);
        //}

        // GET: PartListItem/Create
        public ActionResult Create()
        {
            using (Thermal_PMSEntities cshparpEntity = new Thermal_PMSEntities())
            {
                var fromDatabaseEF = new SelectList(cshparpEntity.Part_List.ToList(), "ID", "Name");
                ViewData["DBMySkills"] = fromDatabaseEF;
            }
            ViewBag.Id = new SelectList(db.Part_List_Item, "Id", "Project_Code");
            return PartialView("Partial_Create");
        }

       
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "id,Project_Code,Maker_No,Apg_No,Apg_Name,Partlist_No,Part_Group,Part_Sl_No,Part_Name,Part_Desription,Part_variant,Part_UOM,Part_Spec_Id,Part_Rm_Type,Part_Rm_WThick,Part_Rm_Density,Part_Mtc_Cert,Part_IBR_Cert,Part_EN_Cert,Part_RM_Code,Part_Dia,Part_Wt,Part_Length,Part_W2,Part_Fg_wt,Part_Rm_Wt,Part_D_Wt,Part_Engg_Code,CompId,Version_No,Version_Date,Version_Change,Created,Creted_By,Modified,Modified_By,Qty,OD,Part_Equipment_Name,Status,Drawing_NO,PTS_NO,Main_Drwaing_No,Activity_Part_No")] Part_List_Item part_List_Item)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Part_List_Item.Add(part_List_Item);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Part_List_Item, "Id", "Project_Code", part_List_Item.Project_Code);
        //    return View(part_List_Item);
        //}

        // GET: PartListItem/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            if (part_List_Item == null)
            {
                return HttpNotFound();
            }
            return View(part_List_Item);
        }

        // POST: PartListItem/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Project_Code,Maker_No,Apg_No,Apg_Name,Partlist_No,Part_Group,Part_Sl_No,Part_Name,Part_Desription,Part_variant,Part_UOM,Part_Spec_Id,Part_Rm_Type,Part_Rm_WThick,Part_Rm_Density,Part_Mtc_Cert,Part_IBR_Cert,Part_EN_Cert,Part_RM_Code,Part_Dia,Part_Wt,Part_Length,Part_W2,Part_Fg_wt,Part_Rm_Wt,Part_D_Wt,Part_Engg_Code,CompId,Version_No,Version_Date,Version_Change,Created,Creted_By,Modified,Modified_By,Qty,OD,Part_Equipment_Name,Status,Drawing_NO,PTS_NO,Main_Drwaing_No,Activity_Part_No")] Part_List_Item part_List_Item)
        {
            if (ModelState.IsValid)
            {
                db.Entry(part_List_Item).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(part_List_Item);
        }

        // GET: PartListItem/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            if (part_List_Item == null)
            {
                return HttpNotFound();
            }
            return View(part_List_Item);
        }

        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Project_Code,Maker_No,Apg_No,Apg_Name,Partlist_No,Part_Group,Part_Sl_No,Part_Name,Part_Desription,Part_variant,Part_UOM,Part_Spec_Id,Part_Rm_Type,Part_Rm_WThick,Part_Rm_Density,Part_Mtc_Cert,Part_IBR_Cert,Part_EN_Cert,Part_RM_Code,Part_Dia,Part_Wt,Part_Length,Part_W2,Part_Fg_wt,Part_Rm_Wt,Part_D_Wt,Part_Engg_Code,CompId,Version_No,Version_Date,Version_Change,Created,Creted_By,Modified,Modified_By,Qty,OD,Part_Equipment_Name,Status,Drawing_NO,PTS_NO,Main_Drwaing_No,Activity_Part_No")] Part_List_Item part_List_Item)
        {
            if (ModelState.IsValid)
            {
                db.Part_List_Item.Add(part_List_Item);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Part_List_Item, "Id", "Project_Code", part_List_Item.Project_Code);
            return PartialView(part_List_Item);
        }
        // POST: PartListItem/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            db.Part_List_Item.Remove(part_List_Item);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
