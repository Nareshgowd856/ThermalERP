﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Web;

//namespace ThermalERP.web.Models
//{
//    public class MaterialGrade
//    {
//        [Display(Name = "Material Group")]
//        public string Material_Group { get; set; }
//        [Display(Name = "Material Grad")]
//        public string Material_Grad { get; set; }
//        [Display(Name = "Material Color")]
//        public string Material_Color { get; set; }
//        [Display(Name = "Material Density")]
//        public Nullable<decimal> Material_Density { get; set; }
//        public string CompID { get; set; }
//        [Display(Name = "Spec Code")]
//        public string Spec_Code { get; set; }
//        public int id { get; set; }

//        public static List<MaterialGrade> GetList()
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                List<MaterialGrade> Material = db.Material_Grades.Where(model => model.id());


//                return Material;
//            }
            
//        }

//    }
//}