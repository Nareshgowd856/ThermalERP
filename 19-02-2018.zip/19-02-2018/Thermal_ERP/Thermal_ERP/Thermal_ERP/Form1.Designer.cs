﻿namespace Thermal_ERP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.setupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newMakerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newAPGGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newPartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activityMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setupToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(466, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // setupToolStripMenuItem
            // 
            this.setupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newProjectToolStripMenuItem,
            this.newMakerToolStripMenuItem,
            this.newAPGGroupToolStripMenuItem,
            this.newPartToolStripMenuItem,
            this.activityMasterToolStripMenuItem});
            this.setupToolStripMenuItem.Name = "setupToolStripMenuItem";
            this.setupToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.setupToolStripMenuItem.Text = "Setup";
            // 
            // newProjectToolStripMenuItem
            // 
            this.newProjectToolStripMenuItem.Name = "newProjectToolStripMenuItem";
            this.newProjectToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newProjectToolStripMenuItem.Text = "New Project";
            this.newProjectToolStripMenuItem.Click += new System.EventHandler(this.newProjectToolStripMenuItem_Click);
            // 
            // newMakerToolStripMenuItem
            // 
            this.newMakerToolStripMenuItem.Name = "newMakerToolStripMenuItem";
            this.newMakerToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newMakerToolStripMenuItem.Text = "New Maker";
            this.newMakerToolStripMenuItem.Click += new System.EventHandler(this.newMakerToolStripMenuItem_Click);
            // 
            // newAPGGroupToolStripMenuItem
            // 
            this.newAPGGroupToolStripMenuItem.Name = "newAPGGroupToolStripMenuItem";
            this.newAPGGroupToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newAPGGroupToolStripMenuItem.Text = "New APG Group";
            this.newAPGGroupToolStripMenuItem.Click += new System.EventHandler(this.newAPGGroupToolStripMenuItem_Click);
            // 
            // newPartToolStripMenuItem
            // 
            this.newPartToolStripMenuItem.Name = "newPartToolStripMenuItem";
            this.newPartToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newPartToolStripMenuItem.Text = "New Part";
            // 
            // activityMasterToolStripMenuItem
            // 
            this.activityMasterToolStripMenuItem.Name = "activityMasterToolStripMenuItem";
            this.activityMasterToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.activityMasterToolStripMenuItem.Text = "Activity Master";
            this.activityMasterToolStripMenuItem.Click += new System.EventHandler(this.activityMasterToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 345);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem setupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newPartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newMakerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newAPGGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activityMasterToolStripMenuItem;
    }
}

