﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Thermal_ERP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void newMakerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMakers frm = new frmMakers();
            frm.Show();

        }

        private void newAPGGroupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAPGMaster frm = new frmAPGMaster();
            frm.Show();
        }

        private void activityMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmActivityMaster frm = new frmActivityMaster();
            frm.Show();
        }
    }
}
