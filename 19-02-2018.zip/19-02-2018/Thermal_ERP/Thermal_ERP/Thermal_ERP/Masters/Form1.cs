﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
namespace Thermal_ERP.Masters
{
    //public class DataGridViewProgressColumn : DataGridViewImageColumn
    //{
    //    private Color _ProgressBarColor;

    //    public override DataGridViewCell CellTemplate
    //    {
    //        get
    //        {
    //            return base.CellTemplate;
    //        }
    //        set
    //        {
    //            if (value != null &&
    //                !value.GetType().IsAssignableFrom(typeof(DataGridViewProgressCell)))
    //            {
    //                throw new InvalidCastException("Must be a DataGridViewProgressCell");
    //            }
    //            base.CellTemplate = value;
    //        }
    //    }
    //    protected override void Paint(Graphics g, System.Drawing.Rectangle clipBounds, System.Drawing.Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
    //    {
    //        if (Convert.ToInt16(value) == 0 || value == null)
    //        {
    //            value = 0;
    //        }

    //        int progressVal = Convert.ToInt32(value);

    //        // Need to convert to float before division; 
    //        //otherwise C# returns int which is 0 for anything but 100%.
    //        float percentage = ((float)progressVal / 100.0f);
    //        Brush backColorBrush = new SolidBrush(cellStyle.BackColor);
    //        Brush foreColorBrush = new SolidBrush(cellStyle.ForeColor);
    //        NewMethod(g, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, paintParts);

    //        float posX = cellBounds.X;
    //        float posY = cellBounds.Y;

    //        float textWidth = TextRenderer.MeasureText
    //        (progressVal.ToString() + "%", cellStyle.Font).Width;
    //        float textHeight = TextRenderer.MeasureText
    //        (progressVal.ToString() + "%", cellStyle.Font).Height;

    //        //evaluating text position according to selected alignment
    //        //default text alignment is TopLeft
    //        //variables posX and posY determine position of progress value text (percentage+"%")
    //        switch (cellStyle.Alignment)
    //        {
    //            case DataGridViewContentAlignment.BottomCenter:
    //                posX = cellBounds.X + (cellBounds.Width / 2) - textWidth / 2;
    //                posY = cellBounds.Y + cellBounds.Height - textHeight;
    //                break;
    //            case DataGridViewContentAlignment.BottomLeft:
    //                posX = cellBounds.X;
    //                posY = cellBounds.Y + cellBounds.Height - textHeight;
    //                break;
    //            case DataGridViewContentAlignment.BottomRight:
    //                posX = cellBounds.X + cellBounds.Width - textWidth;
    //                posY = cellBounds.Y + cellBounds.Height - textHeight;
    //                break;
    //            case DataGridViewContentAlignment.MiddleCenter:
    //                posX = cellBounds.X + (cellBounds.Width / 2) - textWidth / 2;
    //                posY = cellBounds.Y + (cellBounds.Height / 2) - textHeight / 2;
    //                break;
    //            case DataGridViewContentAlignment.MiddleLeft:
    //                posX = cellBounds.X;
    //                posY = cellBounds.Y + (cellBounds.Height / 2) - textHeight / 2;
    //                break;
    //            case DataGridViewContentAlignment.MiddleRight:
    //                posX = cellBounds.X + cellBounds.Width - textWidth;
    //                posY = cellBounds.Y + (cellBounds.Height / 2) - textHeight / 2;
    //                break;
    //            case DataGridViewContentAlignment.TopCenter:
    //                posX = cellBounds.X + (cellBounds.Width / 2) - textWidth / 2;
    //                posY = cellBounds.Y;
    //                break;
    //            case DataGridViewContentAlignment.TopLeft:
    //                posX = cellBounds.X;
    //                posY = cellBounds.Y;
    //                break;

    //            case DataGridViewContentAlignment.TopRight:
    //                posX = cellBounds.X + cellBounds.Width - textWidth;
    //                posY = cellBounds.Y;
    //                break;
    //        }

    //        if (percentage >= 0.0)
    //        {
    //            // Draw the progress 
    //            g.FillRectangle(new SolidBrush(_ProgressBarColor), cellBounds.X + 2, cellBounds.Y + 2, Convert.ToInt32((percentage * cellBounds.Width * 0.8)), cellBounds.Height / 1 - 5);
    //            //Draw text
    //            g.DrawString(progressVal.ToString() + "%",
    //            cellStyle.Font, foreColorBrush, posX, posY);
    //        }
    //        else
    //        {
    //            //if percentage is negative, we don't want to draw progress bar
    //            //we want only text
    //            if (this.DataGridView.CurrentRow.Index == rowIndex)
    //            {
    //                g.DrawString(progressVal.ToString() + "%", cellStyle.Font,
    //                    new SolidBrush(cellStyle.SelectionForeColor), posX, posX);
    //            }
    //            else
    //            {
    //                g.DrawString(progressVal.ToString() + "%", cellStyle.Font,
    //                    foreColorBrush, posX, posY);
    //            }
    //        }
    //    }

    //    private void NewMethod(Graphics g, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    //private void NewMethod(Graphics g, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
    //    //{

    //    //    // Draws the cell grid
    //    //    base.Paint(g, clipBounds, cellBounds, rowIndex,cellState, value, formattedValue, errorText,cellStyle, advancedBorderStyle,(paintParts & ~DataGridViewPaintParts.ContentForeground));
    //    //}

    //    public override object Clone()
    //    {
    //        DataGridViewProgressCell dataGridViewCell = base.Clone() as DataGridViewProgressCell;
    //        if (dataGridViewCell != null)
    //        {
    //            dataGridViewCell.ProgressBarColor = this.ProgressBarColor;
    //        }
    //        return dataGridViewCell;
    //    }

    //    [Browsable(true)]
    //    public Color ProgressBarColor
    //    {
    //        get
    //        {
    //            if (this.ProgressBarCellTemplate == null)
    //            {
    //                throw new InvalidOperationException
    //            ("Operation cannot be completed because this DataGridViewColumn does not have a CellTemplate.");
    //            }
    //             return this.ProgressBarCellTemplate.ProgressBarColor;
    //        }
    //        set
    //        {
    //            if (this.ProgressBarCellTemplate == null)
    //            {
    //                throw new InvalidOperationException
    //            ("Operation cannot be completed because this DataGridViewColumn  does not have a CellTemplate.");
    //            }
    //            NewMethod(value);
    //            if (this.DataGridView != null)
    //            {
    //                DataGridViewRowCollection dataGridViewRows = this.DataGridView.Rows;
    //                int rowCount = dataGridViewRows.Count;
    //                for (int rowIndex = 0; rowIndex < rowCount; rowIndex++)
    //                {
    //                    DataGridViewRow dataGridViewRow = dataGridViewRows.SharedRow(rowIndex);
    //                    if (dataGridViewRow.Cells[this.Index] is DataGridViewProgressCell dataGridViewCell)
    //                    {
    //                        dataGridViewCell.SetProgressBarColor(rowIndex, value);
    //                    }
    //                }
    //                this.DataGridView.InvalidateColumn(this.Index);
    //            }
    //        }
    //    }

    //    private void NewMethod(Color value)
    //    {
    //        NewMethod1(value);
    //    }

    //    private void NewMethod1(Color value)
    //    {
    //        this.ProgressBarCellTemplate.ProgressBarColor = value;
    //    }

    //    public object ProgressBarCellTemplate { get; private set; }

    //    private void InitializeComponent()
    //    {

    //    }
    //}

    //internal class DataGridViewProgressCell
    //{
    //    public Color ProgressBarColor { get; internal set; }

    //    internal void SetProgressBarColor(int rowIndex, Color value)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
