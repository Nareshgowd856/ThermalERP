﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class PTMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public PTMaster()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }
        public void Clear()
        {
            txtPtId.Text = "";
            txtPtName.Text = "";
            var sa = (from k in db.Part_Lists where k.CompID == "0001" select new { k.Part_List_No, k.Part_List_Name }).ToList();
            if(sa.Count>0)
            {
                dgCustmaster.DataSource = sa;
            }
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if((from k in db.Part_Lists where k.CompID=="0001"&& k.Part_List_No==txtPtId.Text.Trim() select k).Count()>0)
            {
                db.sp_Delete_Part_List("0001", txtPtId.Text.Trim());
                Part_List p = new Part_List();
                p.Part_List_No = txtPtId.Text;
                p.Part_List_Name = txtPtName.Text;
                p.CompID = "0001";
                p.Created_By = "";
                p.Created_On = DateTime.Now;
                db.Part_Lists.InsertOnSubmit(p);
                db.SubmitChanges();
                MessageBox.Show("Recored Updated Succesfully");
                Clear();
                txtPtId.Focus();
                return;
            }
            else
            {
                Part_List p = new Part_List();
                p.Part_List_No = txtPtId.Text;
                p.Part_List_Name = txtPtName.Text;
                p.CompID = "0001";
                p.Created_By = "";
                p.Created_On = DateTime.Now;
                db.Part_Lists.InsertOnSubmit(p);
                db.SubmitChanges();
                MessageBox.Show("Recored Saved Succesfully");
                Clear();
                txtPtId.Focus();
                return;
            }
           
        }

        private void PTMaster_Load(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPtId_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Part_Lists where k.CompID == "0001" && k.Part_List_No==txtPtId.Text.Trim() select k).ToList();
                if (sa.Count > 0)
                {
                    MessageBox.Show("This Name is Alreday Existing...");
                    txtPtId.Text = "";
                    txtPtId.Focus();
                    return;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dgCustmaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    string partid = (dgCustmaster.Rows[e.RowIndex].Cells["Part_List_No"].Value.ToString());
                    var sa = (from k in db.Part_Lists where k.CompID == "0001" && k.Part_List_No == partid select new { k.Part_List_No, k.Part_List_Name }).ToList();
                    if(sa.Count>0)
                    {
                        txtPtId.Text = sa[0].Part_List_No;
                        txtPtName.Text = sa[0].Part_List_Name;

                    }
                    else
                    {

                    }
                }
                txtPtName.Focus();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
