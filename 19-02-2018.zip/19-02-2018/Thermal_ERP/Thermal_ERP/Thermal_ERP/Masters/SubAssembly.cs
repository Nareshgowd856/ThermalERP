﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class SubAssembly : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public SubAssembly()
        {
            InitializeComponent();
        }
        public void BindGrid()
        {
            var sa = (from k in db.SubAssembly_Masters where k.CompID == "0001" select new { k.Sub_Assembly_ID, k.Sub_Assembly_Name }).ToList();
            if(sa.Count>0)
            {
                dguommaster.DataSource = sa;
            }
        }
        public void Clear()
        {
            txtUOMid.Text = "";
            txtUOMName.Text = "";
            comboBox1.Text = "";
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUOMName.Text == "" || txtUOMName.Text == null)
                {
                    MessageBox.Show("PLease Enter Sub Assemly Name");
                    txtUOMName.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.SubAssembly_Masters where k.CompID == "0001" && k.Sub_Assembly_ID == txtUOMid.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_SubAssembly_Master("0001", txtUOMid.Text);
                        SubAssembly_Master s = new SubAssembly_Master();
                        s.Sub_Assembly_ID = txtUOMid.Text;
                        s.Sub_Assembly_Name = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                        s.GroupName=(comboBox1.Text=="")?"" : comboBox1.Text;
                        s.CompID = "0001";
                        s.Created_By = "";
                        s.Created_On = DateTime.Now;
                        s.Modified_By = "";
                        s.Modified_On = DateTime.Now;
                        db.SubAssembly_Masters.InsertOnSubmit(s);
                        db.SubmitChanges();
                        BindGrid();
                        Clear();
                        MessageBox.Show("Recored Updated Successfully");
                        return;
                    }
                    else
                    {
                        SubAssembly_Master s = new SubAssembly_Master();
                        s.Sub_Assembly_Name = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                        s.CompID = "0001";
                        s.GroupName = (comboBox1.Text == "") ? "" : comboBox1.Text;
                        s.Created_By = "";
                        s.Created_On = DateTime.Now;
                        s.Modified_By = "";
                        s.Modified_On = DateTime.Now;
                        var sa = (db.Sp_autoincrement_SubAssembly_Master("0001"));
                        s.Sub_Assembly_ID = sa.FirstOrDefault().Sub_Assembly_ID;
                        db.SubAssembly_Masters.InsertOnSubmit(s);
                        db.SubmitChanges();
                        BindGrid();
                        Clear();
                        MessageBox.Show("Recored Saved Successfully");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                Clear();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dguommaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>0)
                {

                    string asmid = (dguommaster.Rows[e.RowIndex].Cells["Sub_Assembly_ID"].Value.ToString());
                    var sa = (from k in db.SubAssembly_Masters where k.CompID == "0001" && k.Sub_Assembly_ID == asmid select new { k.Sub_Assembly_ID, k.Sub_Assembly_Name,k.GroupName }).ToList();
                    if(sa.Count>0)
                    {
                        txtUOMid.Text = sa[0].Sub_Assembly_ID;
                        txtUOMName.Text = sa[0].Sub_Assembly_Name;
                        comboBox1.Text = sa[0].GroupName;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void SubAssembly_Load(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void txtUOMName_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.SubAssembly_Masters where k.CompID == "0001" && k.Sub_Assembly_Name == txtUOMName.Text select k).ToList();
                if(sa.Count>0)
                {
                    MessageBox.Show("This Name is Already Existing.. Please Enter Another Name..");
                    txtUOMName.Text = "";
                    txtUOMName.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
