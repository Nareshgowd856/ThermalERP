﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Configuration;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class ProjectStructureCreation : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());

        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public ProjectStructureCreation()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            cmbcode.Text = "";
            cmbmaker.Text = "";
            txtmaker.Text = "";
            comboBox1.Text = "";
            textBox1.Text = "";
            groupBox2.Visible = false;
            var sa11 = (from k in db.APG_Masters where k.CompID == "0001" select new { k.APG_No, k.APG_Description }).ToList();
            if (sa11.Count > 0)
            {

                dataGridView4.DataSource = sa11;
            }
            BindTreeViewData();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                for(int i=0;i<dataGridView4.Rows.Count-1;i++)
                {
                    if (dataGridView4.Rows[i].Cells["ColSelect1"].Value != null)
                    {
                        if (dataGridView4.Rows[i].Cells["ColSelect1"].Value.ToString().Equals("True"))
                        {
                            Project_Structure_Main p = new Project_Structure_Main();
                            p.Project_Code = label9.Text;
                            p.Maker_No = label5.Text;
                            p.Maker_Name = label7.Text;
                            p.APG_No = (dataGridView4.Rows[i].Cells["APG_No"].Value == "" || dataGridView4.Rows[i].Cells["APG_No"].Value == null) ? "" : dataGridView4.Rows[i].Cells["APG_No"].Value.ToString();
                            p.APG_Name = (dataGridView4.Rows[i].Cells["APG_Description"].Value == "" || dataGridView4.Rows[i].Cells["APG_Description"].Value == null) ? "" : dataGridView4.Rows[i].Cells["APG_Description"].Value.ToString();
                            p.Full_Project_Code = cmbcode.Text + "." + txtmaker.Text;
                            p.CompID = "0001";
                            p.Created_By = "";
                            p.Created_On = DateTime.Now;
                            db.Project_Structure_Mains.InsertOnSubmit(p);
                        }
                    }
                   
                }
                db.SubmitChanges();
                MessageBox.Show("Recored Saved Successfully");
                BindTreeViewData();
                groupBox2.Visible = false;
                Clear();
                
                return;
              
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
        }
        private void ColorNodes(TreeNode t)
        {
            foreach (TreeNode tn in t.Nodes)
            {
                tn.ForeColor = Color.Blue;
                ColorNodes(tn);
            }
        }
        public string prjcode;
        public void fill_Tree2()
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                  SqlCommand cmd = new SqlCommand("select distinct(Project_Code) from Project_Structure_Main where  CompID='" + "0001" + "'", con);
               // SqlCommand cmd = new SqlCommand("select distinct(Project_Code) from Project_Master_Child where  CompID='" + "0001" + "'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                twProjectCreation.Nodes.Clear();
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode tnParent = new TreeNode();
                    tnParent.Text = dr["Project_Code"].ToString();
                    prjcode = dr["Project_Code"].ToString();
                    tnParent.Expand();
                    twProjectCreation.Nodes.Add(tnParent);
                    AddChildNodes(tnParent, tnParent.Text);
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void AddChildNodes(TreeNode tr1, string p)
        {
            try
            {
                string Sub_Group_Of = p;
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                   SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+Maker_Name) as MakerNo,Project_Code,Maker_No FROM Project_Structure_Main WHERE Project_Code= '" + p + "'  and CompID='" + "0001" + "' and Project_Code='" + prjcode + "'", con);
             //   SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+Project_Equp_Name) as MakerNo,Project_Code,Maker_No FROM Project_Master_Child WHERE Project_Code= '" + p + "'  and CompID='" + "0001" + "' and Project_Code='" + prjcode + "'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["MakerNo"].ToString().Trim();
                    string  makno = dr["Maker_No"].ToString().Trim();
                    AddChild_ChildNodes(child, makno);
                    tr1.Nodes.Add(child);
                }
            }
            catch (Exception ex)
            {
            }

        }
        public void AddChild_ChildNodes(TreeNode tr1, string p)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ToString());
                con.Open();
                 SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+APG_No+'.'+APG_Name) as APGNo,Maker_No,APG_No  FROM Project_Structure_Main WHERE Maker_No= '" + p + "'  and CompID='" + "0001" + "' and Project_Code='" + prjcode + "'", con);
               // SqlCommand cmd = new SqlCommand("SELECT distinct(Project_Code+'.'+Maker_No+'.'+APG_No+'.'+APG_Name) as APGNo,Maker_No,APG_No  FROM Project_Master_Child WHERE Maker_No= '" + p + "'  and CompID='" + "0001" + "' and Project_Code='" + prjcode + "'", con);
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dap.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode child = new TreeNode();
                    child.Text = dr["APGNo"].ToString().Trim();
                   // string apgno= dr["APG_No"].ToString().Trim();
                    AddChild_ChildNodes(child, child.Text);

                    tr1.Nodes.Add(child);
                }
                con.Close();
            }
            catch (Exception ex)
            {
            }

        }
       
        public void BindTreeViewData()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                foreach (TreeNode tn in twProjectCreation.Nodes)
                {
                    tn.ForeColor = Color.Blue;
                    ColorNodes(tn);
                }
                fill_Tree2();
                Cursor.Current = Cursors.Default;

            }
            catch (Exception ex)
            {


            }
        }
        private void ProjectStructureCreation_Load(object sender, EventArgs e)
        {
            //   this.aPG_MasterTableAdapter.Fill(this.thermal_PMSDataSet.APG_Master);
            BindTreeViewData();
            var sa = (from k in db.Project_Masters where k.CompID == "0001" select new { k.Project_Code }).ToList();
            if(sa.Count>0)
            {
                cmbcode.DataSource = sa;
                cmbcode.DisplayMember = "Project_Code";
                cmbcode.ValueMember = "Project_Code";

                if(cmbcode.Items.Count>0)
                {
                    cmbcode.SelectedIndex = -1;
                }
                else
                {
                    cmbcode.SelectedIndex = -1;
                }
            }
            var sa1 = (from k in db.APG_Masters where k.CompID == "0001" select new { k.APG_Description }).ToList();
            if (sa1.Count > 0)
            {
                comboBox1.DataSource = sa1;
                comboBox1.DisplayMember = "APG_Description";
                comboBox1.ValueMember = "APG_Description";
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = -1;
                }
                else
                {
                    comboBox1.SelectedIndex = -1;
                }
            }

            var sa11 = (from k in db.APG_Masters where k.CompID == "0001" select new { k.APG_No,k.APG_Description }).ToList();
            if (sa11.Count > 0)
            {
               
                dataGridView4.DataSource = sa11;                
            }
            //var saa = (from k in db.Sp_Bind_APGDATA("0001") select k).ToList();
            //if(saa.Count>0)
            //{
            //    dataGridView4.DataSource = saa;
            //}
            //else
            //{

            //}
        }

        private void cmbmaker_Leave(object sender, EventArgs e)
        {

        }

        private void cmbcode_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Project_Master_Childs //join m in db.Maker_Masters on new { a=k.CompID,b=k.Project_Equp_Name} equals new { a=m.CompID,b=m.Maker_No}
                          where k.CompID == "0001" && k.Project_Code == cmbcode.Text.Trim() select new { k.Project_Equp_Name }).ToList();
                if(sa.Count>0)
                {
                    cmbmaker.DataSource = sa;
                    cmbmaker.DisplayMember = "Project_Equp_Name";
                    cmbmaker.ValueMember = "Project_Equp_Name";
                    if(cmbmaker.Items.Count>0)
                    {
                        cmbmaker.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbmaker.SelectedIndex = -1;
                    }
                }
                else
                {
                   
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void comboBox1_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.APG_Masters where k.CompID == "0001" && k.APG_Description == comboBox1.Text.Trim() select new { k.APG_No }).ToList();
                if(sa.Count>0)
                {
                    textBox1.Text = sa[0].APG_No;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                string apgno = textBox1.Text;
                string apgname = comboBox1.Text;
                if ((apgno != "" && apgname != "") || (apgno != null && apgname != null))
                {             
            
                    string[] row = new string[] { apgno, apgname };
                    dataGridView4.Rows.Add(row);

                }
                    
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // DataGridViewRow dgProductData.Rows[i] = dgProductData.Rows[dgProductData.CurrentRow.Index];
                if (dataGridView4.Rows.Count > 1)
                {
                    if (dataGridView4.Rows[dataGridView4.CurrentRow.Index].Cells[dataGridView4.CurrentCell.ColumnIndex].Value == "Remove")
                    {
                        if (dataGridView4.Rows.Count > 0)
                        {
                            foreach (DataGridViewCell oneCell in dataGridView4.SelectedCells)
                            {
                                if (oneCell.Selected)
                                    dataGridView4.Rows.RemoveAt(oneCell.RowIndex);
                            }

                        }
                    }
                }
            }

            catch (Exception)
            {
            }
        }
      public static  string code;
        public static string makno;
        private void twProjectCreation_DoubleClick(object sender, EventArgs e)
        {
        //    try
        //    {
                
        //        try
        //        {
        //            SqlCommand cmd2 = new SqlCommand("SP_Bind_ProjectStructure_Data", con);
        //            cmd2.CommandType = CommandType.StoredProcedure;
        //            string name1 = (twProjectCreation.SelectedNode.Text);
        //            Char delimiter1 = '.';
        //            String[] substrings1 = name1.Split(delimiter1);
        //            for (int R = 0; R < substrings1.Length - 3; R++)
        //            {
        //                if(R==0)
        //                {
        //                    code = substrings1[R].ToString();
        //                }
        //                else if(R==1)
        //                {
        //                    makno = substrings1[R].ToString();
        //                }
        //                else
        //                {

        //                }

        //            }
        //            string fullprojecycode = code + "." + makno;
        //                cmd2.Parameters.AddWithValue("@full_Project_Code",fullprojecycode);
        //            cmd2.Parameters.AddWithValue("@CompanyName", "0001");
        //            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        //            DataSet ds2 = new DataSet();
        //            da2.Fill(ds2, "x");
        //            if (ds2.Tables["X"].Rows.Count > 0)
        //            {
        //                dataGridView4.DataSource = ds2.Tables[0];
        //            }
        //            else
        //            {
        //                MessageBox.Show("No Records Found");
        //            }
        //            var sa = (from k in db.Project_Structure_Mains where k.Full_Project_Code == fullprojecycode select k).ToList();
        //            if (sa.Count > 0)
        //            {
        //                cmbcode.Text = sa[0].Project_Code;
        //                txtmaker.Text = sa[0].Maker_No;
        //                cmbmaker.Text = sa[0].Maker_Name;
                       
        //            }
        //        }
        //        catch (Exception ex)
        //    {

        //        throw;
        //    }
        //}
        //    catch (Exception ex)
        //    {

        //        throw;
        //    }
        }
        public bool sa;
        private void twProjectCreation_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {             

               twProjectCreation.SelectedNode = e.Node;
                if(e.Node.Level==1)
                {
                    contextMenuStrip1.Visible = true;
                    sa = true;

                        }
                else
                {
                    sa = false;
                    contextMenuStrip1.Visible = false;
                }
                
            }
        }

        private void addAPGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(sa==true)
            {
                groupBox2.Visible = true;
             //string Nodename=   twProjectCreation.SelectedNode.Text;
             //   //Char delimiter1 = '.';
             //   //String[] substrings1 =
             //   String mNo = Nodename(5,2);
             //   string mName = Nodename.Substring(5, 2);
                String value = twProjectCreation.SelectedNode.Text;
                int maklenght = value.Length;
                int startIndex = 5;
                int length = 2;
                int maknamelen = maklenght - 8;
                String ProjectCode = value.Substring(0, 4);
                String makerno = value.Substring(startIndex, length);
                String makname = value.Substring(8, maknamelen);
                label5.Text = makerno;
                label7.Text = makname;
                label9.Text = ProjectCode;
                //for (int R = 0; R < substrings1.Length - 1; R++)
                //{
                //    if(R==1)
                //    {

                //    }

                //}
            }
            else
            {
                MessageBox.Show("Please Select Maker to Add APG...");
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
