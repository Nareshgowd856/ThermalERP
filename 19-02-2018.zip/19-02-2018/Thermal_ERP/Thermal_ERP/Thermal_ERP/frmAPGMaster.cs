﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmAPGMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public frmAPGMaster()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are You Sure Want to Delete this Record ", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    db.Sp_Delete_APG_Master("0001", txtapgno.Text);
                    BindGrid();
                    return;
                }
            }
            catch (Exception 
            ex)
            {

                throw;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAPGMaster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.APG_Master' table. You can move, or remove it, as needed.
            //  this.aPG_MasterTableAdapter.Fill(this.thermal_PMSDataSet.APG_Master);
            BindGrid();
        }
        public void BindGrid()
        {
            var sa = (from k in db.APG_Masters where k.CompID == "0001" select new { k.APG_No,k.APG_Description}).ToList();
            if(sa.Count>0)
            {
                dataGridView1.DataSource = sa;
            }
        }
        public void Clear()
        {
            txtapgno.Text = "";
            txtdsc.Text = "";
            textBox3.Text = "";
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //aPG_MasterTableAdapter.InsertAPG(textBox1.Text, textBox2.Text, textBox3.Text, "0001");
            //dataGridView1.Refresh();
            try
            {
               if(txtapgno.Text==""||txtapgno.Text==null)
                {
                    MessageBox.Show("Please Enter APG No");
                    txtapgno.Focus();
                    return;
                }
               else
                {
                    if((from k in db.APG_Masters where k.CompID=="0001" && k.APG_No==txtapgno.Text select k ).Count()>0)
                    {
                        db.Sp_Delete_APG_Master("0001", txtapgno.Text);
                        APG_Master a = new APG_Master();
                        a.APG_No = txtapgno.Text;
                        a.APG_Description = (txtdsc.Text == "") ? "" : txtdsc.Text;
                        a.APG_ApplicableTo = (textBox3.Text == "") ? "" : textBox3.Text;
                        a.CompID = "0001";
                        a.Created_By = "";
                        a.Created_On = DateTime.Now;
                        a.Modified_By = "";
                        a.Modified_On = DateTime.Now;
                        db.APG_Masters.InsertOnSubmit(a);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Sucessfully");
                        BindGrid();
                        Clear();
                        return;
                    }
                    else
                    {
                        APG_Master a = new APG_Master();
                        a.APG_No = txtapgno.Text;
                        a.APG_Description = (txtdsc.Text == "") ? "" : txtdsc.Text;
                        a.APG_ApplicableTo = (textBox3.Text == "") ? "" : textBox3.Text;
                        a.CompID = "0001";
                        a.Created_By = "";
                        a.Created_On = DateTime.Now;
                        a.Modified_By = "";
                        a.Modified_On = DateTime.Now;
                        db.APG_Masters.InsertOnSubmit(a);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Sucessfully");
                        BindGrid();
                        Clear();
                        return;
                    }
               
                }

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    string apgno = dataGridView1.Rows[e.RowIndex].Cells["APG_No"].Value.ToString();
                    var sa = (from k in db.APG_Masters where k.CompID == "0001" && k.APG_No == apgno select new { k.APG_No, k.APG_Description }).ToList();
                    if(sa.Count>0)
                    {
                        txtapgno.Text = sa[0].APG_No;
                        txtdsc.Text = sa[0].APG_Description;

                    }
                }
                
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
