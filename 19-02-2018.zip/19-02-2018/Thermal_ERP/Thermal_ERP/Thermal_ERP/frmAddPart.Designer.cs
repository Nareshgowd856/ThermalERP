﻿namespace Thermal_ERP
{
    partial class frmAddPart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtApgname = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtapgno = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtplno = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtmarkerno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtprojectcode = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dpdate = new System.Windows.Forms.DateTimePicker();
            this.txtverno = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDia = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtW2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtThickness = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtlength = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtfgwt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtrmwt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtDwt = new System.Windows.Forms.TextBox();
            this.txtod = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtmaindrawingno = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtpartno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdescription = new System.Windows.Forms.TextBox();
            this.cmbvariant = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbPartname = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.cmbPartGroup = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbSpecification = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbThickNo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbRmtype = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDensity = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cmbptsno = new System.Windows.Forms.ComboBox();
            this.cmbUom = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtMMitem = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtdrawingno = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.chkIbr = new System.Windows.Forms.CheckBox();
            this.chkEn = new System.Windows.Forms.CheckBox();
            this.chkMtc = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.dgActivity = new System.Windows.Forms.DataGridView();
            this.Activity_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Activity_Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Work_Center = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Person_Rep = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_CompletionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_Duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_Completiondate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_Duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Version_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocumentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_Change = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Creted_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Modified_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reviewd_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label26 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label25 = new System.Windows.Forms.Label();
            this.txtEqpName = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.materialGradesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.material_GradesTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter();
            this.materialGradesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.txtRevStatus = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgActivity)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(728, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 17);
            this.label10.TabIndex = 7;
            this.label10.Text = "ADD /MODIFY PART DATA";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtRevStatus);
            this.groupBox1.Controls.Add(this.txtApgname);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.txtapgno);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtplno);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtmarkerno);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtprojectcode);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(14, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(985, 48);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtApgname
            // 
            this.txtApgname.Location = new System.Drawing.Point(558, 15);
            this.txtApgname.Name = "txtApgname";
            this.txtApgname.Size = new System.Drawing.Size(126, 23);
            this.txtApgname.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(449, 15);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 15);
            this.label27.TabIndex = 8;
            this.label27.Text = "Equipment  Name";
            // 
            // txtapgno
            // 
            this.txtapgno.Location = new System.Drawing.Point(368, 15);
            this.txtapgno.Name = "txtapgno";
            this.txtapgno.Size = new System.Drawing.Size(75, 23);
            this.txtapgno.TabIndex = 3;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(316, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(49, 15);
            this.label28.TabIndex = 6;
            this.label28.Text = "APG No";
            // 
            // txtplno
            // 
            this.txtplno.Location = new System.Drawing.Point(761, 12);
            this.txtplno.Name = "txtplno";
            this.txtplno.Size = new System.Drawing.Size(81, 23);
            this.txtplno.TabIndex = 2;
            this.txtplno.TextChanged += new System.EventHandler(this.txtplno_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(687, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 15);
            this.label19.TabIndex = 4;
            this.label19.Text = "Part List No";
            // 
            // txtmarkerno
            // 
            this.txtmarkerno.Location = new System.Drawing.Point(233, 15);
            this.txtmarkerno.Name = "txtmarkerno";
            this.txtmarkerno.Size = new System.Drawing.Size(77, 23);
            this.txtmarkerno.TabIndex = 1;
            this.txtmarkerno.TextChanged += new System.EventHandler(this.txtmarkerno_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(172, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 15);
            this.label18.TabIndex = 2;
            this.label18.Text = "Maker No";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // txtprojectcode
            // 
            this.txtprojectcode.Location = new System.Drawing.Point(80, 15);
            this.txtprojectcode.Name = "txtprojectcode";
            this.txtprojectcode.Size = new System.Drawing.Size(86, 23);
            this.txtprojectcode.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "Project Code";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(619, 379);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 15);
            this.label22.TabIndex = 9;
            this.label22.Text = "Date";
            // 
            // dpdate
            // 
            this.dpdate.Enabled = false;
            this.dpdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpdate.Location = new System.Drawing.Point(664, 376);
            this.dpdate.Name = "dpdate";
            this.dpdate.Size = new System.Drawing.Size(101, 23);
            this.dpdate.TabIndex = 8;
            // 
            // txtverno
            // 
            this.txtverno.Enabled = false;
            this.txtverno.Location = new System.Drawing.Point(528, 374);
            this.txtverno.Name = "txtverno";
            this.txtverno.ReadOnly = true;
            this.txtverno.Size = new System.Drawing.Size(67, 23);
            this.txtverno.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(479, 377);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 15);
            this.label21.TabIndex = 6;
            this.label21.Text = "Ver No";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.tabControl1, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(14, 84);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(985, 449);
            this.tableLayoutPanel3.TabIndex = 12;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(979, 438);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.dpdate);
            this.tabPage1.Controls.Add(this.txtverno);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Controls.Add(this.chkIbr);
            this.tabPage1.Controls.Add(this.chkEn);
            this.tabPage1.Controls.Add(this.chkMtc);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(971, 410);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tech Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label39.Location = new System.Drawing.Point(9, 281);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(141, 15);
            this.label39.TabIndex = 44;
            this.label39.Text = "Raw Material Dimensions";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(67, 373);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(391, 23);
            this.textBox1.TabIndex = 20;
            this.textBox1.Visible = false;
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(9, 377);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 15);
            this.label33.TabIndex = 19;
            this.label33.Text = "Remarks";
            this.label33.Visible = false;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 10;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 124F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 74F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 89F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 127F));
            this.tableLayoutPanel2.Controls.Add(this.label9, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtDia, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtW2, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtThickness, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtlength, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtfgwt, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label15, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtrmwt, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label16, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtDwt, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtod, 9, 1);
            this.tableLayoutPanel2.Controls.Add(this.label36, 8, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(7, 299);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(721, 71);
            this.tableLayoutPanel2.TabIndex = 9;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 35);
            this.label9.TabIndex = 0;
            this.label9.Text = "Dia / W1";
            // 
            // txtDia
            // 
            this.txtDia.Location = new System.Drawing.Point(93, 4);
            this.txtDia.Name = "txtDia";
            this.txtDia.Size = new System.Drawing.Size(60, 23);
            this.txtDia.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(218, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "W2";
            // 
            // txtW2
            // 
            this.txtW2.Location = new System.Drawing.Point(293, 4);
            this.txtW2.Name = "txtW2";
            this.txtW2.Size = new System.Drawing.Size(61, 23);
            this.txtW2.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(383, 1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Thickness";
            // 
            // txtThickness
            // 
            this.txtThickness.Location = new System.Drawing.Point(464, 4);
            this.txtThickness.Name = "txtThickness";
            this.txtThickness.Size = new System.Drawing.Size(51, 23);
            this.txtThickness.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(545, 1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 15);
            this.label13.TabIndex = 6;
            this.label13.Text = "Length";
            // 
            // txtlength
            // 
            this.txtlength.Location = new System.Drawing.Point(616, 4);
            this.txtlength.Name = "txtlength";
            this.txtlength.Size = new System.Drawing.Size(67, 23);
            this.txtlength.TabIndex = 3;
            this.txtlength.Leave += new System.EventHandler(this.txtlength_Leave);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 15);
            this.label14.TabIndex = 8;
            this.label14.Text = "FG Wt";
            // 
            // txtfgwt
            // 
            this.txtfgwt.Location = new System.Drawing.Point(93, 40);
            this.txtfgwt.Name = "txtfgwt";
            this.txtfgwt.Size = new System.Drawing.Size(84, 23);
            this.txtfgwt.TabIndex = 4;
            this.txtfgwt.Leave += new System.EventHandler(this.txtfgwt_Leave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(218, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 15);
            this.label15.TabIndex = 10;
            this.label15.Text = "RM Wt";
            // 
            // txtrmwt
            // 
            this.txtrmwt.Location = new System.Drawing.Point(293, 40);
            this.txtrmwt.Name = "txtrmwt";
            this.txtrmwt.Size = new System.Drawing.Size(61, 23);
            this.txtrmwt.TabIndex = 5;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(383, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 15);
            this.label16.TabIndex = 12;
            this.label16.Text = "D Wt";
            // 
            // txtDwt
            // 
            this.txtDwt.Location = new System.Drawing.Point(464, 40);
            this.txtDwt.Name = "txtDwt";
            this.txtDwt.Size = new System.Drawing.Size(51, 23);
            this.txtDwt.TabIndex = 6;
            // 
            // txtod
            // 
            this.txtod.Location = new System.Drawing.Point(616, 40);
            this.txtod.Name = "txtod";
            this.txtod.Size = new System.Drawing.Size(100, 23);
            this.txtod.TabIndex = 13;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(545, 37);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 15);
            this.label36.TabIndex = 14;
            this.label36.Text = "OD";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.txtmaindrawingno, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtQty, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label37, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label30, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtpartno, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtdescription, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.cmbvariant, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbPartname, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button2, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label32, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbPartGroup, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.cmbSpecification, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.cmbThickNo, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbRmtype, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label23, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtDensity, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.label34, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbptsno, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbUom, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label35, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtMMitem, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.label24, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtdrawingno, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.label29, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.button1, 5, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(7, 8);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(971, 262);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // txtmaindrawingno
            // 
            this.txtmaindrawingno.Location = new System.Drawing.Point(802, 5);
            this.txtmaindrawingno.Name = "txtmaindrawingno";
            this.txtmaindrawingno.Size = new System.Drawing.Size(156, 23);
            this.txtmaindrawingno.TabIndex = 45;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(496, 71);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 23);
            this.txtQty.TabIndex = 20;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(680, 2);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(114, 17);
            this.label37.TabIndex = 44;
            this.label37.Text = "Main Drawing No";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Part No";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(388, 68);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 15);
            this.label30.TabIndex = 19;
            this.label30.Text = "Qty";
            // 
            // txtpartno
            // 
            this.txtpartno.Location = new System.Drawing.Point(89, 38);
            this.txtpartno.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtpartno.Name = "txtpartno";
            this.txtpartno.Size = new System.Drawing.Size(102, 23);
            this.txtpartno.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Description";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Type";
            // 
            // txtdescription
            // 
            this.txtdescription.Location = new System.Drawing.Point(89, 73);
            this.txtdescription.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtdescription.Multiline = true;
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(291, 62);
            this.txtdescription.TabIndex = 3;
            // 
            // cmbvariant
            // 
            this.cmbvariant.FormattingEnabled = true;
            this.cmbvariant.Location = new System.Drawing.Point(89, 147);
            this.cmbvariant.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbvariant.Name = "cmbvariant";
            this.cmbvariant.Size = new System.Drawing.Size(206, 23);
            this.cmbvariant.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(5, 2);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 17);
            this.label20.TabIndex = 31;
            this.label20.Text = "Part Group";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(388, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Part Name";
            // 
            // cmbPartname
            // 
            this.cmbPartname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPartname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPartname.FormattingEnabled = true;
            this.cmbPartname.Location = new System.Drawing.Point(496, 36);
            this.cmbPartname.Name = "cmbPartname";
            this.cmbPartname.Size = new System.Drawing.Size(164, 23);
            this.cmbPartname.TabIndex = 2;
            this.cmbPartname.Leave += new System.EventHandler(this.comboBox7_Leave);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(680, 36);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 27);
            this.button2.TabIndex = 28;
            this.button2.Text = "New";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(388, 2);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 17);
            this.label32.TabIndex = 44;
            this.label32.Text = "Main Assembly";
            // 
            // cmbPartGroup
            // 
            this.cmbPartGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPartGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPartGroup.FormattingEnabled = true;
            this.cmbPartGroup.Items.AddRange(new object[] {
            "Main Assembly",
            "Sub Assembly",
            "Brought Out Component"});
            this.cmbPartGroup.Location = new System.Drawing.Point(89, 5);
            this.cmbPartGroup.Name = "cmbPartGroup";
            this.cmbPartGroup.Size = new System.Drawing.Size(194, 23);
            this.cmbPartGroup.TabIndex = 0;
            this.cmbPartGroup.SelectedIndexChanged += new System.EventHandler(this.cmbPartGroup_SelectedIndexChanged);
            this.cmbPartGroup.Leave += new System.EventHandler(this.comboBox6_Leave);
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(496, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(164, 23);
            this.comboBox1.TabIndex = 45;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(680, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "UOM";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(388, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Specification";
            // 
            // cmbSpecification
            // 
            this.cmbSpecification.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSpecification.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSpecification.DisplayMember = "Material_Grade";
            this.cmbSpecification.FormattingEnabled = true;
            this.cmbSpecification.Location = new System.Drawing.Point(496, 147);
            this.cmbSpecification.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbSpecification.Name = "cmbSpecification";
            this.cmbSpecification.Size = new System.Drawing.Size(174, 23);
            this.cmbSpecification.TabIndex = 7;
            this.cmbSpecification.ValueMember = "Material_Grade";
            this.cmbSpecification.Leave += new System.EventHandler(this.comboBox2_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(680, 142);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 15);
            this.label8.TabIndex = 30;
            this.label8.Text = "Thick / Sch No";
            // 
            // cmbThickNo
            // 
            this.cmbThickNo.FormattingEnabled = true;
            this.cmbThickNo.Location = new System.Drawing.Point(802, 145);
            this.cmbThickNo.Name = "cmbThickNo";
            this.cmbThickNo.Size = new System.Drawing.Size(83, 23);
            this.cmbThickNo.TabIndex = 9;
            this.cmbThickNo.Leave += new System.EventHandler(this.comboBox5_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 177);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "RM Type";
            // 
            // cmbRmtype
            // 
            this.cmbRmtype.Enabled = false;
            this.cmbRmtype.FormattingEnabled = true;
            this.cmbRmtype.Items.AddRange(new object[] {
            "Nos",
            "Kgs",
            "MT",
            "Mtrs",
            "Packs"});
            this.cmbRmtype.Location = new System.Drawing.Point(89, 182);
            this.cmbRmtype.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbRmtype.Name = "cmbRmtype";
            this.cmbRmtype.Size = new System.Drawing.Size(100, 23);
            this.cmbRmtype.TabIndex = 8;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(680, 177);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 15);
            this.label23.TabIndex = 34;
            this.label23.Text = "Density";
            // 
            // txtDensity
            // 
            this.txtDensity.Enabled = false;
            this.txtDensity.Location = new System.Drawing.Point(802, 180);
            this.txtDensity.Name = "txtDensity";
            this.txtDensity.Size = new System.Drawing.Size(79, 23);
            this.txtDensity.TabIndex = 10;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(388, 177);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(52, 17);
            this.label34.TabIndex = 46;
            this.label34.Text = "PTS No";
            // 
            // cmbptsno
            // 
            this.cmbptsno.FormattingEnabled = true;
            this.cmbptsno.Location = new System.Drawing.Point(496, 180);
            this.cmbptsno.Name = "cmbptsno";
            this.cmbptsno.Size = new System.Drawing.Size(174, 23);
            this.cmbptsno.TabIndex = 47;
            // 
            // cmbUom
            // 
            this.cmbUom.FormattingEnabled = true;
            this.cmbUom.Location = new System.Drawing.Point(802, 73);
            this.cmbUom.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbUom.Name = "cmbUom";
            this.cmbUom.Size = new System.Drawing.Size(72, 23);
            this.cmbUom.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(89, 217);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(282, 40);
            this.textBox2.TabIndex = 48;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(5, 214);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(66, 17);
            this.label35.TabIndex = 50;
            this.label35.Text = "Spl Notes";
            // 
            // txtMMitem
            // 
            this.txtMMitem.Enabled = false;
            this.txtMMitem.Location = new System.Drawing.Point(802, 217);
            this.txtMMitem.Name = "txtMMitem";
            this.txtMMitem.Size = new System.Drawing.Size(117, 23);
            this.txtMMitem.TabIndex = 12;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(680, 214);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 15);
            this.label24.TabIndex = 39;
            this.label24.Text = "MM Item Code";
            // 
            // txtdrawingno
            // 
            this.txtdrawingno.Location = new System.Drawing.Point(496, 217);
            this.txtdrawingno.Name = "txtdrawingno";
            this.txtdrawingno.Size = new System.Drawing.Size(176, 23);
            this.txtdrawingno.TabIndex = 51;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(388, 214);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(80, 17);
            this.label29.TabIndex = 52;
            this.label29.Text = "Drawing No";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Desktop;
            this.button1.ForeColor = System.Drawing.Color.Coral;
            this.button1.Location = new System.Drawing.Point(802, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 23);
            this.button1.TabIndex = 53;
            this.button1.Text = "Copy Part Data";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // chkIbr
            // 
            this.chkIbr.AutoSize = true;
            this.chkIbr.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIbr.ForeColor = System.Drawing.Color.Red;
            this.chkIbr.Location = new System.Drawing.Point(747, 303);
            this.chkIbr.Name = "chkIbr";
            this.chkIbr.Size = new System.Drawing.Size(67, 19);
            this.chkIbr.TabIndex = 11;
            this.chkIbr.Text = "IBR Cert";
            this.chkIbr.UseVisualStyleBackColor = true;
            // 
            // chkEn
            // 
            this.chkEn.AutoSize = true;
            this.chkEn.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEn.ForeColor = System.Drawing.Color.Red;
            this.chkEn.Location = new System.Drawing.Point(747, 323);
            this.chkEn.Name = "chkEn";
            this.chkEn.Size = new System.Drawing.Size(65, 19);
            this.chkEn.TabIndex = 43;
            this.chkEn.Text = "EN Cert";
            this.chkEn.UseVisualStyleBackColor = true;
            // 
            // chkMtc
            // 
            this.chkMtc.AutoSize = true;
            this.chkMtc.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMtc.ForeColor = System.Drawing.Color.Red;
            this.chkMtc.Location = new System.Drawing.Point(747, 341);
            this.chkMtc.Name = "chkMtc";
            this.chkMtc.Size = new System.Drawing.Size(75, 19);
            this.chkMtc.TabIndex = 42;
            this.chkMtc.Text = "MTC Cert";
            this.chkMtc.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(971, 410);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Stock Availbility";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Linen;
            this.groupBox5.Controls.Add(this.dataGridView3);
            this.groupBox5.Location = new System.Drawing.Point(-9, 8);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(974, 395);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.Column9});
            this.dataGridView3.Location = new System.Drawing.Point(7, 22);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(853, 366);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Avaiable Size";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "UOM";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Qty Available";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "MTC Cert";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "IBR Cert";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "EN Cert";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Reserve Stock";
            this.Column9.Name = "Column9";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(971, 410);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Activity Chart";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Linen;
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.dgActivity);
            this.groupBox4.Location = new System.Drawing.Point(-9, 8);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(974, 395);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.OrangeRed;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(560, 13);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(337, 17);
            this.label38.TabIndex = 1;
            this.label38.Text = "Please Enter Dates yyyy-MM-dd HH:mm Format Only";
            // 
            // dgActivity
            // 
            this.dgActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgActivity.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Activity_Code,
            this.Activity_Description,
            this.Work_Center,
            this.Person_Rep,
            this.Planned_StartDate,
            this.Planned_CompletionDate,
            this.Planned_Duration,
            this.Actual_StartDate,
            this.Actual_Completiondate,
            this.Actual_Duration,
            this.Status});
            this.dgActivity.Location = new System.Drawing.Point(7, 35);
            this.dgActivity.Name = "dgActivity";
            this.dgActivity.Size = new System.Drawing.Size(961, 353);
            this.dgActivity.TabIndex = 0;
            this.dgActivity.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgActivity_CellContentClick);
            this.dgActivity.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgActivity_CellEndEdit);
            this.dgActivity.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgActivity_CellValidating);
            this.dgActivity.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgActivity_EditingControlShowing);
            this.dgActivity.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgActivity_RowPostPaint);
            // 
            // Activity_Code
            // 
            this.Activity_Code.DataPropertyName = "Activity_Code";
            this.Activity_Code.HeaderText = "Activity Code";
            this.Activity_Code.Name = "Activity_Code";
            // 
            // Activity_Description
            // 
            this.Activity_Description.DataPropertyName = "Activity_Description";
            this.Activity_Description.HeaderText = "Activity Name";
            this.Activity_Description.Name = "Activity_Description";
            // 
            // Work_Center
            // 
            this.Work_Center.DataPropertyName = "Work_Center";
            this.Work_Center.HeaderText = "Work Center";
            this.Work_Center.Name = "Work_Center";
            // 
            // Person_Rep
            // 
            this.Person_Rep.DataPropertyName = "Person_Rep";
            this.Person_Rep.HeaderText = "Person Resp";
            this.Person_Rep.Name = "Person_Rep";
            // 
            // Planned_StartDate
            // 
            this.Planned_StartDate.DataPropertyName = "Planned_StartDate";
            dataGridViewCellStyle1.Format = "G";
            dataGridViewCellStyle1.NullValue = null;
            this.Planned_StartDate.DefaultCellStyle = dataGridViewCellStyle1;
            this.Planned_StartDate.HeaderText = "Planned Start Date";
            this.Planned_StartDate.Name = "Planned_StartDate";
            // 
            // Planned_CompletionDate
            // 
            this.Planned_CompletionDate.DataPropertyName = "Planned_CompletionDate";
            dataGridViewCellStyle2.Format = "G";
            this.Planned_CompletionDate.DefaultCellStyle = dataGridViewCellStyle2;
            this.Planned_CompletionDate.HeaderText = "Planned Completion Date";
            this.Planned_CompletionDate.Name = "Planned_CompletionDate";
            // 
            // Planned_Duration
            // 
            this.Planned_Duration.DataPropertyName = "Planned_Duration";
            this.Planned_Duration.HeaderText = "Planed Duration";
            this.Planned_Duration.Name = "Planned_Duration";
            // 
            // Actual_StartDate
            // 
            this.Actual_StartDate.DataPropertyName = "Actual_StartDate";
            this.Actual_StartDate.HeaderText = "Actual Start Date";
            this.Actual_StartDate.Name = "Actual_StartDate";
            this.Actual_StartDate.ReadOnly = true;
            // 
            // Actual_Completiondate
            // 
            this.Actual_Completiondate.DataPropertyName = "Actual_Completiondate";
            this.Actual_Completiondate.HeaderText = "Actual Completion Date";
            this.Actual_Completiondate.Name = "Actual_Completiondate";
            this.Actual_Completiondate.ReadOnly = true;
            // 
            // Actual_Duration
            // 
            this.Actual_Duration.DataPropertyName = "Actual_Duration";
            this.Actual_Duration.HeaderText = "Actual Duration";
            this.Actual_Duration.Name = "Actual_Duration";
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(971, 410);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Version History";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Linen;
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Location = new System.Drawing.Point(3, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(962, 395);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Version_No,
            this.Version_Date,
            this.DocumentNo,
            this.Version_Change,
            this.Creted_By,
            this.Modified_By,
            this.Reviewd_By});
            this.dataGridView1.Location = new System.Drawing.Point(7, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(853, 366);
            this.dataGridView1.TabIndex = 0;
            // 
            // Version_No
            // 
            this.Version_No.DataPropertyName = "Version_No";
            this.Version_No.HeaderText = "Ver No";
            this.Version_No.Name = "Version_No";
            // 
            // Version_Date
            // 
            this.Version_Date.DataPropertyName = "Version_Date";
            this.Version_Date.HeaderText = "Ver Date";
            this.Version_Date.Name = "Version_Date";
            // 
            // DocumentNo
            // 
            this.DocumentNo.DataPropertyName = "DocumentNo";
            this.DocumentNo.HeaderText = "DCN No";
            this.DocumentNo.Name = "DocumentNo";
            // 
            // Version_Change
            // 
            this.Version_Change.DataPropertyName = "Version_Change";
            this.Version_Change.HeaderText = "Changes Made";
            this.Version_Change.Name = "Version_Change";
            // 
            // Creted_By
            // 
            this.Creted_By.DataPropertyName = "Creted_By";
            this.Creted_By.HeaderText = "Created By";
            this.Creted_By.Name = "Creted_By";
            // 
            // Modified_By
            // 
            this.Modified_By.DataPropertyName = "Modified_By";
            this.Modified_By.HeaderText = "Reviewed By";
            this.Modified_By.Name = "Modified_By";
            // 
            // Reviewd_By
            // 
            this.Reviewd_By.DataPropertyName = "Reviewd_By";
            this.Reviewd_By.HeaderText = "Approved By";
            this.Reviewd_By.Name = "Reviewd_By";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(269, 542);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(60, 15);
            this.linkLabel2.TabIndex = 18;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "linkLabel2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(160, 542);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 15);
            this.label26.TabIndex = 17;
            this.label26.Text = "Last Modified By";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(85, 542);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(60, 15);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "linkLabel1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 542);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 15);
            this.label25.TabIndex = 15;
            this.label25.Text = "Created By";
            // 
            // txtEqpName
            // 
            this.txtEqpName.Location = new System.Drawing.Point(443, 8);
            this.txtEqpName.Name = "txtEqpName";
            this.txtEqpName.Size = new System.Drawing.Size(187, 23);
            this.txtEqpName.TabIndex = 13;
            this.txtEqpName.Visible = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(328, 11);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 15);
            this.label31.TabIndex = 14;
            this.label31.Text = "Equipment Name";
            this.label31.Visible = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Desktop;
            this.button8.ForeColor = System.Drawing.Color.Cornsilk;
            this.button8.Location = new System.Drawing.Point(924, 536);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 28);
            this.button8.TabIndex = 17;
            this.button8.Text = "Close";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Desktop;
            this.button7.ForeColor = System.Drawing.Color.Cornsilk;
            this.button7.Location = new System.Drawing.Point(841, 536);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 28);
            this.button7.TabIndex = 15;
            this.button7.Text = "Submit";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Desktop;
            this.button6.ForeColor = System.Drawing.Color.Cornsilk;
            this.button6.Location = new System.Drawing.Point(760, 536);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 28);
            this.button6.TabIndex = 16;
            this.button6.Text = "Reset";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // materialGradesBindingSource
            // 
            this.materialGradesBindingSource.DataMember = "Material_Grades";
            this.materialGradesBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // material_GradesTableAdapter
            // 
            this.material_GradesTableAdapter.ClearBeforeFill = true;
            // 
            // materialGradesBindingSource1
            // 
            this.materialGradesBindingSource1.DataMember = "Material_Grades";
            this.materialGradesBindingSource1.DataSource = this.thermal_PMSDataSet;
            // 
            // txtRevStatus
            // 
            this.txtRevStatus.Location = new System.Drawing.Point(872, 12);
            this.txtRevStatus.Name = "txtRevStatus";
            this.txtRevStatus.ReadOnly = true;
            this.txtRevStatus.Size = new System.Drawing.Size(100, 23);
            this.txtRevStatus.TabIndex = 9;
            // 
            // frmAddPart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtEqpName);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmAddPart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAddPart";
            this.Load += new System.EventHandler(this.frmAddPart_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgActivity)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtmarkerno;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtprojectcode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtplno;
        private System.Windows.Forms.Label label19;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource materialGradesBindingSource;
        private Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter material_GradesTableAdapter;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dpdate;
        private System.Windows.Forms.TextBox txtverno;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDia;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtW2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtThickness;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtlength;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtfgwt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtrmwt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtDwt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpartno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdescription;
        private System.Windows.Forms.ComboBox cmbvariant;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbPartGroup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbPartname;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbRmtype;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbSpecification;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbUom;
        private System.Windows.Forms.ComboBox cmbThickNo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDensity;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtMMitem;
        private System.Windows.Forms.CheckBox chkIbr;
        private System.Windows.Forms.CheckBox chkMtc;
        private System.Windows.Forms.CheckBox chkEn;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column9;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgActivity;
        private System.Windows.Forms.TextBox txtApgname;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtapgno;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.BindingSource materialGradesBindingSource1;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtEqpName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocumentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_Change;
        private System.Windows.Forms.DataGridViewTextBoxColumn Creted_By;
        private System.Windows.Forms.DataGridViewTextBoxColumn Modified_By;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reviewd_By;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cmbptsno;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtod;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtdrawingno;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtmaindrawingno;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Work_Center;
        private System.Windows.Forms.DataGridViewTextBoxColumn Person_Rep;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_CompletionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_Duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_Completiondate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_Duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtRevStatus;
    }
}