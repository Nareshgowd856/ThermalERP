﻿namespace Thermal_ERP
{
    partial class frmCreateProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCreateProject));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.txtDescrption = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbClient = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFinalClient = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dpdate = new System.Windows.Forms.DateTimePicker();
            this.dgEqup = new System.Windows.Forms.DataGridView();
            this.Maker_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Project_Equp_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chkConcessReq = new System.Windows.Forms.CheckBox();
            this.chkInspandAccpbyClient = new System.Windows.Forms.CheckBox();
            this.chkInspbyAuth = new System.Windows.Forms.CheckBox();
            this.chkQAP = new System.Windows.Forms.CheckBox();
            this.txtWarrantyPeriod = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chkSplmatreq = new System.Windows.Forms.CheckBox();
            this.txtsplMatreq = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkCompDoscGost = new System.Windows.Forms.CheckBox();
            this.chkComplocalreg = new System.Windows.Forms.CheckBox();
            this.chkInspByTPIA = new System.Windows.Forms.CheckBox();
            this.chkinspbyCIB = new System.Windows.Forms.CheckBox();
            this.chkNationalBoardreg = new System.Windows.Forms.CheckBox();
            this.chkASME = new System.Windows.Forms.CheckBox();
            this.chkCEMarketing = new System.Windows.Forms.CheckBox();
            this.cmbCodeOfConstruction = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbCurrency = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbProjectSector = new System.Windows.Forms.ComboBox();
            this.cmbProjectClass = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dgPymentterms = new System.Windows.Forms.DataGridView();
            this.Mile_Stone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Per_Payments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TriggeringPoint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label12 = new System.Windows.Forms.Label();
            this.txtLDforDelDrawing = new System.Windows.Forms.TextBox();
            this.txtLDfodelayd = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.project_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.project_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.project_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.project_MasterTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Project_MasterTableAdapter();
            this.tableAdapterManager = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.TableAdapterManager();
            this.projectMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEqup)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPymentterms)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.project_MasterBindingNavigator)).BeginInit();
            this.project_MasterBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.project_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectMasterBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtProjectCode, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtDescrption, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.cmbClient, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtFinalClient, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.dpdate, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.dgEqup, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(27, 47);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(607, 258);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project Code";
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.Location = new System.Drawing.Point(146, 3);
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.Size = new System.Drawing.Size(116, 23);
            this.txtProjectCode.TabIndex = 1;
            this.txtProjectCode.Leave += new System.EventHandler(this.txtProjectCode_Leave);
            // 
            // txtDescrption
            // 
            this.txtDescrption.Location = new System.Drawing.Point(146, 33);
            this.txtDescrption.Name = "txtDescrption";
            this.txtDescrption.Size = new System.Drawing.Size(430, 23);
            this.txtDescrption.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Client / Buyer";
            // 
            // cmbClient
            // 
            this.cmbClient.FormattingEnabled = true;
            this.cmbClient.Location = new System.Drawing.Point(146, 63);
            this.cmbClient.Name = "cmbClient";
            this.cmbClient.Size = new System.Drawing.Size(321, 23);
            this.cmbClient.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Final Client / Owner";
            // 
            // txtFinalClient
            // 
            this.txtFinalClient.Location = new System.Drawing.Point(146, 93);
            this.txtFinalClient.Name = "txtFinalClient";
            this.txtFinalClient.Size = new System.Drawing.Size(321, 23);
            this.txtFinalClient.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Delivery Date";
            // 
            // dpdate
            // 
            this.dpdate.Location = new System.Drawing.Point(146, 122);
            this.dpdate.Name = "dpdate";
            this.dpdate.Size = new System.Drawing.Size(233, 23);
            this.dpdate.TabIndex = 9;
            // 
            // dgEqup
            // 
            this.dgEqup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEqup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Maker_No,
            this.Project_Equp_Name,
            this.Column5});
            this.dgEqup.Location = new System.Drawing.Point(146, 152);
            this.dgEqup.Name = "dgEqup";
            this.dgEqup.Size = new System.Drawing.Size(458, 103);
            this.dgEqup.TabIndex = 10;
            this.dgEqup.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgEqup_CellClick);
            this.dgEqup.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgEqup_CellEndEdit);
            this.dgEqup.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgEqup_EditingControlShowing);
            // 
            // Maker_No
            // 
            this.Maker_No.DataPropertyName = "Maker_No";
            this.Maker_No.HeaderText = "Makere No";
            this.Maker_No.MaxInputLength = 2;
            this.Maker_No.Name = "Maker_No";
            // 
            // Project_Equp_Name
            // 
            this.Project_Equp_Name.DataPropertyName = "Project_Equp_Name";
            this.Project_Equp_Name.HeaderText = "Description of Item";
            this.Project_Equp_Name.Name = "Project_Equp_Name";
            this.Project_Equp_Name.Width = 250;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "";
            this.Column5.Name = "Column5";
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column5.Text = "Remove";
            this.Column5.UseColumnTextForButtonValue = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Equipment Name /Items";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 15);
            this.label2.TabIndex = 12;
            this.label2.Text = "Project Description";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(27, 324);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1009, 276);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chkConcessReq);
            this.tabPage1.Controls.Add(this.chkInspandAccpbyClient);
            this.tabPage1.Controls.Add(this.chkInspbyAuth);
            this.tabPage1.Controls.Add(this.chkQAP);
            this.tabPage1.Controls.Add(this.txtWarrantyPeriod);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.chkSplmatreq);
            this.tabPage1.Controls.Add(this.txtsplMatreq);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.chkCompDoscGost);
            this.tabPage1.Controls.Add(this.chkComplocalreg);
            this.tabPage1.Controls.Add(this.chkInspByTPIA);
            this.tabPage1.Controls.Add(this.chkinspbyCIB);
            this.tabPage1.Controls.Add(this.chkNationalBoardreg);
            this.tabPage1.Controls.Add(this.chkASME);
            this.tabPage1.Controls.Add(this.chkCEMarketing);
            this.tabPage1.Controls.Add(this.cmbCodeOfConstruction);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1001, 248);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Technical Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // chkConcessReq
            // 
            this.chkConcessReq.AutoSize = true;
            this.chkConcessReq.Location = new System.Drawing.Point(455, 219);
            this.chkConcessReq.Name = "chkConcessReq";
            this.chkConcessReq.Size = new System.Drawing.Size(169, 19);
            this.chkConcessReq.TabIndex = 17;
            this.chkConcessReq.Text = "Concession Request on NC";
            this.chkConcessReq.UseVisualStyleBackColor = true;
            this.chkConcessReq.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // chkInspandAccpbyClient
            // 
            this.chkInspandAccpbyClient.AutoSize = true;
            this.chkInspandAccpbyClient.Location = new System.Drawing.Point(455, 193);
            this.chkInspandAccpbyClient.Name = "chkInspandAccpbyClient";
            this.chkInspandAccpbyClient.Size = new System.Drawing.Size(219, 19);
            this.chkInspandAccpbyClient.TabIndex = 16;
            this.chkInspandAccpbyClient.Text = "Inspection and Acceptance by Client";
            this.chkInspandAccpbyClient.UseVisualStyleBackColor = true;
            this.chkInspandAccpbyClient.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // chkInspbyAuth
            // 
            this.chkInspbyAuth.AutoSize = true;
            this.chkInspbyAuth.Location = new System.Drawing.Point(455, 163);
            this.chkInspbyAuth.Name = "chkInspbyAuth";
            this.chkInspbyAuth.Size = new System.Drawing.Size(229, 19);
            this.chkInspbyAuth.TabIndex = 15;
            this.chkInspbyAuth.Text = "Inspection by Authorized Inspector(AI)";
            this.chkInspbyAuth.UseVisualStyleBackColor = true;
            this.chkInspbyAuth.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // chkQAP
            // 
            this.chkQAP.AutoSize = true;
            this.chkQAP.Location = new System.Drawing.Point(455, 136);
            this.chkQAP.Name = "chkQAP";
            this.chkQAP.Size = new System.Drawing.Size(244, 19);
            this.chkQAP.TabIndex = 14;
            this.chkQAP.Text = "QAP and Weldmap Approval is Required?";
            this.chkQAP.UseVisualStyleBackColor = true;
            this.chkQAP.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // txtWarrantyPeriod
            // 
            this.txtWarrantyPeriod.Location = new System.Drawing.Point(206, 75);
            this.txtWarrantyPeriod.Name = "txtWarrantyPeriod";
            this.txtWarrantyPeriod.Size = new System.Drawing.Size(214, 23);
            this.txtWarrantyPeriod.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 15);
            this.label9.TabIndex = 12;
            this.label9.Text = "Warranty Period";
            // 
            // chkSplmatreq
            // 
            this.chkSplmatreq.AutoSize = true;
            this.chkSplmatreq.Location = new System.Drawing.Point(182, 48);
            this.chkSplmatreq.Name = "chkSplmatreq";
            this.chkSplmatreq.Size = new System.Drawing.Size(15, 14);
            this.chkSplmatreq.TabIndex = 11;
            this.chkSplmatreq.UseVisualStyleBackColor = true;
            // 
            // txtsplMatreq
            // 
            this.txtsplMatreq.Location = new System.Drawing.Point(206, 45);
            this.txtsplMatreq.Name = "txtsplMatreq";
            this.txtsplMatreq.Size = new System.Drawing.Size(214, 23);
            this.txtsplMatreq.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 15);
            this.label8.TabIndex = 9;
            this.label8.Text = "Special Material Requirments";
            // 
            // chkCompDoscGost
            // 
            this.chkCompDoscGost.AutoSize = true;
            this.chkCompDoscGost.Location = new System.Drawing.Point(455, 110);
            this.chkCompDoscGost.Name = "chkCompDoscGost";
            this.chkCompDoscGost.Size = new System.Drawing.Size(246, 19);
            this.chkCompDoscGost.TabIndex = 8;
            this.chkCompDoscGost.Text = "Complaince and Documentation to GOST";
            this.chkCompDoscGost.UseVisualStyleBackColor = true;
            this.chkCompDoscGost.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // chkComplocalreg
            // 
            this.chkComplocalreg.AutoSize = true;
            this.chkComplocalreg.Location = new System.Drawing.Point(455, 83);
            this.chkComplocalreg.Name = "chkComplocalreg";
            this.chkComplocalreg.Size = new System.Drawing.Size(214, 19);
            this.chkComplocalreg.TabIndex = 7;
            this.chkComplocalreg.Text = "Complaince With Local Regulations";
            this.chkComplocalreg.UseVisualStyleBackColor = true;
            this.chkComplocalreg.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // chkInspByTPIA
            // 
            this.chkInspByTPIA.AutoSize = true;
            this.chkInspByTPIA.Location = new System.Drawing.Point(206, 132);
            this.chkInspByTPIA.Name = "chkInspByTPIA";
            this.chkInspByTPIA.Size = new System.Drawing.Size(125, 19);
            this.chkInspByTPIA.TabIndex = 6;
            this.chkInspByTPIA.Text = "Inspection by TPIA";
            this.chkInspByTPIA.UseVisualStyleBackColor = true;
            // 
            // chkinspbyCIB
            // 
            this.chkinspbyCIB.AutoSize = true;
            this.chkinspbyCIB.Location = new System.Drawing.Point(455, 57);
            this.chkinspbyCIB.Name = "chkinspbyCIB";
            this.chkinspbyCIB.Size = new System.Drawing.Size(134, 19);
            this.chkinspbyCIB.TabIndex = 5;
            this.chkinspbyCIB.Text = "Inspection by CIB,TS";
            this.chkinspbyCIB.UseVisualStyleBackColor = true;
            // 
            // chkNationalBoardreg
            // 
            this.chkNationalBoardreg.AutoSize = true;
            this.chkNationalBoardreg.Location = new System.Drawing.Point(455, 30);
            this.chkNationalBoardreg.Name = "chkNationalBoardreg";
            this.chkNationalBoardreg.Size = new System.Drawing.Size(171, 19);
            this.chkNationalBoardreg.TabIndex = 4;
            this.chkNationalBoardreg.Text = "National Board Registration";
            this.chkNationalBoardreg.UseVisualStyleBackColor = true;
            // 
            // chkASME
            // 
            this.chkASME.AutoSize = true;
            this.chkASME.Location = new System.Drawing.Point(455, 7);
            this.chkASME.Name = "chkASME";
            this.chkASME.Size = new System.Drawing.Size(125, 19);
            this.chkASME.TabIndex = 3;
            this.chkASME.Text = "ASME Code Stamp";
            this.chkASME.UseVisualStyleBackColor = true;
            // 
            // chkCEMarketing
            // 
            this.chkCEMarketing.AutoSize = true;
            this.chkCEMarketing.Location = new System.Drawing.Point(206, 105);
            this.chkCEMarketing.Name = "chkCEMarketing";
            this.chkCEMarketing.Size = new System.Drawing.Size(189, 19);
            this.chkCEMarketing.TabIndex = 2;
            this.chkCEMarketing.Text = "CE Markeing / PED Conformity";
            this.chkCEMarketing.UseVisualStyleBackColor = true;
            // 
            // cmbCodeOfConstruction
            // 
            this.cmbCodeOfConstruction.FormattingEnabled = true;
            this.cmbCodeOfConstruction.Location = new System.Drawing.Point(206, 14);
            this.cmbCodeOfConstruction.Name = "cmbCodeOfConstruction";
            this.cmbCodeOfConstruction.Size = new System.Drawing.Size(102, 23);
            this.cmbCodeOfConstruction.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Code of Construction";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.cmbCurrency);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.cmbProjectSector);
            this.tabPage2.Controls.Add(this.cmbProjectClass);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.dgPymentterms);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txtLDforDelDrawing);
            this.tabPage2.Controls.Add(this.txtLDfodelayd);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1001, 248);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Commercial Data";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(490, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(51, 24);
            this.button2.TabIndex = 13;
            this.button2.Text = "New";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(380, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(51, 24);
            this.button1.TabIndex = 12;
            this.button1.Text = "New";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // cmbCurrency
            // 
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Items.AddRange(new object[] {
            "INR",
            "USD",
            "EURO"});
            this.cmbCurrency.Location = new System.Drawing.Point(232, 73);
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.Size = new System.Drawing.Size(140, 23);
            this.cmbCurrency.TabIndex = 11;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 15);
            this.label16.TabIndex = 10;
            this.label16.Text = "Currency";
            // 
            // cmbProjectSector
            // 
            this.cmbProjectSector.FormattingEnabled = true;
            this.cmbProjectSector.Location = new System.Drawing.Point(232, 42);
            this.cmbProjectSector.Name = "cmbProjectSector";
            this.cmbProjectSector.Size = new System.Drawing.Size(250, 23);
            this.cmbProjectSector.TabIndex = 9;
            this.cmbProjectSector.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // cmbProjectClass
            // 
            this.cmbProjectClass.FormattingEnabled = true;
            this.cmbProjectClass.Items.AddRange(new object[] {
            "Domestic",
            "Export"});
            this.cmbProjectClass.Location = new System.Drawing.Point(232, 15);
            this.cmbProjectClass.Name = "cmbProjectClass";
            this.cmbProjectClass.Size = new System.Drawing.Size(140, 23);
            this.cmbProjectClass.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 15);
            this.label15.TabIndex = 7;
            this.label15.Text = "Project Sector";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 15);
            this.label14.TabIndex = 6;
            this.label14.Text = "Project Clasification";
            // 
            // dgPymentterms
            // 
            this.dgPymentterms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPymentterms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Mile_Stone,
            this.Per_Payments,
            this.TriggeringPoint});
            this.dgPymentterms.Location = new System.Drawing.Point(548, 35);
            this.dgPymentterms.Name = "dgPymentterms";
            this.dgPymentterms.Size = new System.Drawing.Size(444, 188);
            this.dgPymentterms.TabIndex = 5;
            // 
            // Mile_Stone
            // 
            this.Mile_Stone.DataPropertyName = "Mile_Stone";
            this.Mile_Stone.HeaderText = "MileStone";
            this.Mile_Stone.Name = "Mile_Stone";
            // 
            // Per_Payments
            // 
            this.Per_Payments.DataPropertyName = "Per_Payments";
            this.Per_Payments.HeaderText = "% of Payment";
            this.Per_Payments.Name = "Per_Payments";
            // 
            // TriggeringPoint
            // 
            this.TriggeringPoint.DataPropertyName = "TriggeringPoint";
            this.TriggeringPoint.HeaderText = "Triggering Point";
            this.TriggeringPoint.Name = "TriggeringPoint";
            this.TriggeringPoint.Width = 125;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(545, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Payment Terms";
            // 
            // txtLDforDelDrawing
            // 
            this.txtLDforDelDrawing.Location = new System.Drawing.Point(232, 173);
            this.txtLDforDelDrawing.Multiline = true;
            this.txtLDforDelDrawing.Name = "txtLDforDelDrawing";
            this.txtLDforDelDrawing.Size = new System.Drawing.Size(308, 49);
            this.txtLDforDelDrawing.TabIndex = 3;
            // 
            // txtLDfodelayd
            // 
            this.txtLDfodelayd.Location = new System.Drawing.Point(232, 118);
            this.txtLDfodelayd.Multiline = true;
            this.txtLDfodelayd.Name = "txtLDfodelayd";
            this.txtLDfodelayd.Size = new System.Drawing.Size(308, 48);
            this.txtLDfodelayd.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 177);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(195, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "LD for Delayed Delivery of Drawings";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 118);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(204, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "LD fo Delayed delivery of Equipments";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1001, 248);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Attachments";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView3.Location = new System.Drawing.Point(15, 14);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(793, 213);
            this.dataGridView3.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Document Name";
            this.Column1.Name = "Column1";
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Document Ref No";
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Document File Path";
            this.Column3.Name = "Column3";
            this.Column3.Width = 200;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Upload";
            this.Column4.Name = "Column4";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(867, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(145, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Create New Project";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(957, 632);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 19;
            this.button3.Text = "Close";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(876, 632);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 18;
            this.button4.Text = "Delete";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(795, 632);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 17;
            this.button5.Text = "Submit";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // project_MasterBindingNavigator
            // 
            this.project_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.project_MasterBindingNavigator.BindingSource = this.project_MasterBindingSource;
            this.project_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.project_MasterBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.project_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.project_MasterBindingNavigatorSaveItem});
            this.project_MasterBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.project_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.project_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.project_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.project_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.project_MasterBindingNavigator.Name = "project_MasterBindingNavigator";
            this.project_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.project_MasterBindingNavigator.Size = new System.Drawing.Size(1093, 25);
            this.project_MasterBindingNavigator.TabIndex = 20;
            this.project_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // project_MasterBindingSource
            // 
            this.project_MasterBindingSource.DataMember = "Project_Master";
            this.project_MasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // project_MasterBindingNavigatorSaveItem
            // 
            this.project_MasterBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.project_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("project_MasterBindingNavigatorSaveItem.Image")));
            this.project_MasterBindingNavigatorSaveItem.Name = "project_MasterBindingNavigatorSaveItem";
            this.project_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.project_MasterBindingNavigatorSaveItem.Text = "Save Data";
            this.project_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.project_MasterBindingNavigatorSaveItem_Click);
            // 
            // project_MasterTableAdapter
            // 
            this.project_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.Activity_MasterTableAdapter = null;
            this.tableAdapterManager.APG_MasterTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Item_MasterTableAdapter = null;
            this.tableAdapterManager.Maker_MasterTableAdapter = null;
            this.tableAdapterManager.Material_GradesTableAdapter = null;
            this.tableAdapterManager.Project_MasterTableAdapter = this.project_MasterTableAdapter;
            this.tableAdapterManager.Project_StructureTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Thermal_ERP.Thermal_PMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // projectMasterBindingSource
            // 
            this.projectMasterBindingSource.DataMember = "Project_Master";
            this.projectMasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1001, 248);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Contact Info / Project Team";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // frmCreateProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1093, 750);
            this.Controls.Add(this.project_MasterBindingNavigator);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmCreateProject";
            this.Text = "frmCreateProject";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCreateProject_FormClosing);
            this.Load += new System.EventHandler(this.frmCreateProject_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEqup)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPymentterms)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.project_MasterBindingNavigator)).EndInit();
            this.project_MasterBindingNavigator.ResumeLayout(false);
            this.project_MasterBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.project_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectMasterBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.CheckBox chkConcessReq;
        private System.Windows.Forms.CheckBox chkInspandAccpbyClient;
        private System.Windows.Forms.CheckBox chkInspbyAuth;
        private System.Windows.Forms.CheckBox chkQAP;
        private System.Windows.Forms.TextBox txtWarrantyPeriod;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkSplmatreq;
        private System.Windows.Forms.TextBox txtsplMatreq;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkCompDoscGost;
        private System.Windows.Forms.CheckBox chkComplocalreg;
        private System.Windows.Forms.CheckBox chkInspByTPIA;
        private System.Windows.Forms.CheckBox chkinspbyCIB;
        private System.Windows.Forms.CheckBox chkNationalBoardreg;
        private System.Windows.Forms.CheckBox chkASME;
        private System.Windows.Forms.CheckBox chkCEMarketing;
        private System.Windows.Forms.ComboBox cmbCodeOfConstruction;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtLDforDelDrawing;
        private System.Windows.Forms.TextBox txtLDfodelayd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgPymentterms;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewButtonColumn Column4;
        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.TextBox txtDescrption;
        private System.Windows.Forms.ComboBox cmbClient;
        private System.Windows.Forms.TextBox txtFinalClient;
        private System.Windows.Forms.DateTimePicker dpdate;
        private System.Windows.Forms.DataGridView dgEqup;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbProjectSector;
        private System.Windows.Forms.ComboBox cmbProjectClass;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbCurrency;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource project_MasterBindingSource;
        private Thermal_PMSDataSetTableAdapters.Project_MasterTableAdapter project_MasterTableAdapter;
        private Thermal_PMSDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator project_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton project_MasterBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingSource projectMasterBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mile_Stone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Per_Payments;
        private System.Windows.Forms.DataGridViewTextBoxColumn TriggeringPoint;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maker_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Project_Equp_Name;
        private System.Windows.Forms.DataGridViewButtonColumn Column5;
        private System.Windows.Forms.TabPage tabPage4;
    }
}