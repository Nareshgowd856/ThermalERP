﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmMaterialGrades : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string Material_No;
        public frmMaterialGrades()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            //m .DeleteMaker(textBox1.Text);
         //   material_GradesTableAdapter.inserMtrlGrades(cmbmaterialgroup.Text,txtmaterialgrade.Text,cmbcolorcode.Text,Convert.ToDecimal(txtDensity.Text), "0001");
            //dataGridView1.Refresh();
            if((from k in db.Material_Grades where k.CompID=="0001"&& k.Spec_Code==(txtmeterialid.Text) select k).Count()>0)
            {
                db.Sp_Delete_MaterialGrade("0001", txtmeterialid.Text);
                Material_Grade mg = new Material_Grade();
                mg.Spec_Code = (txtmeterialid.Text);
                mg.Material_Group = (cmbmaterialgroup.Text == "") ? "" : cmbmaterialgroup.Text;
                mg.Material_Grad = (txtmaterialgrade.Text == "") ? "" : txtmaterialgrade.Text;
                mg.Material_Color = (cmbcolorcode.Text == "") ? "" : cmbcolorcode.Text;
                mg.Material_Density = (txtDensity.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDensity.Text);
                mg.CompID = "0001";
                db.Material_Grades.InsertOnSubmit(mg);
                db.SubmitChanges();
                MessageBox.Show("Recored Updated Successfully");
                Binddatatogird();
                Clear();
            }
            else

            {
                Material_Grade mg = new Material_Grade();
                mg.Material_Group = (cmbmaterialgroup.Text == "") ? "" : cmbmaterialgroup.Text;
                mg.Material_Grad = (txtmaterialgrade.Text == "") ? "" : txtmaterialgrade.Text;
                mg.Material_Color = (cmbcolorcode.Text == "") ? "" : cmbcolorcode.Text;
                mg.Material_Density = (txtDensity.Text == "") ? Convert.ToDecimal(0) : Convert.ToDecimal(txtDensity.Text);
                mg.CompID = "0001";
             //   var auto = db.Sp_autoincrement_Material_Grade("0001");
                mg.Spec_Code = txtmeterialid.Text;
                db.Material_Grades.InsertOnSubmit(mg);
                db.SubmitChanges();
                MessageBox.Show("Recored Saved Successfully");
                Binddatatogird();
                Clear();
            }

        }

        private void material_GradesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.material_GradesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.thermal_PMSDataSet);

        }
        public void Binddatatogird()
        {
            var sa = (from k in db.Material_Grades where k.CompID == "0001" select k).ToList();
            if (sa.Count > 0)
            {
                material_GradesDataGridView.DataSource = sa;
            }
        }
        private void frmMaterialGrades_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Material_Grades' table. You can move, or remove it, as needed.
            //  this.material_GradesTableAdapter.Fill(this.thermal_PMSDataSet.Material_Grades);
            Binddatatogird();
        }

        private void material_GradesDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    Material_No = (material_GradesDataGridView.Rows[e.RowIndex].Cells["Spec_Code"].Value.ToString());

                    var sa = (from k in db.Material_Grades where k.CompID == "0001" && k.Spec_Code == Material_No select k).ToList();
                    if(sa.Count>0)
                    {
                        txtmeterialid.Text = Material_No;
                        cmbmaterialgroup.Text = sa[0].Material_Group;
                        txtmaterialgrade.Text = sa[0].Material_Grad;
                        cmbcolorcode.Text = sa[0].Material_Color;
                        txtDensity.Text = Convert.ToDecimal(sa[0].Material_Density).ToString();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Clear()
        {
            try
            {
                //foreach (Control d in tableLayoutPanel1.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();
                //    if (d is ComboBox)
                //        (d as ComboBox).SelectedIndex = -1;
                //    if (d is CheckBox)
                //        (d as CheckBox).Checked = false;
                //}
                cmbmaterialgroup.Text = "";txtmaterialgrade.Text = "";txtmeterialid.Text = "";cmbcolorcode.Text = "";txtDensity.Text = "";

            }
            catch (Exception ex)
            {
                throw;
            }
          
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void txtmeterialid_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Material_Grades where k.CompID == "0001" && k.Spec_Code == txtmeterialid.Text select k).ToList();
                if(sa.Count>0)
                {
                    MessageBox.Show("This  Id is Already Existing.. Please try another id...");
                    txtmeterialid.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
