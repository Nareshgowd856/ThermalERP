﻿namespace Thermal_ERP
{
    partial class frmPartMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPartMaster));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbspecification = new System.Windows.Forms.ComboBox();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbpurchaseuom = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPurchaseUom = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbGroup = new System.Windows.Forms.ComboBox();
            this.cmbissuuom = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.BtnSpecification = new System.Windows.Forms.Button();
            this.chkCriticalitem = new System.Windows.Forms.CheckBox();
            this.chkShelfLifeitem = new System.Windows.Forms.CheckBox();
            this.chkBomReq = new System.Windows.Forms.CheckBox();
            this.cmbPtsNo = new System.Windows.Forms.ComboBox();
            this.btnPtsno = new System.Windows.Forms.Button();
            this.btnGroup = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dgItemmaster = new System.Windows.Forms.DataGridView();
            this.Item_Dia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Wt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_SchNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_UWt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_LongText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_List_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Part_List_No1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemmaster)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 155F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 296F));
            this.tableLayoutPanel1.Controls.Add(this.cmbspecification, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.cmbType, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbpurchaseuom, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnPurchaseUom, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbGroup, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbissuuom, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnSpecification, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.chkCriticalitem, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.chkShelfLifeitem, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.chkBomReq, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbPtsNo, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnPtsno, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnGroup, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label9, 4, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 34);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(987, 142);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // cmbspecification
            // 
            this.cmbspecification.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbspecification.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbspecification.FormattingEnabled = true;
            this.cmbspecification.Location = new System.Drawing.Point(111, 79);
            this.cmbspecification.Name = "cmbspecification";
            this.cmbspecification.Size = new System.Drawing.Size(177, 25);
            this.cmbspecification.TabIndex = 14;
            // 
            // cmbType
            // 
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "Raw Material"});
            this.cmbType.Location = new System.Drawing.Point(111, 6);
            this.cmbType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(177, 25);
            this.cmbType.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Type";
            // 
            // cmbpurchaseuom
            // 
            this.cmbpurchaseuom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbpurchaseuom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbpurchaseuom.FormattingEnabled = true;
            this.cmbpurchaseuom.Location = new System.Drawing.Point(111, 43);
            this.cmbpurchaseuom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbpurchaseuom.Name = "cmbpurchaseuom";
            this.cmbpurchaseuom.Size = new System.Drawing.Size(88, 25);
            this.cmbpurchaseuom.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Purchase UOM";
            // 
            // btnPurchaseUom
            // 
            this.btnPurchaseUom.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnPurchaseUom.Location = new System.Drawing.Point(296, 43);
            this.btnPurchaseUom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPurchaseUom.Name = "btnPurchaseUom";
            this.btnPurchaseUom.Size = new System.Drawing.Size(62, 27);
            this.btnPurchaseUom.TabIndex = 4;
            this.btnPurchaseUom.Text = "New";
            this.btnPurchaseUom.UseVisualStyleBackColor = false;
            this.btnPurchaseUom.Click += new System.EventHandler(this.button3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(366, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Group";
            // 
            // cmbGroup
            // 
            this.cmbGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGroup.FormattingEnabled = true;
            this.cmbGroup.Location = new System.Drawing.Point(464, 6);
            this.cmbGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbGroup.Name = "cmbGroup";
            this.cmbGroup.Size = new System.Drawing.Size(149, 25);
            this.cmbGroup.TabIndex = 1;
            // 
            // cmbissuuom
            // 
            this.cmbissuuom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbissuuom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbissuuom.FormattingEnabled = true;
            this.cmbissuuom.Location = new System.Drawing.Point(464, 43);
            this.cmbissuuom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbissuuom.Name = "cmbissuuom";
            this.cmbissuuom.Size = new System.Drawing.Size(88, 25);
            this.cmbissuuom.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(366, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Issue UOM";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "Specification";
            // 
            // BtnSpecification
            // 
            this.BtnSpecification.BackColor = System.Drawing.Color.NavajoWhite;
            this.BtnSpecification.Location = new System.Drawing.Point(296, 80);
            this.BtnSpecification.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnSpecification.Name = "BtnSpecification";
            this.BtnSpecification.Size = new System.Drawing.Size(62, 27);
            this.BtnSpecification.TabIndex = 8;
            this.BtnSpecification.Text = "New";
            this.BtnSpecification.UseVisualStyleBackColor = false;
            this.BtnSpecification.Click += new System.EventHandler(this.button4_Click);
            // 
            // chkCriticalitem
            // 
            this.chkCriticalitem.AutoSize = true;
            this.chkCriticalitem.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCriticalitem.ForeColor = System.Drawing.Color.Blue;
            this.chkCriticalitem.Location = new System.Drawing.Point(696, 42);
            this.chkCriticalitem.Name = "chkCriticalitem";
            this.chkCriticalitem.Size = new System.Drawing.Size(105, 21);
            this.chkCriticalitem.TabIndex = 6;
            this.chkCriticalitem.Text = "Critical Item?";
            this.chkCriticalitem.UseVisualStyleBackColor = true;
            // 
            // chkShelfLifeitem
            // 
            this.chkShelfLifeitem.AutoSize = true;
            this.chkShelfLifeitem.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShelfLifeitem.ForeColor = System.Drawing.Color.Blue;
            this.chkShelfLifeitem.Location = new System.Drawing.Point(696, 79);
            this.chkShelfLifeitem.Name = "chkShelfLifeitem";
            this.chkShelfLifeitem.Size = new System.Drawing.Size(118, 21);
            this.chkShelfLifeitem.TabIndex = 11;
            this.chkShelfLifeitem.Text = "Shelf Life Item?";
            this.chkShelfLifeitem.UseVisualStyleBackColor = true;
            // 
            // chkBomReq
            // 
            this.chkBomReq.AutoSize = true;
            this.chkBomReq.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBomReq.ForeColor = System.Drawing.Color.Blue;
            this.chkBomReq.Location = new System.Drawing.Point(696, 116);
            this.chkBomReq.Name = "chkBomReq";
            this.chkBomReq.Size = new System.Drawing.Size(121, 21);
            this.chkBomReq.TabIndex = 12;
            this.chkBomReq.Text = "BOM Required?";
            this.chkBomReq.UseVisualStyleBackColor = true;
            // 
            // cmbPtsNo
            // 
            this.cmbPtsNo.FormattingEnabled = true;
            this.cmbPtsNo.Location = new System.Drawing.Point(464, 80);
            this.cmbPtsNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbPtsNo.Name = "cmbPtsNo";
            this.cmbPtsNo.Size = new System.Drawing.Size(149, 25);
            this.cmbPtsNo.TabIndex = 9;
            this.cmbPtsNo.Visible = false;
            // 
            // btnPtsno
            // 
            this.btnPtsno.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnPtsno.Location = new System.Drawing.Point(621, 80);
            this.btnPtsno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPtsno.Name = "btnPtsno";
            this.btnPtsno.Size = new System.Drawing.Size(62, 25);
            this.btnPtsno.TabIndex = 10;
            this.btnPtsno.Text = "New";
            this.btnPtsno.UseVisualStyleBackColor = false;
            this.btnPtsno.Visible = false;
            this.btnPtsno.Click += new System.EventHandler(this.btnPtsno_Click);
            // 
            // btnGroup
            // 
            this.btnGroup.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnGroup.Location = new System.Drawing.Point(621, 5);
            this.btnGroup.Name = "btnGroup";
            this.btnGroup.Size = new System.Drawing.Size(62, 25);
            this.btnGroup.TabIndex = 2;
            this.btnGroup.Text = "New";
            this.btnGroup.UseVisualStyleBackColor = false;
            this.btnGroup.Click += new System.EventHandler(this.btnGroup_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.NavajoWhite;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(296, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 27);
            this.button1.TabIndex = 20;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(464, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "PTS No";
            this.label9.Visible = false;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.BackColor = System.Drawing.Color.White;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Red;
            this.btnReset.Location = new System.Drawing.Point(690, 3);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(94, 25);
            this.btnReset.TabIndex = 1;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.Red;
            this.btnSubmit.Location = new System.Drawing.Point(790, 3);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(94, 25);
            this.btnSubmit.TabIndex = 0;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(890, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(94, 25);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(751, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(248, 21);
            this.label10.TabIndex = 5;
            this.label10.Text = "ITEM MASTER - RAW MATERIAL";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.dgItemmaster, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 208);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(987, 300);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // dgItemmaster
            // 
            this.dgItemmaster.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgItemmaster.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgItemmaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemmaster.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Item_Dia,
            this.Item_Wt,
            this.Item_SchNo,
            this.Item_UWt,
            this.Item_Description,
            this.Item_Code,
            this.Item_LongText,
            this.Part_List_No,
            this.Column2,
            this.Column3});
            this.dgItemmaster.Location = new System.Drawing.Point(3, 3);
            this.dgItemmaster.Name = "dgItemmaster";
            this.dgItemmaster.Size = new System.Drawing.Size(981, 294);
            this.dgItemmaster.TabIndex = 0;
            this.dgItemmaster.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemmaster_CellClick);
            this.dgItemmaster.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // Item_Dia
            // 
            this.Item_Dia.DataPropertyName = "Item_Dia";
            this.Item_Dia.HeaderText = "Dia";
            this.Item_Dia.Name = "Item_Dia";
            // 
            // Item_Wt
            // 
            this.Item_Wt.DataPropertyName = "Item_Wt";
            this.Item_Wt.HeaderText = "Thick";
            this.Item_Wt.Name = "Item_Wt";
            // 
            // Item_SchNo
            // 
            this.Item_SchNo.DataPropertyName = "Item_SchNo";
            this.Item_SchNo.HeaderText = "Sch No";
            this.Item_SchNo.Name = "Item_SchNo";
            // 
            // Item_UWt
            // 
            this.Item_UWt.DataPropertyName = "Item_UWt";
            this.Item_UWt.HeaderText = "Unit Wt";
            this.Item_UWt.Name = "Item_UWt";
            // 
            // Item_Description
            // 
            this.Item_Description.DataPropertyName = "Item_Description";
            this.Item_Description.HeaderText = "Item Description";
            this.Item_Description.Name = "Item_Description";
            // 
            // Item_Code
            // 
            this.Item_Code.DataPropertyName = "Item_Code";
            this.Item_Code.HeaderText = "Item Code";
            this.Item_Code.Name = "Item_Code";
            // 
            // Item_LongText
            // 
            this.Item_LongText.DataPropertyName = "Item_LongText";
            this.Item_LongText.HeaderText = "Item Long Text";
            this.Item_LongText.Name = "Item_LongText";
            // 
            // Part_List_No
            // 
            this.Part_List_No.DataPropertyName = "Part_List_No";
            this.Part_List_No.HeaderText = "Part List No\'s";
            this.Part_List_No.Name = "Part_List_No";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "";
            this.Column2.Name = "Column2";
            this.Column2.Text = "Add";
            this.Column2.UseColumnTextForButtonValue = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "";
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column3.Text = "Remove";
            this.Column3.UseColumnTextForButtonValue = true;
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.White;
            this.btnImport.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport.ForeColor = System.Drawing.Color.Red;
            this.btnImport.Location = new System.Drawing.Point(12, 179);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(75, 26);
            this.btnImport.TabIndex = 1;
            this.btnImport.Text = "Import ";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.White;
            this.btnExport.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.ForeColor = System.Drawing.Color.Red;
            this.btnExport.Location = new System.Drawing.Point(93, 179);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 26);
            this.btnExport.TabIndex = 2;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.button2_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 8;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 77F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 116F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 97F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 305F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Controls.Add(this.btnSubmit, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnClose, 7, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel2, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.linkLabel1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnReset, 5, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(12, 511);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(987, 31);
            this.tableLayoutPanel3.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Created By";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(172, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Last Modofied By";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.Location = new System.Drawing.Point(288, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(59, 13);
            this.linkLabel2.TabIndex = 7;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "linkLabel2";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(80, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(59, 13);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "linkLabel1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(410, 280);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 219);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PT No\'s";
            this.groupBox1.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(245, 189);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(57, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "Create";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(305, 189);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(57, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Part_List_No1});
            this.dataGridView1.Location = new System.Drawing.Point(21, 20);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(339, 164);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column1.HeaderText = "Select";
            this.Column1.Name = "Column1";
            this.Column1.Width = 50;
            // 
            // Part_List_No1
            // 
            this.Part_List_No1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Part_List_No1.DataPropertyName = "Part_List_No";
            this.Part_List_No1.HeaderText = "PT No\'s";
            this.Part_List_No1.Name = "Part_List_No1";
            this.Part_List_No1.Width = 200;
            // 
            // frmPartMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmPartMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Part Master";
            this.Load += new System.EventHandler(this.frmPartMaster_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmPartMaster_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmPartMaster_KeyPress);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgItemmaster)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.ComboBox cmbGroup;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbpurchaseuom;
        private System.Windows.Forms.ComboBox cmbissuuom;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbPtsNo;
        private System.Windows.Forms.CheckBox chkBomReq;
        private System.Windows.Forms.CheckBox chkCriticalitem;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkShelfLifeitem;
        private System.Windows.Forms.Button btnPurchaseUom;
        private System.Windows.Forms.Button BtnSpecification;
        private System.Windows.Forms.Button btnPtsno;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView dgItemmaster;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button btnGroup;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_List_No1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Dia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Wt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_SchNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_UWt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_LongText;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_List_No;
        private System.Windows.Forms.DataGridViewButtonColumn Column2;
        private System.Windows.Forms.DataGridViewButtonColumn Column3;
        private System.Windows.Forms.ComboBox cmbspecification;
        private System.Windows.Forms.Button button3;
    }
}