﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing.Printing;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmPartMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);

        public frmPartMaster()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmMaterialGrades frm = new frmMaterialGrades();
            if (frm.ShowDialog() == DialogResult.Cancel)
            {
                BindSpecifications();
              //  BindSpecifications();
            }
            //frm.MdiParent = this.ParentForm;
            //frm.Show();
        }
        public void BindPartList()
        {
            var sa = (from k in db.Part_Lists where k.CompID == "0001" select new { k.Part_List_No }).ToList();
            if(sa.Count>0)
            {
                dataGridView1.DataSource = sa;
            }
        }
        private void frmPartMaster_Load(object sender, EventArgs e)
        {
            //// TODO: This line of code loads data into the 'thermal_PMSDataSet.Material_Grades' table. You can move, or remove it, as needed.
            //this.material_GradesTableAdapter.Fill(this.thermal_PMSDataSet.Material_Grades);
            //// TODO: This line of code loads data into the 'thermal_PMSDataSet.Item_Master' table. You can move, or remove it, as needed.
            //this.item_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Item_Master);
            //// TODO: This line of code loads data into the 'thermal_PMSDataSet.Item_Master' table. You can move, or remove it, as needed.
            //this.item_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Item_Master);
            //// TODO: This line of code loads data into the 'thermal_PMSDataSet.Material_Grades' table. You can move, or remove it, as needed.
            //this.material_GradesTableAdapter.Fill(this.thermal_PMSDataSet.Material_Grades);
            BindGridMasterdata();
            BindUomMasterdata();
            BindSpecifications();
            BindPartList();
        }
        public void BindSpecifications()
        {
            var sa = (from k in db.Material_Grades where k.CompID == "0001" select new { k.Material_Grad,k.Spec_Code }).ToList();
            if(sa.Count>0)
            {
                cmbspecification.DataSource = sa;
                cmbspecification.DisplayMember = "Material_Grad";
                cmbspecification.ValueMember = "Spec_Code";
                // cmbspecification.DataSource = sa;
                if (cmbspecification.Items.Count>0)
                {
                    cmbspecification.Text = "";
                }
                else
                {
                    cmbspecification.SelectedIndex = -1;
                }
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
           
        }

        private void item_MasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Masters.UomMaster obj = new Masters.UomMaster();
            if(obj.ShowDialog() == DialogResult.Cancel)
            {
                BindUomMasterdata();
            }
        }

        //return msg;
    

        

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow R = dgItemmaster.Rows[dgItemmaster.CurrentRow.Index];
            int columnIndex = dgItemmaster.CurrentCell.ColumnIndex;
            string columnName = dgItemmaster.Columns[columnIndex].Name;
            if (cmbGroup.Text == "Plate")
            {
                R.Cells["Item_Description"].Value = cmbGroup.Text + " " + cmbspecification.Text + " " +R.Cells["Item_Dia"].Value + " MM";
                int Thick = Convert.ToInt32(R.Cells["Item_Dia"].Value); 
                if(Thick <10)
                {
                    R.Cells["Item_Code"].Value = "001BQ060000" + R.Cells["Item_Dia"].Value;
                }
                else
                {
                    R.Cells["Item_Code"].Value = "001BQ06000" + R.Cells["Item_Dia"].Value;
                }
            }
            if (cmbGroup.Text == "Tubes")
            {
                R.Cells["Item_Description"].Value = cmbGroup.Text + " " + cmbspecification.Text + " " + R.Cells["Item_Dia"].Value + "x" + R.Cells["Item_Wt"].Value + " MM";
                double Thick = Convert.ToInt32(R.Cells["Item_Wt"].Value);
                if (Thick < 10)
                {
                    R.Cells["Item_Code"].Value = "002AS0100" + R.Cells["Item_Wt"].Value;
                }
                else
                {
                    R.Cells["Item_Code"].Value = "002AS010" + R.Cells["Item_Wt"].Value;
                }
            }
            if (cmbGroup.Text == "Pipes")
            {
                R.Cells["Item_Description"].Value = cmbGroup.Text + " " + cmbspecification.Text + " " + R.Cells["Item_Dia"].Value + "x" + R.Cells["Item_Wt"].Value + " MM";
                double Thick = Convert.ToInt32(R.Cells["Item_Wt"].Value);
                if (Thick < 10)
                {
                    R.Cells["Item_Code"].Value = "002AS0100" + R.Cells["Item_Wt"].Value;
                }
                else
                {
                    R.Cells["Item_Code"].Value = "002AS010" + R.Cells["Item_Wt"].Value;
                }
            }
          
          
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void BindGridMasterdata()
        {
            try
            {
                var sa = ((from k in db.Group_Masters where k.CompID == "0001" select new { k.Group_Name,k.Group_Id})).ToList();
                if (sa.Count > 0)
                {
                    cmbGroup.DataSource = sa;
                    cmbGroup.DisplayMember = "Group_Name";
                    cmbGroup.ValueMember = "Group_Id";
                    if(cmbGroup.Items.Count>0)
                    {
                        cmbGroup.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbGroup.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        public void BindUomMasterdata()
        {
            try
            {
                var sa = ((from k in db.UOM_Masters where k.CompId == "0001" select new { k.UOM_Name,k.UOM_Id })).ToList();
                if (sa.Count > 0)
                {
                    cmbpurchaseuom.DataSource = sa;
                    cmbpurchaseuom.DisplayMember = "UOM_Name";
                    cmbpurchaseuom.ValueMember = "UOM_Id";
                    if (cmbpurchaseuom.Items.Count > 0)
                    {
                        cmbpurchaseuom.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbpurchaseuom.SelectedIndex = -1;
                    }
                }
                var sa1 = ((from k in db.UOM_Masters where k.CompId == "0001" select new { k.UOM_Name, k.UOM_Id })).ToList();
                if (sa1.Count > 0)
                {
                    cmbissuuom.DataSource = sa1;
                    cmbissuuom.DisplayMember = "UOM_Name";
                    cmbissuuom.ValueMember = "UOM_Id";
                    if (cmbissuuom.Items.Count > 0)
                    {
                        cmbissuuom.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbissuuom.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        private void btnGroup_Click(object sender, EventArgs e)
        {
            Masters.GroupMaster obj = new Masters.GroupMaster();
            if (obj.ShowDialog() == DialogResult.Cancel)
            {
                BindGridMasterdata();
            }
                
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                cmbType.Text = "";cmbGroup.Text = "";cmbpurchaseuom.Text = "";cmbissuuom.Text = "";cmbspecification.Text = "";cmbPtsNo.Text = "";chkBomReq.Checked = false;chkCriticalitem.Checked = false;chkShelfLifeitem.Checked = false;
                if (dgItemmaster.Rows.Count > 0)
                {
                    for (int i = 0; i < dgItemmaster.Rows.Count - 1; i++)
                    {
                        dgItemmaster.Rows.RemoveAt(i);
                        i--;
                        while (dgItemmaster.Rows.Count == 0)
                            continue;
                    }
                }
                groupBox1.Visible = false;
                BindPartList();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbType.Text == "" || cmbType.Text == null)
                {
                    MessageBox.Show("Please Select Type");
                    cmbType.Focus();
                    return;
                }
                else
                {
                  if((from k in db.Item_RM_Masters where k.CompID=="0001" && k.Item_Type==cmbType.Text.Trim() && k.Item_Group==cmbGroup.SelectedValue.ToString().Trim() && k.Item_Pur_UOM==cmbpurchaseuom.SelectedValue.ToString().Trim() && k.Item_Iss_UOM==cmbissuuom.SelectedValue.ToString().Trim()
                      && k.Item_Spec==cmbspecification.SelectedValue.ToString().Trim() && k.Item_PTS==cmbPtsNo.Text.Trim() select k).Count()>0)
                    {
                        db.SP_delete_Item_RM_Master("0001", cmbType.Text, cmbGroup.SelectedValue.ToString(), cmbpurchaseuom.SelectedValue.ToString(), cmbissuuom.SelectedValue.ToString(), cmbspecification.SelectedValue.ToString(), cmbPtsNo.Text);
                        Item_RM_Master im = new Item_RM_Master();
                        im.Item_Type = (cmbType.Text == "") ? "" : cmbType.Text;
                        im.Item_Group = (cmbGroup.SelectedValue.ToString() == "") ? "" : cmbGroup.SelectedValue.ToString();
                        im.Item_Pur_UOM = (cmbpurchaseuom.SelectedValue.ToString() == "") ? "" : cmbpurchaseuom.SelectedValue.ToString();
                        im.Item_Iss_UOM = (cmbissuuom.SelectedValue.ToString() == "") ? "" : cmbissuuom.SelectedValue.ToString();
                        im.Item_Spec = (cmbspecification.SelectedValue.ToString() == "") ? "" : cmbspecification.SelectedValue.ToString();
                        im.Item_PTS = (cmbPtsNo.Text == "") ? "" : cmbPtsNo.Text;
                        im.Item_BOM_Req = "No";
                        im.Item_Critical_Item = "Yes";
                        im.Item_ShelfLife = "No";
                        im.CompID = "0001";
                        db.Item_RM_Masters.InsertOnSubmit(im);
                        db.SubmitChanges();

                    
                      //  string code = (dgItemmaster.Rows[i].Cells["Item_Code"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Code"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_Code"].Value.ToString());
                        db.SP_delete_Item_RM_Code("0001", cmbspecification.SelectedValue.ToString());
                        for (int i = 0; i < dgItemmaster.Rows.Count - 1; i++)
                        {
                            Item_RM_Code ic = new Item_RM_Code();
                            ic.Item_Spec = (cmbspecification.SelectedValue.ToString() == "") ? "" : cmbspecification.SelectedValue.ToString();
                            ic.Item_Dia = (dgItemmaster.Rows[i].Cells["Item_Dia"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Dia"].Value == null || dgItemmaster.Rows[i].Cells["Item_Dia"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_Dia"].Value.ToString());
                            ic.Item_WT = (dgItemmaster.Rows[i].Cells["Item_WT"].Value == "" || dgItemmaster.Rows[i].Cells["Item_WT"].Value == null || dgItemmaster.Rows[i].Cells["Item_WT"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_WT"].Value.ToString());
                            ic.Item_SchNo = (dgItemmaster.Rows[i].Cells["Item_SchNo"].Value == "" || dgItemmaster.Rows[i].Cells["Item_SchNo"].Value == null) ? "" : dgItemmaster.Rows[i].Cells["Item_SchNo"].Value.ToString();
                            ic.Part_List_No = (dgItemmaster.Rows[i].Cells["Part_List_No"].Value == "" || dgItemmaster.Rows[i].Cells["Part_List_No"].Value == null) ? "" : dgItemmaster.Rows[i].Cells["Part_List_No"].Value.ToString();
                            ic.Item_UWt = (dgItemmaster.Rows[i].Cells["Item_UWt"].Value == "" || dgItemmaster.Rows[i].Cells["Item_UWt"].Value == null || dgItemmaster.Rows[i].Cells["Item_UWt"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_UWt"].Value.ToString());
                            ic.Item_Description = (dgItemmaster.Rows[i].Cells["Item_Description"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Description"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_Description"].Value.ToString());
                            ic.Item_Code = (dgItemmaster.Rows[i].Cells["Item_Code"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Code"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_Code"].Value.ToString());
                            ic.Item_LongText = (dgItemmaster.Rows[i].Cells["Item_LongText"].Value == "" || dgItemmaster.Rows[i].Cells["Item_LongText"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_LongText"].Value.ToString());
                            ic.CompID = "0001";
                            db.Item_RM_Codes.InsertOnSubmit(ic);
                        }
                        db.SubmitChanges();
                        MessageBox.Show("Recore Updated Succesfully");
                    }
                    else
                    {
                        Item_RM_Master im = new Item_RM_Master();
                        im.Item_Type = (cmbType.Text == "") ? "" : cmbType.Text;
                        im.Item_Group = (cmbGroup.SelectedValue.ToString() == "") ? "" : cmbGroup.SelectedValue.ToString();
                        im.Item_Pur_UOM = (cmbpurchaseuom.SelectedValue.ToString() == "") ? "" : cmbpurchaseuom.SelectedValue.ToString();
                        im.Item_Iss_UOM = (cmbissuuom.SelectedValue.ToString() == "") ? "" : cmbissuuom.SelectedValue.ToString();
                        im.Item_Spec = (cmbspecification.SelectedValue.ToString() == "") ? "" : cmbspecification.SelectedValue.ToString();
                        im.Item_PTS = (cmbPtsNo.Text == "") ? "" : cmbPtsNo.Text;
                        im.Item_BOM_Req = "No";
                        im.Item_Critical_Item = "Yes";
                        im.Item_ShelfLife = "No";
                        im.CompID = "0001";
                        db.Item_RM_Masters.InsertOnSubmit(im);
                        db.SubmitChanges();

                       
                        for (int i = 0; i < dgItemmaster.Rows.Count - 1; i++)
                        {
                            Item_RM_Code ic = new Item_RM_Code();
                            ic.Item_Spec = (cmbspecification.SelectedValue.ToString() == "") ? "" : cmbspecification.SelectedValue.ToString();
                            ic.Item_Dia = (dgItemmaster.Rows[i].Cells["Item_Dia"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Dia"].Value == null || dgItemmaster.Rows[i].Cells["Item_Dia"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_Dia"].Value.ToString());
                            ic.Item_WT = (dgItemmaster.Rows[i].Cells["Item_WT"].Value == "" || dgItemmaster.Rows[i].Cells["Item_WT"].Value == null || dgItemmaster.Rows[i].Cells["Item_WT"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_WT"].Value.ToString());
                            ic.Item_SchNo = (dgItemmaster.Rows[i].Cells["Item_SchNo"].Value == "" || dgItemmaster.Rows[i].Cells["Item_SchNo"].Value == null) ? "" : dgItemmaster.Rows[i].Cells["Item_SchNo"].Value.ToString();
                            ic.Part_List_No = (dgItemmaster.Rows[i].Cells["Part_List_No"].Value == "" || dgItemmaster.Rows[i].Cells["Part_List_No"].Value == null) ? "" : dgItemmaster.Rows[i].Cells["Part_List_No"].Value.ToString();
                            ic.Item_UWt = (dgItemmaster.Rows[i].Cells["Item_UWt"].Value == "" || dgItemmaster.Rows[i].Cells["Item_UWt"].Value == null || dgItemmaster.Rows[i].Cells["Item_UWt"].Value == DBNull.Value) ? Convert.ToDecimal(0) : Convert.ToDecimal(dgItemmaster.Rows[i].Cells["Item_UWt"].Value.ToString());
                            ic.Item_Description = (dgItemmaster.Rows[i].Cells["Item_Description"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Description"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_Description"].Value.ToString());
                            ic.Item_Code = (dgItemmaster.Rows[i].Cells["Item_Code"].Value == "" || dgItemmaster.Rows[i].Cells["Item_Code"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_Code"].Value.ToString());
                            ic.Item_LongText = (dgItemmaster.Rows[i].Cells["Item_LongText"].Value == "" || dgItemmaster.Rows[i].Cells["Item_LongText"].Value == null) ? "" : (dgItemmaster.Rows[i].Cells["Item_LongText"].Value.ToString());
                            ic.CompID = "0001";
                            db.Item_RM_Codes.InsertOnSubmit(ic);
                        }
                        db.SubmitChanges();
                        MessageBox.Show("Recore Saved Succesfully");
                    }

                   
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Search.ItemMastersearchh obj = new Search.ItemMastersearchh();
          if(obj.ShowDialog()==DialogResult.Cancel)
            {
                var sa = (db.Sp_Bind_ItemsMasterData("0001", Search.ItemMastersearchh.Specno)).ToList();
                if(sa.Count>0)
                {
                    cmbType.Text = sa[0].Item_Type;
                    cmbGroup.Text = sa[0].Item_Group;
                    cmbpurchaseuom.Text = sa[0].puruom;
                    cmbissuuom.Text = sa[0].iisuuom;
                    cmbspecification.Text = sa[0].Item_Spec;
                    cmbPtsNo.Text = sa[0].Item_PTS;
                    if("Yes"==sa[0].Item_Critical_Item)
                    {
                        chkCriticalitem.Checked = true;
                    }
                    else
                    {
                        chkCriticalitem.Checked = false;
                    }
                    if ("Yes" == sa[0].Item_ShelfLife)
                    {
                        chkShelfLifeitem.Checked = true;
                    }
                    else
                    {
                        chkShelfLifeitem.Checked = false;
                    }
                    if ("Yes" == sa[0].Item_BOM_Req)
                    {
                        chkBomReq.Checked = true;
                    }
                    else
                    {
                        chkBomReq.Checked = false;
                    }
                }
                SqlCommand cmd2 = new SqlCommand("Sp_Bind_ItemsMasterDataTo_Grid", con);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@CompName", "0001");
                cmd2.Parameters.AddWithValue("@SpecName", cmbspecification.Text);               
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                DataSet ds2 = new DataSet();
                da2.Fill(ds2, "x");
                if (ds2.Tables["X"].Rows.Count > 0)
                {
                    dgItemmaster.DataSource = ds2.Tables[0];
                }
                else
                {
                    MessageBox.Show("No Records Found");
                }
            }
        }

        private void frmPartMaster_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.F2)
            {
                groupBox1.Visible = true;
            }
        }

        private void frmPartMaster_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.F2)
            {
                groupBox1.Visible = true;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }
      public static  string nos = "";
        private void button2_Click_1(object sender, EventArgs e)
        {
            nos = "";
            
            for (int i = 0; i < dataGridView1.Rows.Count; i = i + 1)
            {
                if (dataGridView1.Rows[i].Cells["Column1"].Value != null)
                {
                    if (dataGridView1.Rows[i].Cells["Column1"].Value.ToString().Equals("True"))
                    {
                        if(nos=="")
                        {
                            nos += dataGridView1.Rows[i].Cells["Part_List_No1"].Value;
                        }
                        else
                        {
                            nos += ","+dataGridView1.Rows[i].Cells["Part_List_No1"].Value;
                        }
                       
                    }
                }
                
            }
            groupBox1.Visible = false;
            dgItemmaster.Rows[roeind].Cells["Part_List_No"].Value = nos;
            roeind = -1;
        }
        public int roeind;
        private void dgItemmaster_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow R = dgItemmaster.Rows[dgItemmaster.CurrentRow.Index];
            int columnIndex = dgItemmaster.CurrentCell.ColumnIndex;
            string columnName = dgItemmaster.Columns[columnIndex].Name;
            if ("Column2" == columnName)
            {               
                groupBox1.Visible = true;
                roeind = e.RowIndex;
            }
            else if("Column3" == columnName)
            {
                 try
            {
  if (dgItemmaster.Rows.Count > 1)
                {
                    if (dgItemmaster.Rows[dgItemmaster.CurrentRow.Index].Cells[dgItemmaster.CurrentCell.ColumnIndex].Value == "Remove")
                    {
                        if (dgItemmaster.Rows.Count > 0)
                        {
                            foreach (DataGridViewCell oneCell in dgItemmaster.SelectedCells)
                            {
                                if (oneCell.Selected)
                                        dgItemmaster.Rows.RemoveAt(oneCell.RowIndex);
                            }

                        }
                    }
                }
            }

            catch (Exception)
            {
            }
            }
        }

        private void btnPtsno_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Masters.PTMaster obj = new Masters.PTMaster();
            if (obj.ShowDialog() == DialogResult.Cancel)
            {
                BindPartList();
            }
        }
    }
}
