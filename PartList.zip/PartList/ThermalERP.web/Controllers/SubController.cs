﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class SubController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: Sub
        public ActionResult Index()
        {
            return View(db.SubAssembly_Master.ToList());
          
        }
    }
}