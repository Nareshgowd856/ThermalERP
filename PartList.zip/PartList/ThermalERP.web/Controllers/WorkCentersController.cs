﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;

namespace ThermalERP.web.Controllers
{
    public class WorkCentersController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        [HttpPost]
        public ActionResult Index()
        {
            return View(db.WorkCenters.ToList());
        }
        [HttpGet]
        public ActionResult Index(int page = 1, string sort = "Work_Center_id", string sortdir = "asc", string search = "")
        {
            int pagesize = 10;
            int totalRecord = 0;
            if (page < 1) page = 1;
            int skip = (page * pagesize) - pagesize;
            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
            ViewBag.TotalRows = totalRecord;
            return View(data);
        }
        public List<WorkCenter> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var v = (from a in db.WorkCenters
                         where
                         a.Work_Center_id.Contains(Search) ||
                         a.Work_Center.Contains(Search)

                         select a
                         );
                TotalRecord = v.Count();
                v = v.OrderBy(sort + " " + sortdir);
                if (pageSize > 0)
                {
                    v = v.Skip(skip).Take(pageSize);
                }
                return v.ToList();
            }
        }

        // GET: WorkCenters/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkCenter workCenter = db.WorkCenters.Find(id);
            if (workCenter == null)
            {
                return HttpNotFound();
            }
            return View(workCenter);
        }

        // GET: WorkCenters/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.WorkCenters, "Id", "Work_Center");
            return PartialView("Partial_Create");
        }

        // POST: WorkCenters/Create
       
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "id,Work_Center_id,Work_Center,CompID,Created_By,Created_On,Modified_By,modified_On")] WorkCenter workCenter)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.WorkCenters.Add(workCenter);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.WorkCenters, "Id", "Work_Center", workCenter.Work_Center);
        //    return View(workCenter);
        //}

        // GET: WorkCenters/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkCenter workCenter = db.WorkCenters.Find(id);
            if (workCenter == null)
            {
                return HttpNotFound();
            }
            return View(workCenter);
        }

        // POST: WorkCenters/Edit/5
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Work_Center_id,Work_Center,CompID,Created_By,Created_On,Modified_By,modified_On")] WorkCenter workCenter)
        {
            if (ModelState.IsValid)
            {
                db.Entry(workCenter).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(workCenter);
        }

        // GET: WorkCenters/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WorkCenter workCenter = db.WorkCenters.Find(id);
            if (workCenter == null)
            {
                return HttpNotFound();
            }
            return View(workCenter);
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Work_Center_id,Work_Center,CompID,Created_By,Created_On,Modified_By,modified_On")] WorkCenter workCenter)
        {
            if (ModelState.IsValid)
            {
                db.WorkCenters.Add(workCenter);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.WorkCenters, "Id", "Work_Center", workCenter.Work_Center);
            return View(workCenter);
        }

        // POST: WorkCenters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            WorkCenter workCenter = db.WorkCenters.Find(id);
            db.WorkCenters.Remove(workCenter);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
