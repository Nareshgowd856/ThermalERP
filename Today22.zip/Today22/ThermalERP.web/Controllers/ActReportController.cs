﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ActReportController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ActReport
        public ActionResult Index()
        {
            return View(db.Activity_Report.ToList());
        }


        public ActionResult Packages()
        {
            return View();
        }

        public ActionResult GetPackagesData()
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                List<Activity_Report> emplist = db.Activity_Report.ToList<Activity_Report>();
                return Json(new { data = emplist }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpGet]
        public ActionResult AddOrEdit(int id = 0)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                if (id == 0)
                    return View(new Activity_Report());
                else
                {

                    // return View(db.tbladdpackages.Where(x => x.Packid == id).FirstOrDefault<tbladdpackage>());
                    var emp = db.Activity_Report.Where(x => x.id == id).FirstOrDefault<Activity_Report>();
                    return PartialView("_PartialPac", emp);
                }
            }
        }
        [HttpPost]
        public ActionResult AddOrEdit(Activity_Report emp)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                try
                {
                    if (emp.id == 0)
                    {
                        emp.Report_No = Convert.ToString(Session["userid"].ToString());
                        emp.Created_On = DateTime.Now;
                        emp.Created_By = Session["Name"].ToString();
                        db.Activity_Report.Add(emp);
                        db.SaveChanges();
                        return Json(new { success = true, message = "Saved Successfully" }, JsonRequestBehavior.AllowGet);
                        // return RedirectToAction("package");
                        //return Json(a, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        emp.Modified_By = Convert.ToString(Session["userid"]);
                        emp.Modified_On = DateTime.Now;
                        emp.Modified_By = Session["Name"].ToString();
                        db.Entry(emp).State = System.Data.Entity.EntityState.Modified;
                        db.SaveChanges();
                        return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
                        //return Json(a, JsonRequestBehavior.AllowGet);
                        //return RedirectToAction("package");
                    }
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                Activity_Report emp = db.Activity_Report.Where(x => x.id == id).FirstOrDefault<Activity_Report>();
                //   emp.Deletedbyid= Convert.ToString(Session["userid"]);
                //   emp.deleteddate = DateTime.Now;
                db.Activity_Report.Remove(emp);
                db.SaveChanges();
                return Json(new { success = true, message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]

        // GET: ActReport/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            if (activity_Report == null)
            {
                return HttpNotFound();
            }
            return View(activity_Report);
        }

        // GET: ActReport/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ActReport/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,Report_No,Date,Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned_StartDate,Planned_CompletionDate,Actual_StartDate,Actual_Completiondate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_Sl_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Report.Add(activity_Report);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(activity_Report);
        }

        // GET: ActReport/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            if (activity_Report == null)
            {
                return HttpNotFound();
            }
            return View(activity_Report);
        }

        // POST: ActReport/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Report_No,Date,Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned_StartDate,Planned_CompletionDate,Actual_StartDate,Actual_Completiondate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_Sl_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Report).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Report);
        }

        // GET: ActReport/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Activity_Report activity_Report = db.Activity_Report.Find(id);
        //    if (activity_Report == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(activity_Report);
        //}

        //// POST: ActReport/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Activity_Report activity_Report = db.Activity_Report.Find(id);
        //    db.Activity_Report.Remove(activity_Report);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
