﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Linq;
//using System.Net;
//using System.Web;
//using System.Web.Mvc;
//using ThermalERP.web.Models;
//using System.Linq.Dynamic;

//namespace ThermalERP.web.Controllers
//{
//    public class MakerMasterController : Controller
//    {
//        private Thermal_PMSEntities db = new Thermal_PMSEntities();

//        [HttpPost]
//        public ActionResult Index()
//        {
//            return View(db.Maker_Master.ToList());
//        }
//        [HttpGet]
//        public ActionResult Index(int page = 1, string sort = "Maker_No", string sortdir = "asc", string search = "")
//        {
//            int pagesize = 5;
//            int totalRecord = 0;
//            if (page < 1) page = 1;
//            int skip = (page * pagesize) - pagesize;
//            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
//            ViewBag.TotalRows = totalRecord;
//            return View(data);
//        }
//        public List<Maker_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                var v = (from a in db.Maker_Master
//                         where
//                         a.Maker_No.Contains(Search) ||
//                         a.Maker_Description.Contains(Search)

//                         select a
//                         );
//                TotalRecord = v.Count();
//                v = v.OrderBy(sort + " " + sortdir);
//                if (pageSize > 0)
//                {
//                    v = v.Skip(skip).Take(pageSize);
//                }
//                return v.ToList();
//            }
//        }

//        // GET: MakerMaster/Details/5
//        public ActionResult Details(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Maker_Master maker_Master = db.Maker_Master.Find(id);
//            if (maker_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(maker_Master);
//        }

//        // GET: MakerMaster/Create
//        public ActionResult Create()
//        {
//            ViewBag.Id = new SelectList(db.Maker_Master, "Id" , "MakerNo");
//            return PartialView("Partial_Create");
//        }

//        // POST: MakerMaster/Create
//        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
//        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public ActionResult Create([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
//        //{
//        //    if (ModelState.IsValid)
//        //    {
//        //        db.Maker_Master.Add(maker_Master);
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", maker_Master.Maker_No);
//        //    return View(maker_Master);
//        //}

//        // GET: MakerMaster/Edit/5
//        public ActionResult Edit(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Maker_Master maker_Master = db.Maker_Master.Find(id);
//            if (maker_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(maker_Master);
//        }

//        // POST: MakerMaster/Edit/5
//        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
//        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Edit([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Entry(maker_Master).State = System.Data.Entity.EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            return View(maker_Master);
//        }

//        // GET: MakerMaster/Delete/5
//        public ActionResult Delete(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Maker_Master maker_Master = db.Maker_Master.Find(id);
//            if (maker_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(maker_Master);
//        }

//        /// <summary>
//        /// Partial_s the create.
//        /// </summary>
//        /// <returns></returns>
//        public ActionResult Partial_Create()
//        {
//            return PartialView();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Create([Bind(Include = "Maker_No,Maker_Description,CompID,id")] Maker_Master maker_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Maker_Master.Add(maker_Master);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", maker_Master.Maker_No);
//            return PartialView(maker_Master);
//        }

//        // POST: MakerMaster/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeleteConfirmed(int id)
//        {
//            Maker_Master maker_Master = db.Maker_Master.Find(id);
//            db.Maker_Master.Remove(maker_Master);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//    }
//}










using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class MakerMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.Maker_Master.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.Maker_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Maker_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }


        [HttpPost]
        public ActionResult Save(Maker_Master emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.Maker_Master.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Maker_No = emp.Maker_No;
                        v.Maker_Description = emp.Maker_Description;
                       
                    }
                }
                else
                {
                    //Save
                    db.Maker_Master.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "MakerMaster");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.Maker_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.Maker_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.Maker_Master.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}