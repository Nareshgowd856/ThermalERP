﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Linq;
//using System.Net;
//using System.Web;
//using System.Web.Mvc;
//using ThermalERP.web.Models;
//using System.Linq.Dynamic;

//namespace ThermalERP.web.Controllers
//{
//    public class ProjectStructureController : Controller
//    {
//        private Thermal_PMSEntities db = new Thermal_PMSEntities();

//       [HttpPost]
//        public ActionResult Index()
//        {
//            return View(db.Project_Structure_Main.ToList());
//        }
//        [HttpGet]
//        public ActionResult Index(int page = 1, string sort = "Project_Code", string sortdir = "asc", string search = "")
//        {
//            int pagesize = 10;
//            int totalRecord = 0;
//            if (page < 1) page = 1;
//            int skip = (page * pagesize) - pagesize;
//            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
//            ViewBag.TotalRows = totalRecord;
//            return View(data);
//        }
//        public List<Project_Structure_Main> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                var v = (from a in db.Project_Structure_Main
//                         where
//                         a.Project_Code.Contains(Search) ||
//                         a.Maker_No.Contains(Search)

//                         select a
//                         );
//                TotalRecord = v.Count();
//                v = v.OrderBy(sort + " " + sortdir);
//                if (pageSize > 0)
//                {
//                    v = v.Skip(skip).Take(pageSize);
//                }
//                return v.ToList();
//            }
//        }
//        // GET: ProjectStructure/Details/5
//        public ActionResult Details(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
//            if (project_Structure_Main == null)
//            {
//                return HttpNotFound();
//            }
//            return View(project_Structure_Main);
//        }

//        // GET: ProjectStructure/Create
//        public ActionResult Create()
//        {
//            ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code");
//            return PartialView("Partial_Create");
//        }

//        // POST: ProjectStructure/Create

//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public ActionResult Create([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
//        //{
//        //    if (ModelState.IsValid)
//        //    {
//        //        db.Project_Structure_Main.Add(project_Structure_Main);
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code", project_Structure_Main.Project_Code);
//        //    return View(project_Structure_Main);
//        //}

//        // GET: ProjectStructure/Edit/5
//        public ActionResult Edit(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
//            if (project_Structure_Main == null)
//            {
//                return HttpNotFound();
//            }
//            return View(project_Structure_Main);
//        }

//        // POST: ProjectStructure/Edit/5

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Edit([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Entry(project_Structure_Main).State = System.Data.Entity.EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            return View(project_Structure_Main);
//        }

//        // GET: ProjectStructure/Delete/5
//        public ActionResult Delete(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
//            if (project_Structure_Main == null)
//            {
//                return HttpNotFound();
//            }
//            return View(project_Structure_Main);
//        }
//        public ActionResult Partial_Create()
//        {
//            return PartialView();
//        }
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Create([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Project_Structure_Main.Add(project_Structure_Main);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code", project_Structure_Main.Project_Code);
//            return PartialView(project_Structure_Main);
//        }
//        // POST: ProjectStructure/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeleteConfirmed(int id)
//        {
//            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
//            db.Project_Structure_Main.Remove(project_Structure_Main);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//    }
//}



















using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class ProjectStructureController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.Project_Structure_Main.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.Project_Structure_Main.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Project_Structure_Main.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }


        [HttpPost]
        public ActionResult Save(Project_Structure_Main emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.Project_Structure_Main.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Apg_No = emp.Apg_No;
                        v.APG_Name = emp.APG_Name;
                       
                    }
                }
                else
                {
                    //Save
                    db.Project_Structure_Main.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "ProjectStructure");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.Project_Structure_Main.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.Project_Structure_Main.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.Project_Structure_Main.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}