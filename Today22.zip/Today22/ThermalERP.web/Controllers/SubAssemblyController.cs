﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Linq;
//using System.Net;
//using System.Web;
//using System.Web.Mvc;
//using ThermalERP.web.Models;
//using System.Web.UI;
//using PagedList;
//using System.Configuration;
//using System.Linq.Dynamic;

//namespace ThermalERP.web.Controllers
//{
//    public class SubAssemblyController : Controller
//    {
//        private Thermal_PMSEntities db = new Thermal_PMSEntities();

//        [HttpPost]
//        public ActionResult Index()
//        {
//            return View(db.SubAssembly_Master.ToList());

//        }
//        [HttpGet]
//        public ActionResult Index(int page = 1, string sort = "Sub_Assembly_ID", string sortdir = "asc", string search = "")
//        {
//            int pagesize = 10;
//            int totalRecord = 0;
//            if (page < 1) page = 1;
//            int skip = (page * pagesize) - pagesize;
//            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
//            ViewBag.TotalRows = totalRecord;
//            return View(data);
//        }
//        public List<SubAssembly_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                var v = (from a in db.SubAssembly_Master
//                         where
//                         a.Sub_Assembly_ID.Contains(Search) ||
//                         a.Sub_Assembly_Name.Contains(Search)

//                         select a
//                         );
//                TotalRecord = v.Count();
//                v = v.OrderBy(sort + " " + sortdir);
//                if (pageSize > 0)
//                {
//                    v = v.Skip(skip).Take(pageSize);
//                }
//                return v.ToList();
//            }
//        }


//        // GET: SubAssembly/Details/5
//        public ActionResult Details(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
//            if (subAssembly_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(subAssembly_Master);
//        }

//        // GET: SubAssembly/Create
//        public ActionResult Create()
//        {
//            ViewBag.Id = new SelectList(db.SubAssembly_Master, "ID", "Sub_Assembly_ID");
//            return PartialView("Partial_Create");
//        }

//        public ActionResult Edit()
//        {
//            ViewBag.Id = new SelectList(db.SubAssembly_Master, "ID", "Sub_Assembly_ID");
//            return PartialView("Partial_Edit");
//        }
//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public ActionResult Create([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
//        //{
//        //    if (ModelState.IsValid)
//        //    {
//        //        db.SubAssembly_Master.Add(subAssembly_Master);
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.SubAssembly_Master, "Id", "Sub_Assembly_ID", subAssembly_Master);
//        //    return View(subAssembly_Master);
//        //}

//        // GET: SubAssembly/Edit/5
//        public ActionResult Edit(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
//            if (subAssembly_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(subAssembly_Master);
//        }

//        // POST: SubAssembly/Edit/5
//        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
//        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Edit([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Entry(subAssembly_Master).State = System.Data.Entity.EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            return View(subAssembly_Master);
//        }

//        // GET: SubAssembly/Delete/5
//        public ActionResult Delete(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
//            if (subAssembly_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(subAssembly_Master);
//        }
//        public ActionResult Partial_Create()
//        {
//            return PartialView();
//        }

//        public ActionResult Partial_Edit()
//        {
//            return PartialView();
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Edit([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
//        {
//            if(ModelState.IsValid)
//            {
//                db.Entry(subAssembly_Master).State = System.Data.Entity.EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            return View(subAssembly_Master);
//        }

//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Create([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.SubAssembly_Master.Add(subAssembly_Master);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.SubAssembly_Master, "Id", "Sub_Assembly_ID", subAssembly_Master);
//            return PartialView(subAssembly_Master);
//        }



//        // POST: SubAssembly/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeleteConfirmed(int id)
//        {
//            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
//            db.SubAssembly_Master.Remove(subAssembly_Master);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }


//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//    }
//}




using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class SubAssemblyController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            return View(db.SubAssembly_Master.ToList());

        }
        [HttpGet]
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
        {
            if (ModelState.IsValid)
            {
                db.SubAssembly_Master.Add(subAssembly_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.SubAssembly_Master, "Id", "Sub_Assembly_ID", subAssembly_Master);
            return PartialView(subAssembly_Master);
        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        //public ActionResult Create()
        //{
        //    return View("Partial_Create");
        //}


        [HttpPost]
        public ActionResult Save(SubAssembly_Master emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.SubAssembly_Master.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Sub_Assembly_ID = emp.Sub_Assembly_ID;
                        v.Sub_Assembly_Name = emp.Sub_Assembly_Name;
                        v.GroupName = emp.GroupName;
                    }
                }
                else
                {
                    //Save
                    db.SubAssembly_Master.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "SubAssembly");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.SubAssembly_Master.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}
