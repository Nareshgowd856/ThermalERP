﻿




using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class VariantMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.Variant_Master.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.Variant_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Variant_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return PartialView("Partial_Create");
        }
       

        [HttpPost]
        public ActionResult Save(Variant_Master emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.Variant_Master.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Variant_ID = emp.Variant_ID;
                        v.Variant_Name = emp.Variant_Name;
                       
                    }
                }
                else
                {
                    //Save
                    db.Variant_Master.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "VariantMaster");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.Variant_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.Variant_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.Variant_Master.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}