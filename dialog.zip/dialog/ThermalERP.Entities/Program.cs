﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThermalERP.Entities
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
