﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ThermalERP.web.Models
{
    public class Add
    {
        public Activity_Master Code { get; set; }
       public IList GetList { get; set; }
    }
}