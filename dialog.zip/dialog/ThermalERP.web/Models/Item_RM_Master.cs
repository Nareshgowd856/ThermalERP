
namespace ThermalERP.web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class Item_RM_Master
    {
        [Display(Name = "Item Type")]
        public string Item_Type { get; set; }
        [Display(Name = "Item Group")]
        public string Item_Group { get; set; }
        [Display(Name = "Item Pur UOM")]
        public string Item_Pur_UOM { get; set; }
        [Display(Name = "Item Iss UOM")]
        public string Item_Iss_UOM { get; set; }
        [Display(Name = "Item Spec")]
        public string Item_Spec { get; set; }
        [Display(Name = "Item PTS")]
        public string Item_PTS { get; set; }
        [Display(Name = "Item BOM Req")]
        public string Item_BOM_Req { get; set; }
        [Display(Name = "Item Critical Item")]
        public string Item_Critical_Item { get; set; }
        [Display(Name = "Item ShelfLife")]
        public string Item_ShelfLife { get; set; }
        public string CompID { get; set; }
        public int id { get; set; }
    }
}
